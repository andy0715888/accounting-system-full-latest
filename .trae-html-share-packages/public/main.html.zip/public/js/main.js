console.log('main.js loaded');

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM ready');
    let state = {
        tabs: [],
        currentTabId: null,
        columns: [],
        records: [],
        selectedRows: new Set(),
        filters: {},
        filterOptions: {},
        tabFilters: {},
        tabScrollTops: {},
        isOnline: true,
        tabCache: {},
        tabManageMode: false,
        selectedTabs: new Set(),
        renameTabId: null,
        providerOptions: [],
        isLoaded: false,
        userName: '',
        isAdmin: false,
        ipPortSuffix: '',
        domainPortSuffix: '',
        // 统计时间范围（0=所有）
        statsMonthRange: 6,
        statsYearRange: 6,
        // 财务统计隐藏敏感数字（默认隐藏）
        statsHidden: true,
        // 分页
        page: 1,
        pageSize: 100,
        total: 0,
        totalPages: 1,
        // 收入弹窗
        incomeRecordId: null,
        incomeRecords: [],
        // 支出弹窗
        expenseRecordId: null,
        expenseRecords: [],
        // 主机支出明细弹窗（独享/共享标签）
        hostExpenseRecordId: null,
        hostExpenseDetails: [],
        // 收入/支出明细排序：{ field: 'date'|'amount', order: 'asc'|'desc' }
        incomeSort: { field: 'date', order: 'desc' },
        expenseSort: { field: 'date', order: 'desc' },
        hostExpenseSort: { field: 'date', order: 'asc' },
        // 客户信息复制（共享标签剪切/粘贴）
        copiedClientRecordId: null,
        // 服务器信息复制（共享标签提取/粘贴）
        copiedServerData: null,
        copiedServerRecordId: null,
        // 独享标签：提取的客户信息（含收入明细）
        extractedClientData: null,
        // 独享标签：提取的服务器+客户全量信息
        extractedBothData: null,
        // 列定义缓存
        columnsCache: {},
        // 行管理模式
        rowManageMode: false,
        // 待保存记录追踪
        pendingSaves: new Set(),
        // 撤销栈
        undoStack: [],
        // 焦点行高亮色
        focusHighlightColor: '#fff3cd'
    };

    // DOM 引用
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);
    const tabBar = $('#tabBar');
    const tableHead = $('#tableHead');
    const tableBody = $('#tableBody');
    const recordCount = $('#recordCount');
    const statusText = $('#statusText');
    const usernameDisplay = $('#usernameDisplay');
    const currentTimeDisplay = $('#currentTimeDisplay');
    const addTabBtn = $('#addTabBtn');
    const manageTabsBtn = $('#manageTabsBtn');
    const deleteTabsBtn = $('#deleteTabsBtn');
    const addRowBtn = $('#addRowBtn');
    const deleteRowsBtn = $('#deleteRowsBtn');
    const manageRowsBtn = $('#manageRowsBtn');
    const importBtn = $('#importBtn');
    const exportBtn = $('#exportBtn');
    const exportInfoBtn = $('#exportInfoBtn');
    const exportInfoModal = $('#exportInfoModal');
    const closeExportInfoModal = $('#closeExportInfoModal');
    const exportInfoConfirm = $('#exportInfoConfirm');
    const exportInfoCancel = $('#exportInfoCancel');
    const exportInfoStatus = $('#exportInfoStatus');
    const exportClientInfoModal = $('#exportClientInfoModal');
    const closeExportClientInfoModal = $('#closeExportClientInfoModal');
    const exportClientConfirm = $('#exportClientConfirm');
    const exportClientCancel = $('#exportClientCancel');
    const exportClientStatus = $('#exportClientStatus');
    const refreshBtn = $('#refreshBtn');
    const manageColumnsBtn = $('#manageColumnsBtn');
    const conditionalFormatBtn = $('#conditionalFormatBtn');
    const conditionalFormatModal = $('#conditionalFormatModal');
    const closeConditionalFormatModal = $('#closeConditionalFormatModal');
    const incomeExpenseStatsBtn = $('#incomeExpenseStatsBtn');
    const incomeExpenseStatsModal = $('#incomeExpenseStatsModal');
    const closeIncomeExpenseStatsModal = $('#closeIncomeExpenseStatsModal');
    const statsTotalIncome = $('#statsTotalIncome');
    const statsTotalExpense = $('#statsTotalExpense');
    const statsNetProfit = $('#statsNetProfit');
    const statsRecordCount = $('#statsRecordCount');
    const statsProfitRatio = $('#statsProfitRatio');
    const cfModalTabName = $('#cfModalTabName');
    const cfColSelect = $('#cfColSelect');
    const cfConditionSelect = $('#cfConditionSelect');
    const cfValueInput = $('#cfValueInput');
    const cfColorInput = $('#cfColorInput');
    const cfBoldCheck = $('#cfBoldCheck');
    const cfAddBtn = $('#cfAddBtn');
    const cfCancelEditBtn = $('#cfCancelEditBtn');
    const cfList = $('#cfList');
    const addressSuffixBtn = $('#addressSuffixBtn');
    const providerManageBtn = $('#providerManageBtn');
    const logoutBtn = $('#logoutBtn');
    const columnModal = $('#columnModal');

    const confirmModal = $('#confirmModal');
    const confirmModalTitle = $('#confirmModalTitle');
    const confirmModalMessage = $('#confirmModalMessage');
    const confirmModalYes = $('#confirmModalYes');
    const confirmModalNo = $('#confirmModalNo');
    const closeConfirmModal = $('#closeConfirmModal');
    const closeColumnModal = $('#closeColumnModal');
    const addColBtn = $('#addColBtn');
    const columnList = $('#columnList');
    const newColName = $('#newColName');
    const newColType = $('#newColType');
    const importModal = $('#importModal');
    const closeImport = $('#closeImport');
    const importFileInput = $('#importFileInput');
    const confirmImport = $('#confirmImport');
    const cancelImport = $('#cancelImport');
    const importStatus = $('#importStatus');
    const statsContainer = $('#statsContainer');
    const changePwdBtn = $('#changePasswordBtn');
    const oldPwdInput = $('#oldPassword');
    const newPwdInput = $('#newPassword');
    const confirmPwdInput = $('#confirmPassword');
    const changePwdStatus = $('#changePwdStatus');
    const changeUsernameBtn = $('#changeUsernameBtn');
    const usernamePasswordInput = $('#usernamePassword');
    const newUsernameInput = $('#newUsername');
    const changeUsernameStatus = $('#changeUsernameStatus');
    const allowRegisterCheckbox = $('#allowRegisterCheckbox');
    const saveRegisterSwitchBtn = $('#saveRegisterSwitchBtn');
    const registerSwitchStatus = $('#registerSwitchStatus');
    const registerSwitchGroup = $('#registerSwitchGroup');

    const addressSuffixModal = $('#addressSuffixModal');
    const closeAddressSuffixModal = $('#closeAddressSuffixModal');
    const ipPortSuffixInput = $('#ipPortSuffixInput');
    const domainPortSuffixInput = $('#domainPortSuffixInput');
    const saveSuffixBtn = $('#saveSuffixBtn');
    const suffixStatus = $('#suffixStatus');
    const renameTabModal = $('#renameTabModal');
    const closeRenameTabModal = $('#closeRenameTabModal');
    const renameTabInput = $('#renameTabInput');
    const saveRenameTabBtn = $('#saveRenameTabBtn');
    const cancelRenameTabBtn = $('#cancelRenameTabBtn');
    const renameTabStatus = $('#renameTabStatus');
    const renameTabModalTitle = $('#renameTabModalTitle');
    const renameTabForm = $('#renameTabForm');
    const addTabForm = $('#addTabForm');
    const newTabNameInput = $('#newTabNameInput');
    const saveNewTabBtn = $('#saveNewTabBtn');
    const cancelNewTabBtn = $('#cancelNewTabBtn');
    const newTabStatus = $('#newTabStatus');
    const providerModal = $('#providerModal');
    const closeProviderModal = $('#closeProviderModal');
    const providerNameInput = $('#providerNameInput');
    const addProviderBtn = $('#addProviderBtn');
    const providerList = $('#providerList');
    const providerStatus = $('#providerStatus');

    const paginationBar = $('#paginationBar');
    const paginationInfo = $('#paginationInfo');
    const prevPageBtn = $('#prevPageBtn');
    const nextPageBtn = $('#nextPageBtn');
    const firstPageBtn = $('#firstPageBtn');
    const lastPageBtn = $('#lastPageBtn');
    const pageIndicator = $('#pageIndicator');
    const pageSizeSelect = $('#pageSizeSelect');
    // 同步 state.pageSize 与下拉框初始值
    state.pageSize = parseInt(pageSizeSelect ? pageSizeSelect.value : 1000) || 1000;
    const pageJumpInput = $('#pageJumpInput');
    const pageJumpBtn = $('#pageJumpBtn');

    const incomeModal = $('#incomeModal');
    const closeIncomeModal = $('#closeIncomeModal');
    const incomeModalRow = $('#incomeModalRow');
    const incomeAmountInput = $('#incomeAmountInput');
    const incomeDateInput = $('#incomeDateInput');
    const incomeRemarkInput = $('#incomeRemarkInput');
    const addIncomeBtn = $('#addIncomeBtn');
    const incomeList = $('#incomeList');
    const incomeTotalDisplay = $('#incomeTotalDisplay');
    const incomeStatus = $('#incomeStatus');

    const expenseModal = $('#expenseModal');
    const closeExpenseModal = $('#closeExpenseModal');
    const expenseModalRow = $('#expenseModalRow');
    const expenseAmountInput = $('#expenseAmountInput');
    const expenseDateInput = $('#expenseDateInput');
    const expenseRemarkInput = $('#expenseRemarkInput');
    const addExpenseBtn = $('#addExpenseBtn');
    const expenseList = $('#expenseList');
    const expenseTotalDisplay = $('#expenseTotalDisplay');
    const expenseStatus = $('#expenseStatus');

    // 独享/共享标签主机支出明细弹窗
    const hostExpenseModal = $('#hostExpenseModal');
    const closeHostExpenseModal = $('#closeHostExpenseModal');
    const hostExpenseModalRow = $('#hostExpenseModalRow');
    const hostExpenseUnitPriceInput = $('#hostExpenseUnitPrice');
    const hostExpenseExtraInput = $('#hostExpenseExtra');
    const hostExpenseRemarkInput = $('#hostExpenseRemarkInput');
    const addHostExpenseDetailBtn = $('#addHostExpenseDetailBtn');
    const hostExpenseList = $('#hostExpenseList');
    const hostExpenseTotalDisplay = $('#hostExpenseTotalDisplay');
    const hostExpenseStatus = $('#hostExpenseStatus');

    let filterDocumentClickBound = false;

    // --- 菜单切换 ---
    function initMenu() {
        $$('.menu-item').forEach(item => {
            item.addEventListener('click', function() {
                $$('.menu-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                const view = this.dataset.view;
                $$('.view-panel').forEach(p => p.classList.remove('active'));
                const target = document.getElementById('view-' + view);
                if (target) target.classList.add('active');
                // 切出财务统计时，重置隐藏状态为默认隐藏
                if (view !== 'stats') state.statsHidden = true;
                if (view === 'stats') renderStats();
                if (view === 'hosts') {
                    loadHosts();
                    loadCommandFolders();
                    // 从其他模块切回主机管理时，SSH 终端容器从 display:none 变为可见，
                    // xterm 尺寸需要重新测量，否则会出现空白/滚动条位置错乱
                    refitActiveTerminal();
                }
                if (view === 'memos') {
                    loadMemoTags();
                }
            });
        });
    }

    // 对当前活跃的 SSH 连接重新 fit 终端尺寸（模块切换回来时调用）
    function refitActiveTerminal() {
        if (!activeConnId) return;
        const conn = sshConnections.find(c => c.id === activeConnId);
        if (!conn || !conn.xterm || !conn.fitAddon) return;
        const ws = conn.ws;
        const fitAndResize = () => {
            try {
                conn.fitAddon.fit();
                const cols = conn.xterm.cols;
                const rows = conn.xterm.rows;
                if (ws && ws.readyState === WebSocket.OPEN && cols > 0 && rows > 0) {
                    ws.send(JSON.stringify({ type: 'resize', cols, rows }));
                }
            } catch (e) {}
        };
        // 容器刚从 none 变为可见，尺寸可能还不稳定，多次 fit 确保正确
        requestAnimationFrame(() => {
            fitAndResize();
            setTimeout(fitAndResize, 50);
            setTimeout(fitAndResize, 200);
            setTimeout(fitAndResize, 500);
        });
    }
    initMenu();

    function updateClock() {
        const now = new Date();
        const weekdays = ['日','一','二','三','四','五','六'];
        currentTimeDisplay.textContent = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} 星期${weekdays[now.getDay()]} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    }
    setInterval(updateClock, 10000);
    updateClock();

    async function updateServerStatus() {
        const ssCpu = $('#ssCpu');
        const ssMem = $('#ssMem');
        const ssDisk = $('#ssDisk');
        if (!ssCpu) return;
        try {
            const data = await API.get('/server-status');
            if (ssCpu) {
                ssCpu.textContent = data.cpu + '%';
                ssCpu.className = 'ss-value' + (data.cpu >= 80 ? ' danger' : data.cpu >= 60 ? ' warn' : '');
            }
            if (ssMem && data.memory) {
                ssMem.textContent = data.memory.percent + '%';
                ssMem.title = data.memory.usedGB + ' / ' + data.memory.totalGB + ' GB';
                ssMem.className = 'ss-value' + (data.memory.percent >= 80 ? ' danger' : data.memory.percent >= 60 ? ' warn' : '');
            }
            if (ssDisk && data.disk) {
                ssDisk.textContent = data.disk.percent + '%';
                ssDisk.title = data.disk.usedGB + ' / ' + data.disk.totalGB + ' GB';
                ssDisk.className = 'ss-value' + (data.disk.percent >= 80 ? ' danger' : data.disk.percent >= 60 ? ' warn' : '');
            }
        } catch (e) {}
    }
    setInterval(updateServerStatus, 3000);
    updateServerStatus();

    function setStatus(msg) { statusText.textContent = msg; }
    function parseDate(str) {
        if (!str) return '';
        const s = String(str).trim();
        if (!s) return '';
        let y, m, d;
        let match;
        match = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
        if (match) {
            y = parseInt(match[1]);
            m = parseInt(match[2]) - 1;
            d = parseInt(match[3]);
        }
        if (!match) {
            match = s.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日$/);
            if (match) {
                y = parseInt(match[1]);
                m = parseInt(match[2]) - 1;
                d = parseInt(match[3]);
            }
        }
        if (!match) {
            match = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
            if (match) {
                y = parseInt(match[3]);
                m = parseInt(match[1]) - 1;
                d = parseInt(match[2]);
            }
        }
        if (y !== undefined && m !== undefined && d !== undefined) {
            const dt = new Date(y, m, d);
            if (!isNaN(dt)) {
                return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
            }
        }
        const dt = new Date(s);
        if (!isNaN(dt)) {
            return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
        }
        return '';
    }
    function formatDate(d) {
        if (!d) return '';
        try { 
            const dt = new Date(d); 
            if (isNaN(dt)) return d; 
            return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
        } catch { return d; }
    }
    function formatDisplayDate(d) {
        if (!d) return '';
        try {
            const dt = new Date(d);
            if (isNaN(dt)) return d;
            const y = dt.getFullYear();
            const m = String(dt.getMonth() + 1).padStart(2, '0');
            const day = String(dt.getDate()).padStart(2, '0');
            return `${y}年${m}月${day}日`;
        } catch { return d; }
    }
    function getCellValue(record, colKey) { return record.data[colKey] ?? ''; }

    function escapeHtml(value) {
        return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function escapeAttr(value) { return escapeHtml(value); }
    function cssUrl(url) { return String(url ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }

    let _modalCounter = 0;
    function showModal(html, id) {
        const modalId = id || ('modal-' + (++_modalCounter));
        if (document.getElementById(modalId)) {
            document.getElementById(modalId).remove();
        }
        const overlay = document.createElement('div');
        overlay.id = modalId;
        overlay.className = 'modal-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:9999;';
        const box = document.createElement('div');
        box.className = 'modal-box';
        box.style.cssText = 'background:#fff;border-radius:8px;min-width:320px;max-width:90vw;max-height:85vh;overflow:auto;box-shadow:0 10px 40px rgba(0,0,0,0.2);';
        box.innerHTML = html;
        overlay.appendChild(box);
        overlay.onclick = (e) => { if (e.target === overlay) closeModal(modalId); };
        document.body.appendChild(overlay);
        return modalId;
    }
    function closeModal(id) {
        if (!id) {
            document.querySelectorAll('.modal-overlay').forEach(m => m.remove());
            return;
        }
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    function showConfirm(message, title) {
        return new Promise((resolve) => {
            confirmModalTitle.textContent = title || '确认';
            confirmModalMessage.textContent = message;
            confirmModal.classList.add('show');
            const yesHandler = () => { close(); resolve(true); };
            const noHandler = () => { close(); resolve(false); };
            const keyHandler = (e) => {
                if (e.key === 'Escape') { close(); resolve(false); }
                else if (e.key === 'Enter') { e.preventDefault(); close(); resolve(true); }
            };

            function close() {
                confirmModal.classList.remove('show');
                confirmModalYes.removeEventListener('click', yesHandler);
                confirmModalNo.removeEventListener('click', noHandler);
                closeConfirmModal.removeEventListener('click', noHandler);
                document.removeEventListener('keydown', keyHandler);
            }

            confirmModalYes.addEventListener('click', yesHandler);
            confirmModalNo.addEventListener('click', noHandler);
            closeConfirmModal.addEventListener('click', noHandler);
            document.addEventListener('keydown', keyHandler);
        });
    }

    function getChineseInitials(text) {
        const extraMap = {
            '烟': 'y', '火': 'h', '云': 'y'
        };
        const initials = 'ABCDEFGHJKLMNOPQRSTWXYZ';
        const boundary = '阿八嚓哒妸发旮哈讥咔垃妈拿噢啪期然撒塌穵昔压匝';
        return String(text || '').split('').map(ch => {
            if (extraMap[ch]) return extraMap[ch];
            if (/^[a-zA-Z0-9]$/.test(ch)) return ch.toLowerCase();
            for (let i = boundary.length - 1; i >= 0; i--) {
                if (ch.localeCompare(boundary[i], 'zh-Hans-CN') >= 0) {
                    return initials[i] ? initials[i].toLowerCase() : '';
                }
            }
            return '';
        }).join('');
    }

    function providerMatchesKeyword(name, keyword) {
        const source = String(name || '').trim().toLowerCase();
        const kw = String(keyword || '').trim().toLowerCase();
        if (!kw) return true;
        const initials = getChineseInitials(source);
        return source.includes(kw) || initials.includes(kw);
    }

    function measureTextWidth(text, fontWeight = 600, fontSize = 14) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.font = `${fontWeight} ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif`;
        return Math.ceil(ctx.measureText(text).width);
    }

    function getDisplayValue(record, col) {
        if (!record || !col) return '';
        const colKey = col.col_key;
        const val = getCellValue(record, colKey);
        if (col.col_type === 'date') {
            return formatDisplayDate(val);
        } else if (col.col_type === 'days_remaining') {
            let dateKey = colKey === 'host_remaining' ? 'host_expire' : (colKey === 'client_remaining' ? 'client_expire' : '');
            const days = computeDaysRemaining(record.data[dateKey]);
            return days !== '' ? days + ' 天' : '';
        } else if (colKey === 'ip_info') {
            return record.data.ip_address || '';
        } else if (colKey === 'is_expired') {
            if (record.record_type === 'client') {
                const clientExpire = record.data.client_expire;
                return checkExpired(clientExpire);
            } else {
                // 独享/共享服务器行：根据 host_remaining 判断
                const hostRemaining = computeDaysRemaining(record.data.host_expire);
                if (hostRemaining === '') return '未知';
                return hostRemaining >= 0 ? '有效' : '过期';
            }
        } else if (colKey === 'fee') {
            const result = computeFeeValue(val);
            return result !== null ? String(result) : (val || '');
        } else if (colKey === 'expense') {
            if (record._expenseTotal !== undefined) {
                return String(Math.round(record._expenseTotal || 0));
            }
            // 独享/共享标签：若有主机支出明细，显示 = 明细总和 + 附加
            if (record._hostExpenseDetails && record._hostExpenseDetails.length > 0) {
                const sum = (record._hostExpenseTotal || 0);
                const extra = parseExpenseExtra(record.data.expense);
                return String(Math.round(sum + extra));
            }
            const months = parseInt(record.data.months) || 0;
            const result = computeExpenseValue(val, months);
            return result !== null ? String(Math.round(result)) : (val || '');
        } else {
            return val === null || val === undefined ? '' : String(val);
        }
    }

    // 从 expense 字段解析附加金额：支持 =80+(10) / =80+10 / =80+(-10) / =80-(10)
    // 返回数字（默认 0）。仅取出附加部分，单价部分不在此函数职责内。
    function parseExpenseExtra(raw) {
        if (!raw && raw !== 0) return 0;
        const str = String(raw).trim();
        if (!str.startsWith('=')) return 0;
        // =80+(10)  或  =80+10  或  =80+(-10)  或  =80-(10)
        const m = str.match(/^=[^()]+\(([^)]+)\)$/);
        if (m) {
            const v = parseFloat(m[1]);
            return isNaN(v) ? 0 : v;
        }
        // =80+10  / =80-10
        const m2 = str.match(/^=-?\d+(?:\.\d+)?([+\-]\d+(?:\.\d+)?)$/);
        if (m2) {
            const v = parseFloat(m2[1]);
            return isNaN(v) ? 0 : v;
        }
        return 0;
    }

    // 从 expense 字段解析单价：=80+(10) → 80；=80 → 80；纯数字 → 该数字
    function parseExpenseUnitPrice(raw) {
        if (!raw && raw !== 0) return 0;
        const str = String(raw).trim();
        if (str.startsWith('=')) {
            const m = str.match(/^=(\d+(?:\.\d+)?)/);
            if (m) return parseFloat(m[1]) || 0;
            return 0;
        }
        const num = parseFloat(str);
        return isNaN(num) ? 0 : num;
    }

    // 从 record 取有效单价：只用弹窗的 host_expense_unit_price，单价0就返回0
    function getRecordUnitPrice(record) {
        if (!record) return 0;
        const d = record.data || {};
        const fromModal = parseFloat(d.host_expense_unit_price);
        if (!isNaN(fromModal)) return fromModal > 0 ? fromModal : 0;
        return 0;
    }

    // 把单价 + 附加合成 expense 字段字符串
    function buildExpenseString(unitPrice, extra) {
        const up = parseFloat(unitPrice) || 0;
        const ex = parseFloat(extra) || 0;
        if (ex === 0) return `=${up}`;
        // 正附加用 +(value)，负附加也用 +(value) 保持格式一致
        return `=${up}+(${ex})`;
    }

    function computeFeeValue(raw) {
        if (!raw && raw !== 0) return '';
        const str = String(raw).trim();
        if (str.startsWith('=')) {
            const res = evalExpression(str);
            if (typeof res === 'number' && !isNaN(res)) return res;
            return raw;
        }
        const num = parseFloat(str);
        return isNaN(num) ? raw : num;
    }

    // 修正后的支出计算：支持 =50 或 =50+(20) 或 纯数字
    function computeExpenseValue(raw, months) {
        if (raw === null || raw === undefined) return 0;
        const str = String(raw).trim();
        const m = months || 0;
        const match = str.match(/^=(\d+(?:\.\d+)?)(?:\+\((.+)\))?$/);
        if (match) {
            const unitPrice = parseFloat(match[1]) || 0;
            const extraExpr = match[2];
            const extra = extraExpr ? safeEval(extraExpr) : 0;
            return m * unitPrice + extra;
        }
        const num = parseFloat(str);
        if (!isNaN(num)) return m * num;
        return safeEval(str);
    }

    function safeEval(expr) {
        try {
            const sanitized = expr.replace(/[^0-9+\-*/().]/g, '');
            if (!sanitized) return 0;
            const result = Function('"use strict"; return (' + sanitized + ')')();
            if (typeof result === 'number' && !isNaN(result)) return result;
            return 0;
        } catch (e) { return 0; }
    }

    // 解析金额表达式（支持 "80"、"=80+10"、"=80" 等），与后端 evalAmountExpr 等价
    function evalAmountExpr(raw) {
        if (!raw) return 0;
        const str = String(raw).trim();
        if (!str) return 0;
        let expr = str.startsWith('=') ? str.slice(1) : str;
        const sanitized = expr.replace(/[^0-9+\-*/().]/g, '');
        if (!sanitized) {
            const num = parseFloat(expr);
            return isNaN(num) ? 0 : num;
        }
        return safeEval(sanitized);
    }

    function calcColumnWidth(col) {
        let headerText = getColumnDisplayName(col);
        let lines = headerText.split('<br>');
        let maxHeaderWidth = 0;
        lines.forEach(line => {
            const w = measureTextWidth(line) + 22;
            if (w > maxHeaderWidth) maxHeaderWidth = w;
        });
        if (col.is_income === 1 || col.is_income === 2) maxHeaderWidth += 20;
        maxHeaderWidth += 8;
        let maxCellWidth = 0;
        const sampleRecords = state.records.slice(0, 50);
        sampleRecords.forEach(record => {
            const displayVal = getDisplayValue(record, col);
            let w = measureTextWidth(displayVal, 400, 14) + 16;
            if (col.col_key === 'expense') w = Math.max(w, 60);
            if (w > maxCellWidth) maxCellWidth = w;
        });
        // IP addresses and dates have known widths, cap them
        if (col.col_key === 'ip_address') maxCellWidth = Math.min(maxCellWidth, 150);
        if (col.col_type === 'date' || col.col_type === 'days_remaining') maxCellWidth = Math.min(maxCellWidth, 120);
        if (col.col_key === 'password') maxCellWidth = Math.min(maxCellWidth, 120);
        if (col.col_key === 'fee') maxCellWidth = Math.min(maxCellWidth, 80);
        return Math.max(60, Math.min(250, Math.max(maxHeaderWidth, maxCellWidth)));
    }

    function getColumnDisplayName(col) {
        // 列管理中修改了列名 → 表格列头直接显示用户改后的新名字（不再用内置硬编码）
        const name = col.col_name || '';
        // 为了和旧版保持视觉一致，对用户未手动修改的"标准"列名做换行优化
        const defaultMap = {
            '主机购买时间': '主机<br>购买时间',
            '主机到期时间': '主机<br>到期时间',
            '主机剩余天数': '主机<br>剩余天数',
            '客户购买时间': '客户<br>购买时间',
            '客户到期时间': '客户<br>到期时间',
            '客户剩余天数': '客户<br>剩余天数',
            '单价备注': '单价<br>备注'
        };
        if (defaultMap[name]) return defaultMap[name];
        return escapeHtml(name);
    }

    function computeDaysRemaining(dateStr) {
        if (!dateStr) return '';
        const target = new Date(dateStr);
        if (isNaN(target)) return '';
        const now = new Date(); now.setHours(0,0,0,0);
        target.setHours(0,0,0,0);
        return Math.ceil((target - now) / (1000*60*60*24));
    }

    function checkConditionMatch(cellValue, conditionType, conditionValue) {
        if (cellValue === null || cellValue === undefined) cellValue = '';
        const cellStr = String(cellValue).trim();
        const condStr = String(conditionValue ?? '').trim();
        switch (conditionType) {
            case 'contains': return cellStr.indexOf(condStr) !== -1;
            case 'equals': return cellStr === condStr;
            case 'not_equals': return cellStr !== condStr;
            case 'starts_with': return cellStr.startsWith(condStr);
            case 'ends_with': return cellStr.endsWith(condStr);
            case 'greater_than': {
                const cellNum = parseFloat(cellStr);
                const condNum = parseFloat(condStr);
                if (isNaN(cellNum) || isNaN(condNum)) return false;
                return cellNum > condNum;
            }
            case 'less_than': {
                const cellNum = parseFloat(cellStr);
                const condNum = parseFloat(condStr);
                if (isNaN(cellNum) || isNaN(condNum)) return false;
                return cellNum < condNum;
            }
            default: return false;
        }
    }

    function getConditionalFormat(colKey, cellValue) {
        if (!state.conditionalFormats || state.conditionalFormats.length === 0) return null;
        const formats = state.conditionalFormats.filter(f => f.col_key === colKey);
        for (const fmt of formats) {
            if (checkConditionMatch(cellValue, fmt.condition_type, fmt.condition_value)) {
                return fmt;
            }
        }
        return null;
    }

    function applyFormatStyle(fmt) {
        if (!fmt) return '';
        let style = '';
        if (fmt.text_color) style += `color:${fmt.text_color};`;
        if (fmt.is_bold) style += 'font-weight:bold;';
        return style;
    }

    function checkExpired(expireDateStr) {
        if (!expireDateStr) return '未知';
        const days = computeDaysRemaining(expireDateStr);
        if (days === '') return '未知';
        return days >= 0 ? '有效' : '过期';
    }

    function calcHostExpire(purchaseDate, months) {
        if (!purchaseDate) return '';
        const d = new Date(purchaseDate);
        if (isNaN(d)) return '';
        d.setMonth(d.getMonth() + (parseInt(months) || 0));
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    function getNextMonth(date) {
        const d = new Date(date);
        d.setMonth(d.getMonth() + 1);
        return d;
    }

    function evalExpression(expr) {
        if (!expr || typeof expr !== 'string') return expr;
        if (!expr.startsWith('=')) return expr;
        try {
            const sanitized = expr.slice(1).replace(/[^0-9+\-*/().]/g, '');
            if (!sanitized) return '';
            const result = Function('"use strict"; return (' + sanitized + ')')();
            if (typeof result === 'number' && !isNaN(result)) return result;
            return expr;
        } catch (e) { return expr; }
    }

    // 网络状态检测
    function updateNetworkStatus(isOnline) {
        state.isOnline = isOnline;
        const statusEl = document.getElementById('networkStatus');
        if (!statusEl) return;
        if (isOnline) {
            statusEl.textContent = '🟢 在线';
            statusEl.className = 'network-status online';
        } else {
            statusEl.textContent = '🔴 离线';
            statusEl.className = 'network-status offline';
            setStatus('⚠️ 网络连接已断开，数据无法保存！');
        }
    }

    // 定期心跳检测（每10秒检测一次）
    let heartbeatInterval;
    function startHeartbeat() {
        if (heartbeatInterval) clearInterval(heartbeatInterval);
        heartbeatInterval = setInterval(async () => {
            try {
                await fetch('/api/auth/check', { credentials: 'include', signal: AbortSignal.timeout(3000) });
                if (!state.isOnline) updateNetworkStatus(true);
            } catch {
                if (state.isOnline) updateNetworkStatus(false);
            }
        }, 10000);
    }

    // 监听浏览器在线状态
    window.addEventListener('online', () => updateNetworkStatus(true));
    window.addEventListener('offline', () => updateNetworkStatus(false));

    // 流量统计
    const trafficStats = {
        uploadBytes: 0,
        downloadBytes: 0,
        uploadWindow: [],
        downloadWindow: [],
        lastUpdateTime: Date.now()
    };

    function formatTrafficSpeed(bytes) {
        if (bytes < 1024) return bytes.toFixed(0) + ' B/s';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB/s';
        return (bytes / 1024 / 1024).toFixed(2) + ' MB/s';
    }

    function addUploadTraffic(bytes) {
        trafficStats.uploadBytes += bytes;
        trafficStats.uploadWindow.push({ bytes, time: Date.now() });
    }

    function addDownloadTraffic(bytes) {
        trafficStats.downloadBytes += bytes;
        trafficStats.downloadWindow.push({ bytes, time: Date.now() });
    }

    function updateTrafficDisplay() {
        const now = Date.now();
        const windowMs = 2000;
        // 清理2秒前的数据
        while (trafficStats.uploadWindow.length > 0 && now - trafficStats.uploadWindow[0].time > windowMs) {
            trafficStats.uploadWindow.shift();
        }
        while (trafficStats.downloadWindow.length > 0 && now - trafficStats.downloadWindow[0].time > windowMs) {
            trafficStats.downloadWindow.shift();
        }
        // 计算2秒平均速度，转换为每秒
        const uploadBytes = trafficStats.uploadWindow.reduce((sum, x) => sum + x.bytes, 0);
        const downloadBytes = trafficStats.downloadWindow.reduce((sum, x) => sum + x.bytes, 0);
        const uploadSpeed = uploadBytes / (windowMs / 1000);
        const downloadSpeed = downloadBytes / (windowMs / 1000);
        const uploadEl = document.getElementById('uploadSpeed');
        const downloadEl = document.getElementById('downloadSpeed');
        if (uploadEl) uploadEl.textContent = formatTrafficSpeed(uploadSpeed);
        if (downloadEl) downloadEl.textContent = formatTrafficSpeed(downloadSpeed);
    }
    setInterval(updateTrafficDisplay, 1000);

    // 拦截 fetch 统计流量
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const [input, init] = args;
        // 统计上传（请求体）
        if (init && init.body) {
            const bodyStr = typeof init.body === 'string' ? init.body : JSON.stringify(init.body);
            addUploadTraffic(new Blob([bodyStr]).size);
        }
        const response = await originalFetch.apply(this, args);
        // 统计下载（响应体）—— 克隆 response 以便读取
        try {
            const cloned = response.clone();
            const buf = await cloned.arrayBuffer();
            addDownloadTraffic(buf.byteLength);
        } catch(e) {}
        return response;
    };

    async function parseResponse(response) {
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.error) {
            throw new Error(data.error || `请求失败 (${response.status})`);
        }
        return data;
    }

    const API = {
        get: (url) => fetch('/api' + url, { credentials: 'include' }).then(parseResponse),
        post: (url, data) => fetch('/api' + url, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify(data)
        }).then(parseResponse),
        put: (url, data) => fetch('/api' + url, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify(data)
        }).then(parseResponse),
        delete: (url) => fetch('/api' + url, { method: 'DELETE', credentials: 'include' }).then(parseResponse)
    };

    async function loadTabs() { state.tabs = await API.get('/tabs'); return state.tabs; }
    async function loadColumns(tabId) { state.columns = await API.get('/columns?tabId=' + tabId); return state.columns; }
    async function loadConditionalFormats(tabId) {
        state.conditionalFormats = await API.get('/conditional-formats?tabId=' + tabId);
        return state.conditionalFormats;
    }

    function isSharedTab() {
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        return tab && tab.tab_type === 'shared';
    }
    function isSimpleTab() {
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        return tab && tab.tab_type === 'simple';
    }

    // Server-only columns (inherited by client rows, not editable)
    const SERVER_ONLY_COLS = new Set(['provider', 'months', 'host_purchase', 'host_expire', 'host_remaining', 'expense', 'ip_info', 'address']);
    const CLIENT_INHERITED_COLS = new Set(['ip_address', 'password', 'domain', 'remark']);
    // 点击编辑后输入框按内容最大长度显示的列（非编辑时居中，编辑时展开）
    const EXPAND_COLS = new Set(['ip_address', 'password', 'domain', 'remark', 'client_name', 'unit_price']);
    // 服务器字段：服务商,月数,主机购买时间,主机到期时间,主机剩余天数,IP地址,密码,域名,备注,地址,IP信息 + 弹窗顶部持久化单价
    const SERVER_FIELDS = ['provider', 'months', 'host_purchase', 'host_expire', 'host_remaining', 'ip_address', 'password', 'domain', 'remark', 'address', 'ip_info', 'host_expense_unit_price', 'host_expense_extra', 'host_expense_remark', 'expense_unit_price', 'income_unit_price'];
    // 客户字段：客户购买时间,客户到期时间,客户剩余天数,客户名,单价备注 + 弹窗顶部持久化单价
    const CLIENT_FIELDS = ['client_purchase', 'client_expire', 'client_remaining', 'client_name', 'unit_price', 'income_unit_price'];
    // Client-only columns (only meaningful for client rows, empty/readonly on server rows)
    // client_purchase, client_expire, client_remaining, client_name, unit_price, fee, is_expired are used by both

    const contextMenu = $('#contextMenu');
    const ctxInsertMultiAbove = $('#ctxInsertMultiAbove');
    const ctxInsertAbove = $('#ctxInsertAbove');
    const ctxAddClient = $('#ctxAddClient');
    const ctxCopyClient = $('#ctxCopyClient');
    const ctxPasteClient = $('#ctxPasteClient');
    const ctxCopyServer = $('#ctxCopyServer');
    const ctxPasteServer = $('#ctxPasteServer');
    const ctxExtractClient = $('#ctxExtractClient');
    const ctxPasteExtractedClient = $('#ctxPasteExtractedClient');
    const ctxExtractBoth = $('#ctxExtractBoth');
    const ctxPasteBoth = $('#ctxPasteBoth');
    const ctxDeleteRecord = $('#ctxDeleteRecord');
    const ctxBatchPaste = $('#ctxBatchPaste');
    const ctxCopySelected = $('#ctxCopySelected');
    const insertMultiRowModal = $('#insertMultiRowModal');
    const closeInsertMultiRowModal = $('#closeInsertMultiRowModal');
    const insertMultiRowCount = $('#insertMultiRowCount');
    const confirmInsertMultiRowBtn = $('#confirmInsertMultiRowBtn');
    const cancelInsertMultiRowBtn = $('#cancelInsertMultiRowBtn');

    async function loadRecords(tabId) {
        await flushPendingSaves();
        // 构建 URL：把 filters 作为 JSON 传给后端
        const filtersParam = Object.keys(state.filters).length > 0
            ? '&filters=' + encodeURIComponent(JSON.stringify(state.filters)) : '';
        const result = await API.get('/records?tabId=' + tabId + '&page=' + state.page + '&pageSize=' + state.pageSize + filtersParam);
        state.records = result.records || [];
        state.total = result.total || 0;
        state.totalPages = result.totalPages || 1;
        updatePaginationUI();
        return state.records;
    }

    function updateTabCache(tabId) {
        if (!tabId) return;
        state.tabCache[tabId] = {
            columns: state.columns,
            total: state.total
        };
    }

    function invalidateTabCache(tabId) {
        if (!tabId) return;
        delete state.tabCache[tabId];
        delete state.tabFilters[tabId];
    }

    function invalidateCurrentTabCache() {
        invalidateTabCache(state.currentTabId);
    }

    function updatePaginationUI() {
        if (!paginationInfo) return;
        const start = (state.page - 1) * state.pageSize + 1;
        const end = Math.min(state.page * state.pageSize, state.total);
        paginationInfo.textContent = state.total > 0 ? `第 ${start}-${end} 条，共 ${state.total} 条` : '共 0 条';
        if (pageIndicator) pageIndicator.textContent = `${state.page} / ${state.totalPages}`;
        if (firstPageBtn) firstPageBtn.disabled = state.page <= 1;
        if (prevPageBtn) prevPageBtn.disabled = state.page <= 1;
        if (nextPageBtn) nextPageBtn.disabled = state.page >= state.totalPages;
        if (lastPageBtn) lastPageBtn.disabled = state.page >= state.totalPages;
        if (pageJumpInput) { pageJumpInput.max = state.totalPages; pageJumpInput.value = state.page; }
    }

    function updateAllFilterOptions(records) {
        const data = records || state.records;
        state.columns.forEach(col => {
            const valueCountMap = new Map();
            data.forEach(r => {
                const dv = normalizeFilterValue(getDisplayValue(r, col));
                valueCountMap.set(dv, (valueCountMap.get(dv) || 0) + 1);
            });
            state.filterOptions[col.col_key] = Array.from(valueCountMap.entries())
                .map(([val, cnt]) => ({ value: val, count: cnt }))
                .sort((a, b) => String(a.value).localeCompare(String(b.value)));
        });
    }

    function updateFilterOptionsForCol(colKey, records) {
        const col = state.columns.find(c => c.col_key === colKey);
        if (!col) return;
        const data = records || state.records;
        const valueCountMap = new Map();
        data.forEach(r => {
            const dv = normalizeFilterValue(getDisplayValue(r, col));
            valueCountMap.set(dv, (valueCountMap.get(dv) || 0) + 1);
        });
        state.filterOptions[colKey] = Array.from(valueCountMap.entries())
            .map(([val, cnt]) => ({ value: val, count: cnt }))
            .sort((a, b) => String(a.value).localeCompare(String(b.value)));
    }

    async function loadDataForTab(tabId, force = false) {
        try {
            state.page = 1;
            // 并行加载列定义和记录
            const [columns] = await Promise.all([
                force || !state.columnsCache[tabId]
                    ? API.get('/columns?tabId=' + tabId)
                    : Promise.resolve(state.columnsCache[tabId]),
                loadRecords(tabId),
                loadConditionalFormats(tabId)
            ]);
            state.columns = columns;
            state.columnsCache[tabId] = columns;
            updateTabCache(tabId);
            setStatus('已加载 ' + state.records.length + ' 条记录（共 ' + state.total + ' 条）');
        }
        catch (err) { setStatus('加载失败: ' + err.message); }
    }

    function renderTabs() {
        let html = '';
        state.tabs.forEach(tab => {
            const active = tab.id === state.currentTabId ? 'active' : '';
            const checked = state.selectedTabs.has(tab.id) ? 'checked' : '';
            const checkbox = state.tabManageMode
                ? `<input type="checkbox" class="tab-select" data-tab-id="${tab.id}" ${checked} />`
                : '';
            const draggable = state.tabManageMode ? 'draggable="true"' : '';
            html += `<button class="tab-item ${active}" data-tab-id="${tab.id}" ${draggable}>
                ${checkbox}
                <span class="tab-name" data-id="${tab.id}">${escapeHtml(tab.name)}</span>
            </button>`;
        });
        tabBar.innerHTML = html;
        if (manageTabsBtn) {
            manageTabsBtn.classList.toggle('active', state.tabManageMode);
            manageTabsBtn.textContent = state.tabManageMode ? '完成' : '管理';
        }
        const tabBarEl = document.querySelector('.tab-bar');
        if (tabBarEl) tabBarEl.classList.toggle('drag-active', state.tabManageMode);
        if (state.tabManageMode) initTabDragDrop();
        tabBar.querySelectorAll('.tab-select').forEach(el => {
            el.addEventListener('click', function(e) {
                e.stopPropagation();
                const tabId = parseInt(this.dataset.tabId);
                if (this.checked) state.selectedTabs.add(tabId);
                else state.selectedTabs.delete(tabId);
            });
        });
        tabBar.querySelectorAll('.tab-name').forEach(el => {
            el.addEventListener('dblclick', async function(e) {
                e.stopPropagation();
                const tabId = parseInt(this.dataset.id);
                openRenameTabModal(tabId);
            });
        });
        tabBar.querySelectorAll('.tab-item').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (e.target.classList.contains('tab-select')) return;
                switchTab(parseInt(this.dataset.tabId));
            });
        });
        if (state.tabs.length === 0) createDefaultTab();
    }

    async function switchTab(tabId, force = false) {
        if (tabId === state.currentTabId && !force) return;
        showTableLoading();
        // 保存当前标签的滚动位置、筛选状态
        if (state.currentTabId) {
            const tw = $('#tableWrapper');
            if (tw) state.tabScrollTops[state.currentTabId] = tw.scrollTop;
            state.tabFilters[state.currentTabId] = { ...state.filters };
            saveTabFiltersToStorage();
        }
        state.currentTabId = tabId;
        state.selectedRows.clear();
        state.page = 1;
        // 跨标签剪切/粘贴：切换标签时保留所有提取状态（服务器/客户/两者），
        // 这样可以在一个标签提取、切到另一个标签粘贴。刷新键才清空。
        $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
        // 如果有跨标签的剪切，回到来源标签时重新给那行加 cut-pending 样式
        [state.copiedServerRecordId, state.extractedClientData?.recordId, state.extractedBothData?.recordId]
            .filter(Boolean)
            .forEach(id => {
                const tr = document.querySelector(`tr[data-id="${id}"]`);
                if (tr) tr.classList.add('cut-pending');
            });
        // 恢复目标标签的筛选状态
        state.filters = state.tabFilters[tabId] ? { ...state.tabFilters[tabId] } : {};
        renderTabs();
        await loadDataForTab(tabId, force);
        // 确保服务商选项已加载（避免切换标签后选项为空）
        if (!state.providerOptions.length) await loadProviderOptions();
        renderTable(false);
        // 恢复目标标签的滚动位置
        const savedScrollTop = state.tabScrollTops[tabId] || 0;
        if (savedScrollTop > 0) {
            requestAnimationFrame(() => {
                const tw = $('#tableWrapper');
                if (tw) tw.scrollTop = savedScrollTop;
            });
        }
        hideTableLoading();
        const currentTab = state.tabs.find(t => t.id === tabId);
        if (currentTab) document.getElementById('columnModalTabName').textContent = currentTab.name;
    }

    function saveTabFiltersToStorage() {
        try {
            if (state.userId) {
                localStorage.setItem('tabFilters_' + state.userId, JSON.stringify(state.tabFilters));
            }
        } catch(e) {}
    }

    async function createTab(name, tabType) {
        const result = await API.post('/tabs', { name, tab_type: tabType || 'dedicated' });
        if (result.success) {
            state.tabs.push({ id: result.id, name, tab_type: result.tab_type || tabType || 'dedicated' });
            renderTabs();
            switchTab(result.id, true);
        }
    }
    async function createDefaultTab() { await createTab('默认'); }
    async function deleteTabs(tabIds) {
        if (!tabIds || tabIds.length === 0) { setStatus('⚠️ 请先在管理模式中勾选标签'); return; }
        if (!await showConfirm(`确定删除 ${tabIds.length} 个标签及其所有数据吗？`)) return;
        try {
            setStatus('🔄 删除标签中...');
            const oldCurrentTabId = state.currentTabId;
            await Promise.all(tabIds.map(tabId => API.delete('/tabs/' + tabId)));
            tabIds.forEach(tabId => {
                invalidateTabCache(tabId);
                state.selectedTabs.delete(tabId);
                delete state.tabFilters[tabId];
            });
            saveTabFiltersToStorage();
            state.tabs = state.tabs.filter(t => !tabIds.includes(t.id));
            const wasCurrentTabDeleted = tabIds.includes(oldCurrentTabId);
            renderTabs();
            if (state.tabs.length > 0) {
                if (!wasCurrentTabDeleted) {
                    await loadDataForTab(state.currentTabId, true);
                    renderTable(false);
                } else {
                    const firstTabId = state.tabs[0].id;
                    await switchTab(firstTabId, true);
                }
            } else {
                await createDefaultTab();
            }
            setStatus(`✅ 已删除 ${tabIds.length} 个标签`);
        } catch (err) { setStatus('❌ 删除标签失败: ' + err.message); }
    }
    addTabBtn.addEventListener('click', () => {
        state.renameTabId = null;
        renameTabModalTitle.textContent = '添加标签';
        renameTabForm.style.display = 'none';
        addTabForm.style.display = 'block';
        newTabNameInput.value = '新标签';
        newTabStatus.textContent = '';
        renameTabModal.classList.add('show');
        setTimeout(() => { newTabNameInput.select(); newTabNameInput.focus(); }, 0);
    });
    manageTabsBtn.addEventListener('click', () => {
        state.tabManageMode = !state.tabManageMode;
        if (!state.tabManageMode) state.selectedTabs.clear();
        renderTabs();
    });
    deleteTabsBtn.addEventListener('click', () => deleteTabs(Array.from(state.selectedTabs)));

    function openRenameTabModal(tabId) {
        const tab = state.tabs.find(t => t.id === tabId);
        if (!tab) return;
        state.renameTabId = tabId;
        renameTabModalTitle.textContent = '编辑标签名称';
        renameTabForm.style.display = 'block';
        addTabForm.style.display = 'none';
        renameTabInput.value = tab.name;
        renameTabStatus.textContent = '';
        renameTabModal.classList.add('show');
        setTimeout(() => { renameTabInput.select(); renameTabInput.focus(); }, 0);
    }

    function closeRenameModal() {
        renameTabModal.classList.remove('show');
        renameTabStatus.textContent = '';
    }

    async function saveRenameTab() {
        const name = renameTabInput.value.trim();
        if (!name) { renameTabStatus.textContent = '⚠️ 标签名称不能为空'; return; }
        try {
            if (state.renameTabId) {
                await API.put('/tabs/' + state.renameTabId, { name });
                const tab = state.tabs.find(t => t.id === state.renameTabId);
                if (tab) tab.name = name;
                renderTabs();
                closeRenameModal();
                setStatus('✅ 标签名称已更新');
            } else {
                await createTab(name);
                closeRenameModal();
                setStatus('✅ 标签已添加');
            }
        } catch (err) { renameTabStatus.textContent = '❌ 保存失败: ' + err.message; }
    }

    closeRenameTabModal.addEventListener('click', closeRenameModal);
    cancelRenameTabBtn.addEventListener('click', closeRenameModal);
    cancelNewTabBtn.addEventListener('click', closeRenameModal);
    saveRenameTabBtn.addEventListener('click', saveRenameTab);
    renameTabInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') saveRenameTab();
        if (e.key === 'Escape') closeRenameModal();
    });

    async function saveNewTab() {
        const name = newTabNameInput.value.trim();
        if (!name) { newTabStatus.textContent = '标签名称不能为空'; return; }
        const typeRadio = document.querySelector('input[name="tabType"]:checked');
        const tabType = typeRadio ? typeRadio.value : 'dedicated';
        try {
            await createTab(name, tabType);
            closeRenameModal();
            setStatus('标签已添加');
        } catch (err) { newTabStatus.textContent = '保存失败: ' + err.message; }
    }
    saveNewTabBtn.addEventListener('click', saveNewTab);
    newTabNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') saveNewTab();
        if (e.key === 'Escape') closeRenameModal();
    });

    // --- 标签拖拽排序 ---
    let dragTabId = null;

    function initTabDragDrop() {
        const tabBar = document.querySelector('.tab-bar');
        if (!tabBar) return;

        // 使用事件委托，避免 cloneNode 丢失事件监听器
        if (tabBar._dragBound) return;
        tabBar._dragBound = true;

        tabBar.addEventListener('dragstart', function(e) {
            const tabItem = e.target.closest('.tab-item');
            if (!tabItem || !state.tabManageMode) {
                e.preventDefault();
                return;
            }
            dragTabId = parseInt(tabItem.dataset.tabId);
            tabItem.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', String(dragTabId));
        });

        tabBar.addEventListener('dragend', function(e) {
            document.querySelectorAll('.tab-item.dragging').forEach(el => el.classList.remove('dragging'));
            document.querySelectorAll('.tab-item.drag-over').forEach(el => el.classList.remove('drag-over'));
            dragTabId = null;
        });

        tabBar.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            const tabItem = e.target.closest('.tab-item');
            if (!tabItem || !state.tabManageMode) return;
            document.querySelectorAll('.tab-item.drag-over').forEach(el => el.classList.remove('drag-over'));
            tabItem.classList.add('drag-over');
        });

        tabBar.addEventListener('dragleave', function(e) {
            const tabItem = e.target.closest('.tab-item');
            if (tabItem) tabItem.classList.remove('drag-over');
        });

        tabBar.addEventListener('drop', async function(e) {
            e.preventDefault();
            document.querySelectorAll('.tab-item.drag-over').forEach(el => el.classList.remove('drag-over'));
            
            if (!state.tabManageMode) return;
            
            const tabItem = e.target.closest('.tab-item');
            if (!tabItem) return;
            
            const targetTabId = parseInt(tabItem.dataset.tabId);
            if (!dragTabId || dragTabId === targetTabId) {
                dragTabId = null;
                return;
            }

            const fromIdx = state.tabs.findIndex(t => t.id === dragTabId);
            const toIdx = state.tabs.findIndex(t => t.id === targetTabId);
            if (fromIdx < 0 || toIdx < 0) {
                dragTabId = null;
                return;
            }

            const [moved] = state.tabs.splice(fromIdx, 1);
            state.tabs.splice(toIdx, 0, moved);
            renderTabs();

            try {
                const tabIds = state.tabs.map(t => t.id);
                await API.post('/tabs/reorder', { tabIds });
            } catch (err) { 
                setStatus('排序保存失败: ' + err.message); 
            } finally {
                dragTabId = null;
            }
        });
    }

    function normalizeFilterValue(value) {
        if (value === null || value === undefined || String(value).trim() === '') return '(空白)';
        return String(value).trim();
    }
    function isFilterActive(colKey) { return state.filters.hasOwnProperty(colKey); }
    function recordMatchesFilter(record, colKey, selectedValues) {
        const col = state.columns.find(c => c.col_key === colKey);
        if (!col) return true;
        return selectedValues.includes(normalizeFilterValue(getDisplayValue(record, col)));
    }
    function getFilteredRecords() {
        const records = state.records;
        if (!isSharedTab()) return records;
        const servers = records.filter(r => r.record_type === 'server').sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id));
        const clients = records.filter(r => r.record_type === 'client');
        const result = [];
        servers.forEach(server => {
            result.push(server);
            const serverClients = clients.filter(c => c.parent_id === server.id).sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id));
            result.push(...serverClients);
        });
        return result;
    }

    // 渲染表格（刷新时不自动适配列宽）
    function renderTable(shouldAutoFit = false) {
        if (!state.currentTabId) return;
        const visibleColumns = state.columns.filter(c => c.col_visible !== 0);
        const filteredRecords = getFilteredRecords();

        let theadHtml = `<tr>${state.rowManageMode ? '<th style="width:36px;min-width:36px;max-width:36px;text-align:center;"><input type="checkbox" id="selectAll" /></th>' : ''}`;
        visibleColumns.forEach(col => {
            const isIncome = col.is_income || 0;
            let incomeLabel = isIncome === 1 ? '💰' : (isIncome === 2 ? '💸' : '');
            const hasFilter = isFilterActive(col.col_key) ? 'filter-active' : '';
            const savedWidth = col.col_width;
            const width = shouldAutoFit || !savedWidth || savedWidth === 150
                ? calcColumnWidth(col)
                : savedWidth;
            const displayName = getColumnDisplayName(col);
            theadHtml += `
                <th data-col="${escapeAttr(col.col_key)}" style="width:${width}px;min-width:${width}px;max-width:${width}px;">
                    <div class="th-inner">
                        <span class="col-name">${displayName} ${incomeLabel}</span>
                        <button class="col-dropdown-btn ${hasFilter}" data-col="${escapeAttr(col.col_key)}">▼</button>
                    </div>
                    <div class="col-resize" data-col="${escapeAttr(col.col_key)}"></div>
                </th>
            `;
        });
        theadHtml += '</tr>';
        tableHead.innerHTML = theadHtml;

        if (filteredRecords.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="${visibleColumns.length + (state.rowManageMode ? 1 : 0)}" style="text-align:center;padding:40px 0;color:#999;">暂无数据</td></tr>`;
            recordCount.textContent = Object.keys(state.filters).length > 0 ? `共 0 / 全部 ${state.records.length} 条记录` : `共 0 条记录`;
            bindFilterEvents();
            return;
        }

        let tbodyHtml = '';
        filteredRecords.forEach((record) => {
            const isSelected = state.selectedRows.has(record.id);
            const isClient = record.record_type === 'client';
            const isServer = !isClient && isSharedTab();
            const hasChildren = isServer && state.records.some(r => r.parent_id === record.id);
            const isCut = state.copiedClientRecordId === record.id;
            const cutClass = isCut ? ' cut-pending' : '';
            tbodyHtml += `<tr class="${isSelected ? 'selected' : ''} ${isClient ? 'client-row' : ''} ${isServer ? 'server-row' : ''} ${hasChildren ? 'has-children' : ''}${cutClass}" data-id="${record.id}" data-type="${record.record_type || 'server'}" data-parent="${record.parent_id || ''}">`;
            if (state.rowManageMode) {
                tbodyHtml += `<td><input type="checkbox" class="row-checkbox" data-id="${record.id}" ${isSelected ? 'checked' : ''} /></td>`;
            }
            visibleColumns.forEach(col => {
                const colKey = col.col_key;
                const val = record.data[colKey] || '';
                let inputHtml = '';
                const isServerOnlyCol = SERVER_ONLY_COLS.has(colKey);
                const CLIENT_DATE_COLS = new Set(['client_purchase', 'client_expire', 'client_remaining']);

                // Client row: server columns show empty (inherited from parent, not editable)
                if (isClient && isServerOnlyCol) {
                    tbodyHtml += `<td class="inherited-cell"></td>`;
                    return;
                }
                // Client row in shared tab: ip_address/password/domain/remark inherited from server, gray and not editable
                if (isClient && isSharedTab() && CLIENT_INHERITED_COLS.has(colKey)) {
                    const displayVal = colKey === 'password' && val ? '***' : val;
                    tbodyHtml += `<td class="inherited-cell">${escapeHtml(String(displayVal))}</td>`;
                    return;
                }
                // Server row in shared tab: client date columns sync from host, not editable
                if (isServer && CLIENT_DATE_COLS.has(colKey)) {
                    let syncVal = '';
                    if (colKey === 'client_purchase') syncVal = getDisplayValue(record, { ...col, col_key: 'host_purchase' });
                    else if (colKey === 'client_expire') syncVal = getDisplayValue(record, { ...col, col_key: 'host_expire' });
                    else if (colKey === 'client_remaining') syncVal = getDisplayValue(record, { ...col, col_key: 'host_remaining' });
                    tbodyHtml += `<td class="inherited-cell">${escapeHtml(String(syncVal))}</td>`;
                    return;
                }

                if (col.col_type === 'days_remaining') {
                    let dateKey = colKey === 'host_remaining' ? 'host_expire' : (colKey === 'client_remaining' ? 'client_expire' : '');
                    const days = computeDaysRemaining(record.data[dateKey]);
                    const displayVal = days !== '' ? days + ' 天' : '';
                    const fmt = getConditionalFormat(colKey, days);
                    let color, style;
                    if (fmt) {
                        color = fmt.text_color || '';
                        style = applyFormatStyle(fmt);
                    } else {
                        if (days <= 3) {
                            color = '#dc143c';
                            style = 'color:#dc143c;font-weight:bold;';
                        } else if (days <= 5) {
                            color = '#ffa500';
                            style = 'color:#ffa500;font-weight:bold;';
                        } else {
                            color = '#333';
                            style = '';
                        }
                    }
                    const styleAttr = style ? ` style="${style}"` : '';
                    inputHtml = `<span${styleAttr}>${escapeHtml(displayVal)}</span>`;
                } else if (colKey === 'ip_info') {
                    const ipVal = record.data.ip_address || '';
                    const fmt = getConditionalFormat(colKey, ipVal);
                    const fmtStyle = applyFormatStyle(fmt);
                    const cellStyle = `cursor:pointer;${fmtStyle || ''}`;
                    inputHtml = `<span class="ip-info-cell" data-id="${record.id}" style="${cellStyle}">${escapeHtml(ipVal)}${ipVal ? ' 🔗' : ''}</span>`;
                } else if (col.col_type === 'address_select') {
                    const optionsArr = col.col_options || [];
                    const options = optionsArr.map(opt => {
                        let display = opt;
                        if (opt === 'IP地址') display = 'IP';
                        else if (opt === '域名地址') display = '域名';
                        return `<option value="${escapeAttr(opt)}" ${val === opt ? 'selected' : ''}>${escapeHtml(display)}</option>`;
                    }).join('');
                    const addressValue = val || '';
                    const fmt = getConditionalFormat(colKey, val);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `
                        <div class="address-control">
                            <select class="cell-input address-select" data-col="${escapeAttr(colKey)}" data-id="${record.id}"${styleAttr}>${options}</select>
                            <button class="open-link" data-address="${escapeAttr(addressValue)}" data-ip="${escapeAttr(record.data.ip_address || '')}" data-domain="${escapeAttr(record.data.domain || '')}">打开</button>
                        </div>
                    `;
                } else if (col.col_type === 'number' && colKey === 'months') {
                    const num = parseInt(val) || 0;
                    const fmt = getConditionalFormat(colKey, num);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `
                        <div class="months-control">
                            <button class="months-dec" data-col="${escapeAttr(colKey)}" data-id="${record.id}">-</button>
                            <input type="number" class="cell-input months-input" data-col="${escapeAttr(colKey)}" data-id="${record.id}" value="${num}" min="0" step="1"${styleAttr} />
                            <button class="months-inc" data-col="${escapeAttr(colKey)}" data-id="${record.id}">+</button>
                        </div>
                    `;
                } else if (col.col_type === 'date') {
                    const dateVal = val || '';
                    const emptyClass = !dateVal ? ' date-empty' : '';
                    const fmt = getConditionalFormat(colKey, dateVal);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    if (colKey === 'host_expire') {
                        const display = formatDisplayDate(dateVal);
                        inputHtml = `<div class="date-cell date-readonly${emptyClass}" data-id="${record.id}" data-col="${escapeAttr(colKey)}"><span style="cursor:default;${fmtStyle}">${escapeHtml(display || '-')}</span></div>`;
                    } else {
                        const displayVal = formatDisplayDate(dateVal);
                        inputHtml = `<div class="date-cell${emptyClass}" data-id="${record.id}" data-col="${escapeAttr(colKey)}"><input type="text" class="cell-input date-text-input" data-col="${escapeAttr(colKey)}" data-id="${record.id}" value="${escapeAttr(displayVal)}" placeholder="点击设置" autocomplete="off"${styleAttr} /><input type="date" class="date-picker-hidden" data-col="${escapeAttr(colKey)}" data-id="${record.id}" value="${escapeAttr(dateVal)}" tabindex="-1" /><button class="date-picker-btn" data-col="${escapeAttr(colKey)}" data-id="${record.id}" title="选择日期" tabindex="-1">📅</button></div>`;
                    }
                } else if (colKey === 'provider') {
                    const currentProvider = val || '';
                    const providerOptions = [...state.providerOptions];
                    if (currentProvider && !providerOptions.includes(currentProvider)) providerOptions.push(currentProvider);
                    const options = providerOptions.map(opt => `
                        <div class="provider-search-option" data-value="${escapeAttr(opt)}">
                            <span>${escapeHtml(opt)}</span>
                            <small>${escapeHtml(getChineseInitials(opt))}</small>
                        </div>
                    `).join('');
                    const fmt = getConditionalFormat(colKey, currentProvider);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `
                        <div class="provider-search-box" data-id="${record.id}" data-col="${escapeAttr(colKey)}">
                            <input type="text" class="cell-input provider-search-input" data-col="${escapeAttr(colKey)}" data-id="${record.id}" value="${escapeAttr(currentProvider)}" placeholder="搜索服务商" autocomplete="off"${styleAttr} />
                            <div class="provider-search-dropdown">${options}<div class="provider-search-empty">暂无匹配服务商</div></div>
                        </div>
                    `;
                } else if (col.col_type === 'select') {
                    const options = (col.col_options || []).map(opt => `<option value="${escapeAttr(opt)}" ${val === opt ? 'selected' : ''}>${escapeHtml(opt)}</option>`).join('');
                    const fmt = getConditionalFormat(colKey, val);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `<select class="cell-input select-cell" data-col="${escapeAttr(colKey)}" data-id="${record.id}"${styleAttr}><option value="">-</option>${options}</select>`;
                } else if (colKey === 'is_expired') {
                    let status;
                    if (record.record_type === 'client') {
                        status = checkExpired(record.data.client_expire);
                    } else {
                        const hostRemaining = computeDaysRemaining(record.data.host_expire);
                        if (hostRemaining === '') { status = '未知'; }
                        else { status = hostRemaining >= 0 ? '有效' : '过期'; }
                    }
                    const fmt = getConditionalFormat(colKey, status);
                    let color = status === '有效' ? '#67c23a' : (status === '过期' ? '#f56c6c' : '#999');
                    let style = `color:${color};`;
                    if (fmt) {
                        style = applyFormatStyle(fmt) || style;
                    }
                    inputHtml = `<span style="${style}">${escapeHtml(status)}</span>`;
                } else if (colKey === 'expense') {
                    if (isSimpleTab()) {
                        const expenseTotal = record._expenseTotal || 0;
                        const displayText = expenseTotal > 0 ? Math.round(expenseTotal) : '0';
                        const fmt = getConditionalFormat(colKey, expenseTotal);
                        const fmtStyle = applyFormatStyle(fmt);
                        const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                        inputHtml = `
                            <div class="fee-summary-cell expense-summary-cell" data-id="${record.id}">
                                <span${styleAttr}>${escapeHtml(displayText)}</span>
                                <span class="fee-add-icon">+</span>
                            </div>
                        `;
                    } else {
                        const rawValue = val || '';
                        // 独享/共享标签：只认明细，没明细就是 0
                        // 有主机支出明细 → 明细总和 + 附加；没明细 → 0
                        let displayValue;
                        if (record._hostExpenseDetails && record._hostExpenseDetails.length > 0) {
                            displayValue = Math.round((record._hostExpenseTotal || 0) + parseExpenseExtra(rawValue));
                        } else {
                            displayValue = 0;
                        }
                        const fmt = getConditionalFormat(colKey, displayValue);
                        const fmtStyle = applyFormatStyle(fmt);
                        const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                        inputHtml = `
                            <div class="expense-inline" data-id="${record.id}">
                                <span class="expense-display"${styleAttr}>${displayValue}</span>
                                <input type="text" class="cell-input expense-input" value="${escapeAttr(rawValue)}" style="display:none;" />
                            </div>
                        `;
                    }
                } else if (colKey === 'fee') {
                    const incomeTotal = record._incomeTotal || 0;
                    const displayText = incomeTotal > 0 ? Math.round(incomeTotal) : '0';
                    const fmt = getConditionalFormat(colKey, incomeTotal);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `
                        <div class="fee-summary-cell" data-id="${record.id}">
                            <span${styleAttr}>${escapeHtml(displayText)}</span>
                            <span class="fee-add-icon">+</span>
                        </div>
                    `;
                } else if (colKey === 'password') {
                    const isEmpty = !val;
                    const displayMask = val ? '***' : '✎ 点击设置';
                    const emptyClass = isEmpty ? ' password-empty' : '';
                    const fmt = getConditionalFormat(colKey, val);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `<div class="password-cell" data-id="${record.id}" data-col="password"><span class="password-mask${emptyClass}"${styleAttr}>${escapeHtml(displayMask)}</span><input type="text" class="cell-input password-input expand-on-focus" data-col="password" data-id="${record.id}" value="${escapeAttr(val || '')}" /></div>`;
                } else {
                    const inputType = col.col_type === 'number' ? 'number' : 'text';
                    const step = col.col_type === 'number' ? 'step="0.01"' : '';
                    const expandClass = EXPAND_COLS.has(colKey) ? ' expand-on-focus' : '';
                    const fmt = getConditionalFormat(colKey, val);
                    const fmtStyle = applyFormatStyle(fmt);
                    const styleAttr = fmtStyle ? ` style="${fmtStyle}"` : '';
                    inputHtml = `<input type="${inputType}" class="cell-input${expandClass}" data-col="${escapeAttr(colKey)}" data-id="${record.id}" value="${escapeAttr(val || '')}" ${step}${styleAttr} />`;
                }
                const tdClass = (colKey === 'expense' || colKey === 'password' || EXPAND_COLS.has(colKey)) ? 'editable-td' : '';
                tbodyHtml += `<td class="${tdClass}">${inputHtml}</td>`;
            });
            tbodyHtml += '</tr>';
        });
        tableBody.innerHTML = tbodyHtml;
        recordCount.textContent = Object.keys(state.filters).length > 0 ? `筛选 ${filteredRecords.length} 条 / 共 ${state.total} 条` : `共 ${state.total} 条记录`;

        bindTableEvents();
        bindFilterEvents();
        bindSpecialEvents();

        // 跨标签剪切：当前表格渲染完成后，给当前标签下的剪切来源行重新补 cut-pending 样式
        if (state.copiedServerRecordId) {
            const tr = document.querySelector(`tr[data-id="${state.copiedServerRecordId}"]`);
            if (tr) tr.classList.add('cut-pending');
        }
        if (state.extractedClientData && state.extractedClientData.recordId) {
            const tr = document.querySelector(`tr[data-id="${state.extractedClientData.recordId}"]`);
            if (tr) tr.classList.add('cut-pending');
        }
        if (state.extractedBothData && state.extractedBothData.recordId) {
            const tr = document.querySelector(`tr[data-id="${state.extractedBothData.recordId}"]`);
            if (tr) tr.classList.add('cut-pending');
        }

        if (shouldAutoFit) autoFitColumns();
    }

    function autoFitColumns() {
        const table = document.getElementById('dataTable');
        if (!table) return;
        table.querySelectorAll('th').forEach((th, index) => {
            if (index === 0) return;
            const colKey = th.dataset.col;
            const col = state.columns.find(c => c.col_key === colKey);
            if (!col) return;
            const width = calcColumnWidth(col);
            th.style.width = width + 'px';
            th.style.minWidth = width + 'px';
            col.col_width = width;
            API.put('/columns/' + col.id, { col_width: width }).catch(() => {});
        });
    }

    // --- 筛选面板动态生成 ---
    function getOrCreateFilterPanel(colKey) {
        let panel = document.querySelector(`.col-dropdown-panel[data-col="${colKey}"]`);
        if (!panel) {
            panel = document.createElement('div');
            panel.className = 'col-dropdown-panel';
            panel.dataset.col = colKey;
            panel.innerHTML = `
                <div class="filter-input-wrap">
                    <input type="text" placeholder="搜索..." class="filter-search" data-col="${escapeAttr(colKey)}" />
                    <button class="filter-search-clear" data-col="${escapeAttr(colKey)}" style="display:none;position:absolute;right:6px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#909399;font-size:14px;padding:0 4px;">✕</button>
                </div>
                <div class="filter-options"></div>
                <div class="filter-summary">已选 0 / 0</div>
                <div class="filter-actions">
                    <div class="btn-row">
                        <button class="filter-ok" data-col="${escapeAttr(colKey)}">确定</button>
                        <button class="filter-cancel" data-col="${escapeAttr(colKey)}">取消</button>
                    </div>
                    <div class="btn-row full-width">
                        <button class="filter-clear" data-col="${escapeAttr(colKey)}">清除筛选</button>
                    </div>
                </div>
            `;
            document.body.appendChild(panel);
        }
        return panel;
    }

    async function refreshFilterPanelContent(panel, colKey) {
        // 从后端获取该列的全部去重值和计数
        let options = [];
        try {
            const filtersParam = Object.keys(state.filters).length > 0
                ? '&filters=' + encodeURIComponent(JSON.stringify(state.filters)) : '';
            options = await API.get('/records/filter-options?tabId=' + state.currentTabId + '&colKey=' + encodeURIComponent(colKey) + filtersParam);
        } catch (e) {
            setStatus('加载筛选选项失败');
            return;
        }
        const optionsHtml = options.map(opt => `
            <label class="filter-option-label" data-filter-label="${escapeHtml(String(opt.value).toLowerCase())}">
                <input type="checkbox" class="filter-option" data-col="${escapeAttr(colKey)}" value="${escapeAttr(opt.value)}" />
                <span class="filter-option-text">${escapeHtml(opt.value)}</span>
                <span class="filter-count">(${opt.count})</span>
            </label>
        `).join('');

        const allHtml = `
            <label class="filter-option-label filter-select-all">
                <input type="checkbox" class="filter-select-all-checkbox" data-col="${escapeAttr(colKey)}" /> <span class="filter-option-text">全选</span>
            </label>
            ${optionsHtml}
        `;
        panel.querySelector('.filter-options').innerHTML = allHtml;
        panel.querySelector('.filter-summary').textContent = `已选 0 / ${options.length}`;

        const allCheckboxes = Array.from(panel.querySelectorAll('.filter-option:not(.filter-select-all-checkbox)'));
        const selected = isFilterActive(colKey) ? state.filters[colKey] : allCheckboxes.map(cb => cb.value);
        allCheckboxes.forEach(cb => { cb.checked = selected.includes(cb.value); });
        updateSelectAllCheckbox(panel);
    }

    function positionFilterPanel(panel, colKey) {
        const th = document.querySelector(`th[data-col="${colKey}"]`);
        if (!th) return;
        const rect = th.getBoundingClientRect();
        const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 1200;
        const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 800;
        const panelWidth = Math.min(Math.max(rect.width, 180), Math.max(180, viewportWidth - 16));
        const maxLeft = Math.max(8, viewportWidth - panelWidth - 8);
        const left = Math.min(Math.max(8, rect.left), maxLeft);
        const top = Math.min(rect.bottom + 2, Math.max(8, viewportHeight - 300));
        panel.style.position = 'fixed';
        panel.style.left = left + 'px';
        panel.style.top = top + 'px';
        panel.style.width = panelWidth + 'px';
        panel.style.height = '280px';
        panel.style.overflowY = 'auto';
        panel.style.zIndex = '10000';
    }

    function closeFilterPanels() {
        $$('.col-dropdown-panel.show').forEach(p => p.classList.remove('show'));
    }

    function getVisibleFilterOptions(panel) {
        return Array.from(panel.querySelectorAll('.filter-option-label'))
            .filter(label => label.style.display !== 'none' && !label.classList.contains('filter-select-all'))
            .map(label => label.querySelector('.filter-option'))
            .filter(Boolean);
    }

    function updateSelectAllCheckbox(panel) {
        const allCb = panel.querySelector('.filter-select-all-checkbox');
        if (!allCb) return;
        const visibleOptions = getVisibleFilterOptions(panel);
        if (visibleOptions.length === 0) {
            allCb.checked = false;
            allCb.indeterminate = false;
            updateFilterSummary(panel);
            return;
        }
        const checkedCount = visibleOptions.filter(opt => opt.checked).length;
        allCb.checked = checkedCount === visibleOptions.length;
        allCb.indeterminate = checkedCount > 0 && checkedCount < visibleOptions.length;
        updateFilterSummary(panel);
    }

    // 修正后的计数：基于可见选项
    function updateFilterSummary(panel) {
        const summary = panel.querySelector('.filter-summary');
        if (!summary) return;
        const visibleOptions = getVisibleFilterOptions(panel);
        const total = visibleOptions.length;
        const checked = visibleOptions.filter(opt => opt.checked).length;
        summary.textContent = `已选 ${checked} / ${total}`;
    }

    function bindFilterEvents() {
        if (filterDocumentClickBound) return;
        filterDocumentClickBound = true;

        document.body.addEventListener('click', function(e) {
            if (e.target.classList.contains('col-dropdown-btn')) {
                e.stopPropagation();
                const colKey = e.target.dataset.col;
                const panel = getOrCreateFilterPanel(colKey);
                const isOpen = panel.classList.contains('show');
                closeFilterPanels();
                if (!isOpen) {
                    refreshFilterPanelContent(panel, colKey).then(() => {
                        positionFilterPanel(panel, colKey);
                        panel.classList.add('show');
                        const search = panel.querySelector('.filter-search');
                        if (search) {
                            setTimeout(() => search.focus(), 0);
                            if (search.value.trim()) {
                                search.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        }
                    });
                }
                return;
            }

            if (!e.target.closest('.col-dropdown-btn') && !e.target.closest('.col-dropdown-panel')) {
                closeFilterPanels();
            }

            if (e.target.classList.contains('filter-ok')) {
                const colKey = e.target.dataset.col;
                if (!colKey) return;
                const panel = document.querySelector(`.col-dropdown-panel[data-col="${colKey}"]`);
                if (!panel) return;
                const searchInput = panel.querySelector('.filter-search');
                const searchText = searchInput ? searchInput.value.trim() : '';
                const allCbs = Array.from(panel.querySelectorAll('.filter-option:not(.filter-select-all-checkbox)'));
                const allValues = allCbs.map(cb => cb.value);

                let checkedValues;
                if (searchText === '') {
                    checkedValues = allCbs.filter(cb => cb.checked).map(cb => cb.value);
                } else {
                    const visibleCbs = allCbs.filter(cb => {
                        const label = cb.closest('.filter-option-label');
                        return label && label.style.display !== 'none';
                    });
                    checkedValues = visibleCbs.filter(cb => cb.checked).map(cb => cb.value);
                }

                const hadFilter = isFilterActive(colKey);
                if (checkedValues.length === 0) {
                    delete state.filters[colKey];
                } else if (searchText === '' && checkedValues.length === allValues.length) {
                    delete state.filters[colKey];
                } else {
                    state.filters[colKey] = checkedValues;
                }
                state.tabFilters[state.currentTabId] = { ...state.filters };
                saveTabFiltersToStorage();
                panel.classList.remove('show');

                const nowClearing = hadFilter && !isFilterActive(colKey);
                const tw = $('#tableWrapper');
                // 获取屏幕上第一条可见记录的ID（用于清除筛选后定位）
                let firstVisibleId = null;
                let firstVisibleOffset = 0;
                if (tw) {
                    const rows = tw.querySelectorAll('tbody tr[data-id]');
                    for (const row of rows) {
                        const rect = row.getBoundingClientRect();
                        const twRect = tw.getBoundingClientRect();
                        if (rect.bottom >= twRect.top - 1) {
                            firstVisibleId = row.dataset.id;
                            firstVisibleOffset = rect.top - twRect.top;
                            break;
                        }
                    }
                }
                if (!nowClearing) state.page = 1;
                loadRecords(state.currentTabId).then(() => {
                    renderTable(false);
                    if (tw && nowClearing && firstVisibleId) {
                        // 清除筛选后：滚动到之前屏幕上第一条可见的记录
                        requestAnimationFrame(() => {
                            const targetRow = tw.querySelector(`tbody tr[data-id="${firstVisibleId}"]`);
                            if (targetRow) {
                                const twRect = tw.getBoundingClientRect();
                                const rowRect = targetRow.getBoundingClientRect();
                                tw.scrollTop += (rowRect.top - twRect.top) - firstVisibleOffset;
                            }
                        });
                    }
                });
                return;
            }

            if (e.target.classList.contains('filter-cancel')) {
                const panel = e.target.closest('.col-dropdown-panel');
                if (panel) panel.classList.remove('show');
                return;
            }

            if (e.target.classList.contains('filter-clear')) {
                const colKey = e.target.dataset.col;
                if (!colKey) return;
                delete state.filters[colKey];
                state.tabFilters[state.currentTabId] = { ...state.filters };
                saveTabFiltersToStorage();
                const panel = document.querySelector(`.col-dropdown-panel[data-col="${colKey}"]`);
                if (panel) {
                    panel.classList.remove('show');
                    const searchInput = panel.querySelector('.filter-search');
                    if (searchInput) searchInput.value = '';
                    const clearBtn = panel.querySelector('.filter-search-clear');
                    if (clearBtn) clearBtn.style.display = 'none';
                }
                const tw = $('#tableWrapper');
                // 获取屏幕上第一条可见记录的ID（用于清除筛选后定位）
                let firstVisibleId = null;
                let firstVisibleOffset = 0;
                if (tw) {
                    const rows = tw.querySelectorAll('tbody tr[data-id]');
                    for (const row of rows) {
                        const rect = row.getBoundingClientRect();
                        const twRect = tw.getBoundingClientRect();
                        if (rect.bottom >= twRect.top - 1) {
                            firstVisibleId = row.dataset.id;
                            firstVisibleOffset = rect.top - twRect.top;
                            break;
                        }
                    }
                }
                loadRecords(state.currentTabId).then(() => {
                    renderTable(false);
                    if (tw && firstVisibleId) {
                        // 清除筛选后：滚动到之前屏幕上第一条可见的记录
                        requestAnimationFrame(() => {
                            const targetRow = tw.querySelector(`tbody tr[data-id="${firstVisibleId}"]`);
                            if (targetRow) {
                                const twRect = tw.getBoundingClientRect();
                                const rowRect = targetRow.getBoundingClientRect();
                                tw.scrollTop += (rowRect.top - twRect.top) - firstVisibleOffset;
                            }
                        });
                    }
                });
                return;
            }
        });

        document.body.addEventListener('click', function(e) {
            if (e.target.classList.contains('filter-search-clear')) {
                e.stopPropagation();
                const panel = e.target.closest('.col-dropdown-panel');
                if (!panel) return;
                const search = panel.querySelector('.filter-search');
                if (search) {
                    search.value = '';
                    search.dispatchEvent(new Event('input', { bubbles: true }));
                    search.focus();
                }
            }
        });

        document.body.addEventListener('change', function(e) {
            if (e.target.classList.contains('filter-select-all-checkbox')) {
                const panel = e.target.closest('.col-dropdown-panel');
                const visibleOptions = getVisibleFilterOptions(panel);
                visibleOptions.forEach(opt => { opt.checked = e.target.checked; });
                updateSelectAllCheckbox(panel);
            } else if (e.target.classList.contains('filter-option') && !e.target.classList.contains('filter-select-all-checkbox')) {
                updateSelectAllCheckbox(e.target.closest('.col-dropdown-panel'));
            }
        });

        // 搜索过滤：从后端搜索该列全部数据
        let searchTimer = null;
        document.body.addEventListener('input', function(e) {
            if (e.target.classList.contains('filter-search')) {
                const panel = e.target.closest('.col-dropdown-panel');
                if (!panel) return;
                const colKey = panel.dataset.col;
                const searchText = e.target.value.trim();

                const clearBtn = panel.querySelector('.filter-search-clear');
                if (clearBtn) clearBtn.style.display = searchText ? 'block' : 'none';

                // 保存当前勾选状态
                const checkedValues = new Set();
                panel.querySelectorAll('.filter-option:not(.filter-select-all-checkbox)').forEach(cb => {
                    if (cb.checked) checkedValues.add(cb.value);
                });

                // 防抖：300ms 后请求后端
                clearTimeout(searchTimer);
                searchTimer = setTimeout(async () => {
                    let options = [];
                    try {
                        const searchParam = searchText ? '&search=' + encodeURIComponent(searchText) : '';
                        // 传递当前已有的筛选条件给 filter-options API
                        const filtersParam = Object.keys(state.filters).length > 0
                            ? '&filters=' + encodeURIComponent(JSON.stringify(state.filters)) : '';
                        options = await API.get('/records/filter-options?tabId=' + state.currentTabId + '&colKey=' + encodeURIComponent(colKey) + searchParam + filtersParam);
                    } catch (e) { /* ignore */ }

                    const selectAllHtml = `
                        <label class="filter-option-label filter-select-all">
                            <input type="checkbox" class="filter-select-all-checkbox" data-col="${escapeAttr(colKey)}" /> <span class="filter-option-text">全选</span>
                        </label>
                    `;
                    const optionsHtml = options.map(opt => `
                        <label class="filter-option-label" data-filter-label="${escapeHtml(String(opt.value).toLowerCase())}">
                            <input type="checkbox" class="filter-option" data-col="${escapeAttr(colKey)}" value="${escapeAttr(opt.value)}" />
                            <span class="filter-option-text">${escapeHtml(opt.value)}</span>
                            <span class="filter-count">(${opt.count})</span>
                        </label>
                    `).join('');

                    panel.querySelector('.filter-options').innerHTML = selectAllHtml + optionsHtml;

                    // 恢复勾选状态
                    panel.querySelectorAll('.filter-option:not(.filter-select-all-checkbox)').forEach(cb => {
                        cb.checked = checkedValues.has(cb.value);
                    });

                    updateSelectAllCheckbox(panel);
                }, 300);
            }
        });
    }

    // 表格事件
    function bindTableEvents() {
        const selectAll = $('#selectAll');
        if (selectAll) {
            selectAll.onchange = function() {
                const checked = this.checked;
                $$('.row-checkbox').forEach(cb => cb.checked = checked);
                state.selectedRows.clear();
                if (checked) $$('.row-checkbox').forEach(cb => state.selectedRows.add(parseInt(cb.dataset.id)));
                updateRowSelection();
            };
        }
        $$('.row-checkbox').forEach(cb => {
            cb.onchange = function() {
                const id = parseInt(this.dataset.id);
                if (this.checked) state.selectedRows.add(id);
                else state.selectedRows.delete(id);
                updateRowSelection();
                if (selectAll) selectAll.checked = $$('.row-checkbox').length > 0 && Array.from($$('.row-checkbox')).every(c => c.checked);
            };
        });

        $$('.cell-input:not(.address-select):not(.provider-search-input):not(.months-input):not(.date-input):not(.date-text-input):not(.expense-input):not(.fee-input)').forEach(input => {
            input.onblur = () => handleCellChange(input);
            input.onkeydown = (e) => {
                if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
            };
            if (input.tagName === 'SELECT') input.onchange = () => handleCellChange(input);
        });

        // --- 拖选粘贴功能（只初始化一次，避免重复绑定） ---
        if (!window._dragSelectBound) {
            window._dragSelectBound = true;
            window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: null, lastClickCol: null };

            // 获取当前表格中所有可见行（按 DOM 显示顺序）
            function getVisibleRows() {
                var tbody = document.querySelector('#dataTable tbody');
                if (!tbody) return [];
                return Array.from(tbody.querySelectorAll('tr[data-id]'));
            }

            // 根据行 ID 获取在当前表格中的 DOM 索引位置
            function getRowDomIndex(rowId) {
                var rows = getVisibleRows();
                for (var i = 0; i < rows.length; i++) {
                    if (parseInt(rows[i].dataset.id) === rowId) return i;
                }
                return -1;
            }

            // 获取指定列在某行中的可编辑目标元素（用于添加/移除 drag-selected）
            function getCellTargetInRow(tr, colKey) {
                // 优先找特殊单元格（密码、日期）
                var specialCell = tr.querySelector('.password-cell[data-col="' + colKey + '"], .date-cell[data-col="' + colKey + '"]');
                if (specialCell) return specialCell;
                // 普通 input 单元格
                var input = tr.querySelector('.cell-input[data-col="' + colKey + '"]');
                return input;
            }

            function clearDragHighlight() {
                $$('.cell-input.drag-selected, .password-cell.drag-selected, .date-cell.drag-selected').forEach(el => el.classList.remove('drag-selected'));
            }

            function updateDragHighlight() {
                clearDragHighlight();
                var ds = window._dragSelect;
                if (!ds.colKey) return;
                if (ds.startRowId === null || ds.endRowId === null) return;

                var startIdx = getRowDomIndex(ds.startRowId);
                var endIdx = getRowDomIndex(ds.endRowId);
                if (startIdx === -1 || endIdx === -1) return;

                var minIdx = Math.min(startIdx, endIdx);
                var maxIdx = Math.max(startIdx, endIdx);
                var rows = getVisibleRows();

                for (var i = minIdx; i <= maxIdx; i++) {
                    var target = getCellTargetInRow(rows[i], ds.colKey);
                    if (target) target.classList.add('drag-selected');
                }
            }

            // 按 DOM 显示顺序获取选中范围内的行 ID
            function getSelectedRowIds(ds) {
                if (ds.startRowId === null || ds.endRowId === null) return [];
                var startIdx = getRowDomIndex(ds.startRowId);
                var endIdx = getRowDomIndex(ds.endRowId);
                if (startIdx === -1 || endIdx === -1) return [];
                var minIdx = Math.min(startIdx, endIdx);
                var maxIdx = Math.max(startIdx, endIdx);
                var rows = getVisibleRows();
                var ids = [];
                for (var i = minIdx; i <= maxIdx; i++) {
                    var rid = parseInt(rows[i].dataset.id);
                    if (!isNaN(rid)) ids.push(rid);
                }
                return ids;
            }

            // 添加拖选粘贴的 CSS 样式
            const style = document.createElement('style');
            style.id = 'drag-select-style';
            style.textContent = `
                .cell-input.drag-selected {
                    outline: 2px solid #1890ff !important;
                    outline-offset: -2px;
                    background-color: #e6f7ff !important;
                }
                .password-cell.drag-selected {
                    outline: 2px solid #1890ff !important;
                    outline-offset: -2px;
                    background-color: #e6f7ff !important;
                }
                .date-cell.drag-selected {
                    outline: 2px solid #1890ff !important;
                    outline-offset: -2px;
                    background-color: #e6f7ff !important;
                }
                .date-cell.drag-selected .date-text-input {
                    background-color: #e6f7ff !important;
                }
            `;
            document.head.appendChild(style);

            var _dragStartPos = null;
            var DRAG_THRESHOLD = 5;

            function getCellInfoFromTarget(target) {
                var cell = target.closest('.password-cell, .date-cell, .cell-input');
                if (!cell) return null;
                var colKey, rowId;
                if (cell.classList.contains('password-cell') || cell.classList.contains('date-cell')) {
                    colKey = cell.dataset.col;
                    rowId = parseInt(cell.dataset.id);
                } else {
                    colKey = cell.dataset.col;
                    rowId = parseInt(cell.dataset.id);
                }
                if (!colKey || isNaN(rowId)) return null;
                return { colKey: colKey, rowId: rowId, cell: cell };
            }

            function isInputTypeSupported(input) {
                if (!input) return false;
                if (input.classList.contains('address-select') ||
                    input.classList.contains('months-input') || input.classList.contains('expense-input') ||
                    input.classList.contains('fee-input') || input.classList.contains('provider-search-input') ||
                    input.classList.contains('date-text-input')) return false;
                return true;
            }

            // 使用事件委托监听 mousedown
            document.addEventListener('mousedown', function(e) {
                var ds = window._dragSelect;
                if (e.target.closest('.date-picker-btn')) return;
                if (e.button !== 0) return;

                var info = getCellInfoFromTarget(e.target);
                if (!info) {
                    if (ds.startRowId && !ds.active) {
                        clearDragHighlight();
                        window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: null, lastClickCol: null };
                    }
                    return;
                }

                if (info.cell.classList.contains('cell-input') && !isInputTypeSupported(info.cell)) return;
                if (info.cell.classList.contains('date-readonly')) return;

                var colKey = info.colKey;
                var rowId = info.rowId;

                if (e.shiftKey && ds.lastClickRowId && ds.lastClickCol === colKey) {
                    window._dragSelect = { active: false, colKey: colKey, startRowId: ds.lastClickRowId, endRowId: rowId, lastClickRowId: ds.lastClickRowId, lastClickCol: colKey };
                    updateDragHighlight();
                    e.preventDefault();
                    return;
                }

                _dragStartPos = { x: e.clientX, y: e.clientY, colKey: colKey, rowId: rowId, inputEl: info.cell };
                window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: rowId, lastClickCol: colKey };
                clearDragHighlight();
            });

            document.addEventListener('mousemove', function(e) {
                var ds = window._dragSelect;
                if (_dragStartPos && !ds.active) {
                    var dx = e.clientX - _dragStartPos.x;
                    var dy = e.clientY - _dragStartPos.y;
                    if (Math.abs(dy) > DRAG_THRESHOLD && Math.abs(dy) > Math.abs(dx)) {
                        ds.active = true;
                        ds.colKey = _dragStartPos.colKey;
                        ds.startRowId = _dragStartPos.rowId;
                        ds.endRowId = _dragStartPos.rowId;
                        try { window.getSelection().removeAllRanges(); } catch (err) {}
                        updateDragHighlight();
                    }
                }

                if (!ds.active || !ds.colKey) return;
                try { window.getSelection().removeAllRanges(); } catch (err) {}
                e.preventDefault();

                var elements = document.elementsFromPoint(e.clientX, e.clientY);
                if (!elements || !elements.length) return;
                var targetRowId = null;
                for (var i = 0; i < elements.length; i++) {
                    var el = elements[i];
                    if (!el) continue;
                    var info = getCellInfoFromTarget(el);
                    if (info) {
                        targetRowId = info.rowId;
                        break;
                    }
                    var tr = el.closest && el.closest('tr[data-id]');
                    if (tr) {
                        var rid = parseInt(tr.dataset.id);
                        if (!isNaN(rid)) {
                            targetRowId = rid;
                            break;
                        }
                    }
                }
                if (targetRowId !== null && targetRowId !== ds.endRowId) {
                    ds.endRowId = targetRowId;
                    updateDragHighlight();
                }
            });

            document.addEventListener('mouseup', function() {
                _dragStartPos = null;
                if (window._dragSelect.active) {
                    window._dragSelect.active = false;
                }
            });

            // Ctrl+V 粘贴到选中的单元格（仅多行选择时生效，单行由浏览器默认粘贴）
            document.addEventListener('copy', function(e) {
                var ds = window._dragSelect;
                if (!ds.startRowId || !ds.endRowId || !ds.colKey) return;

                // 单行且输入框内有部分文本选中时，交给浏览器默认复制（只复制选中的部分）
                if (ds.startRowId === ds.endRowId) {
                    var ae = document.activeElement;
                    if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA')) {
                        if (typeof ae.selectionStart === 'number' && typeof ae.selectionEnd === 'number' && ae.selectionStart !== ae.selectionEnd) {
                            return;
                        }
                    }
                }

                e.preventDefault();
                e.stopPropagation();

                const colKey = ds.colKey;
                const isDateCol = (colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'client_expire');

                const targetRowIds = getSelectedRowIds(ds);
                if (targetRowIds.length === 0) return;

                // 收集值（优先从 DOM 中的 input 读取当前值，处理正在编辑但未保存的情况）
                const values = targetRowIds.map(rowId => {
                    if (colKey === 'password') {
                        const cell = document.querySelector(`.password-cell[data-id="${rowId}"][data-col="${colKey}"]`);
                        if (cell) {
                            const input = cell.querySelector('.password-input');
                            if (input && input.style.display !== 'none') return input.value || '';
                        }
                    } else if (isDateCol) {
                        // 日期列：仅在正在编辑时读取输入框值（YYYY-MM-DD），否则读取记录中的标准格式
                        const cell = document.querySelector(`.date-cell[data-id="${rowId}"][data-col="${colKey}"]`);
                        if (cell) {
                            const input = cell.querySelector('.date-text-input');
                            if (input && document.activeElement === input) return input.value || '';
                        }
                    } else {
                        const input = document.querySelector(`input.cell-input[data-col="${colKey}"][data-id="${rowId}"]`);
                        if (input && document.activeElement === input) return input.value || '';
                    }
                    const record = state.records.find(r => r.id === rowId);
                    return record ? (record.data[colKey] || '') : '';
                });
                const text = values.join('\n');

                try {
                    if (e.clipboardData) {
                        e.clipboardData.setData('text/plain', text);
                    } else if (window.clipboardData) {
                        window.clipboardData.setData('text', text);
                    }
                } catch(ex) {
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(text).catch(() => {});
                    }
                }
                setStatus('已复制 ' + values.length + ' 条数据');
            });

            document.addEventListener('paste', function(e) {
                var ds = window._dragSelect;
                // 单行选择时由浏览器默认粘贴处理，不拦截
                if (!ds.startRowId || !ds.endRowId || !ds.colKey) return;
                if (ds.startRowId === ds.endRowId) return;

                e.preventDefault();
                e.stopPropagation();

                var clipboardText = '';
                try { clipboardText = (e.clipboardData || window.clipboardData).getData('text'); } catch(ex) {}

                // 如果 clipboardData 无法获取，尝试异步读取
                if (!clipboardText && navigator.clipboard && navigator.clipboard.readText) {
                    navigator.clipboard.readText().then(function(text) {
                        if (text) doMultiPaste(ds, text);
                    }).catch(function() {});
                    return;
                }
                if (!clipboardText) return;

                doMultiPaste(ds, clipboardText);
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    clearDragHighlight();
                    window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: null, lastClickCol: null };
                }
                if (e.key === 'Delete' || e.key === 'Backspace') {
                    var ds = window._dragSelect;
                    if (ds && ds.startRowId !== null && ds.endRowId !== null && ds.colKey) {
                        if (ds.startRowId === ds.endRowId) return;
                        var ae = document.activeElement;
                        if (ae && ae.tagName === 'INPUT' && ae.classList.contains('date-text-input')) return;
                        e.preventDefault();
                        doMultiDelete(ds);
                    }
                }
            });
        }

        $$('.col-resize').forEach(handle => {
            let startX, startWidth, colKey;
            handle.onmousedown = (e) => {
                e.preventDefault();
                startX = e.clientX;
                colKey = handle.dataset.col;
                const th = handle.closest('th');
                startWidth = th.offsetWidth;
                document.onmousemove = (ev) => {
                    const diff = ev.clientX - startX;
                    const newWidth = Math.max(60, startWidth + diff);
                    th.style.width = newWidth + 'px';
                    th.style.minWidth = newWidth + 'px';
                };
                document.onmouseup = () => {
                    document.onmousemove = null;
                    document.onmouseup = null;
                    const col = state.columns.find(c => c.col_key === colKey);
                    if (col) {
                        const width = parseInt(th.style.width);
                        if (width > 0) {
                            col.col_width = width;
                            API.put('/columns/' + col.id, { col_width: width }).catch(() => {});
                        }
                    }
                };
            };
        });

        // 密码列：点击***显示明文input，失焦恢复***
        $$('.password-cell').forEach(cell => {
            const mask = cell.querySelector('.password-mask');
            const input = cell.querySelector('.password-input');
            if (!mask || !input) return;
            // 显示密码遮罩（带"点击编辑"占位符，避免删除后无法再次点击）
            const updateMaskDisplay = function() {
                const val = input.value;
                if (val) {
                    mask.textContent = '***';
                    mask.classList.remove('password-empty');
                } else {
                    mask.textContent = '✎ 点击设置';
                    mask.classList.add('password-empty');
                }
            };
            updateMaskDisplay();
            // 根据当前值长度动态调整输入框宽度（对齐其他可展开列的体验）
            const autosizeInput = function() {
                const val = input.value || '';
                // 1 个字符 ~8px，再加 padding（对齐其他 expand-on-focus 列视觉）
                const w = Math.max(120, val.length * 8 + 40);
                input.style.width = w + 'px';
                input.style.minWidth = '100%';
            };
            // 使用 class 切换显示，避免 CSS 默认 display:none 干扰
            const showInput = function() {
                cell.classList.add('editing');
                autosizeInput();
                input.focus();
                input.select();
            };
            const hideInput = function() {
                cell.classList.remove('editing');
                input.style.width = '';
                input.style.minWidth = '';
                updateMaskDisplay();
                handleCellChange(input);
            };
            mask.onclick = function(e) {
                e.stopPropagation();
                // 如果是拖选操作（多行选择），不进入编辑模式
                var ds = window._dragSelect;
                if (ds && ds.startRowId && ds.endRowId && ds.startRowId !== ds.endRowId) return;
                showInput();
            };
            input.onblur = function() {
                hideInput();
            };
            input.onkeydown = function(e) {
                if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
            };
            // 输入时实时拉长，遮挡其他列显示完整密码
            input.addEventListener('input', autosizeInput);
        });
    }

    function bindSpecialEvents() {
        // 日期文本输入框：单击编辑不全选，双击全选；编辑时显示 YYYY-MM-DD，非编辑显示 XXXX年XX月XX日
        $$('.date-text-input').forEach(input => {
            // 获焦：切换为 YYYY-MM-DD 标准格式以便编辑（不全选，光标按正常点击位置）
            input.addEventListener('focus', function() {
                const id = parseInt(this.dataset.id);
                const colKey = this.dataset.col;
                const record = state.records.find(r => r.id === id);
                if (record) {
                    this.value = record.data[colKey] || '';
                }
            });
            // 双击全选
            input.addEventListener('dblclick', function() {
                this.select();
            });
            // 失焦时验证并保存（handleDateTextChange 会切回 XXXX年XX月XX日 显示格式）
            input.addEventListener('blur', function() {
                handleDateTextChange(this);
            });
            // Enter 保存
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') { e.preventDefault(); this.blur(); }
            });
        });

        // 日历按钮：点击打开日期选择器
        $$('.date-picker-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const cell = this.closest('.date-cell');
                if (!cell) return;
                const hiddenInput = cell.querySelector('.date-picker-hidden');
                const textInput = cell.querySelector('.date-text-input');
                if (!hiddenInput || !textInput) return;
                // 同步当前值
                const parsed = parseDate(textInput.value);
                hiddenInput.value = parsed || '';
                // 打开日期选择器
                if (hiddenInput.showPicker) {
                    try { hiddenInput.showPicker(); } catch(e) {}
                } else {
                    hiddenInput.style.position = 'static';
                    hiddenInput.style.opacity = '1';
                    hiddenInput.style.width = 'auto';
                    hiddenInput.style.height = 'auto';
                    hiddenInput.focus();
                    hiddenInput.click();
                }
            });
        });

        // 隐藏日期选择器：选择日期后更新文本输入框
        $$('.date-picker-hidden').forEach(hiddenInput => {
            hiddenInput.addEventListener('change', function() {
                const cell = this.closest('.date-cell');
                if (!cell) return;
                const textInput = cell.querySelector('.date-text-input');
                if (textInput && this.value) {
                    textInput.value = this.value;
                    handleDateTextChange(textInput);
                }
            });
        });

        // 月数
        $$('.months-dec').forEach(btn => {
            btn.onclick = async function() {
                const col = this.dataset.col;
                const id = parseInt(this.dataset.id);
                const input = document.querySelector(`.months-input[data-col="${col}"][data-id="${id}"]`);
                if (!input) return;
                let val = parseInt(input.value) || 0;
                if (val <= 0) return;
                val--;
                input.value = val;
                // 独享/共享标签：删除最晚一笔主机支出明细
                const record = state.records.find(r => r.id === id);
                if (record && !isSimpleTab() && record._hostExpenseDetails && record._hostExpenseDetails.length > 0) {
                    try {
                        await API.delete('/host-expense/latest/' + id);
                        // 同步本地缓存
                        record._hostExpenseDetails.sort((a, b) => {
                            const da = a.expense_date || '', db = b.expense_date || '';
                            if (da !== db) return da < db ? -1 : 1;
                            return a.id - b.id;
                        });
                        record._hostExpenseDetails.pop();
                        record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                    } catch (err) { console.error('删除最晚明细失败:', err); }
                }
                handleCellChange(input);
            };
        });
        $$('.months-inc').forEach(btn => {
            btn.onclick = async function() {
                const col = this.dataset.col;
                const id = parseInt(this.dataset.id);
                const input = document.querySelector(`.months-input[data-col="${col}"][data-id="${id}"]`);
                if (!input) return;
                let val = parseInt(input.value) || 0;
                val++;
                input.value = val;
                // 独享/共享标签：自动新增一笔主机支出明细（使用当前单价，单价为0时不生成）
                const record = state.records.find(r => r.id === id);
                if (record && !isSimpleTab()) {
                    const unitPrice = getRecordUnitPrice(record);
                    if (unitPrice > 0) {
                        const d = new Date();
                        const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                        const hp = record.data.host_purchase || '';
                        const detailCount = (record._hostExpenseDetails || []).length;
                        let useDate;
                        if (detailCount === 0) {
                            useDate = /^\d{4}-\d{2}-\d{2}/.test(hp) ? hp.substring(0, 10) : today;
                        } else {
                            useDate = calcHostExpire(hp || today, detailCount);
                        }
                        try {
                            const resp = await API.post('/host-expense', {
                                record_id: id,
                                unit_price: unitPrice,
                                expense_date: useDate
                            });
                            if (!record._hostExpenseDetails) record._hostExpenseDetails = [];
                            record._hostExpenseDetails.push({
                                id: resp.id,
                                unit_price: resp.unit_price,
                                expense_date: resp.expense_date
                            });
                            record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                        } catch (err) { console.error('新增明细失败:', err); }
                    }
                }
                handleCellChange(input);
            };
        });
        $$('.months-input').forEach(input => {
            input.onchange = async function() {
                const id = parseInt(this.dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) { handleCellChange(this); return; }
                // 独享/共享标签：检测月数变化，同步明细（增删差额笔数）
                if (!isSimpleTab()) {
                    const newVal = Math.max(0, parseInt(this.value) || 0);
                    const oldVal = parseInt(record.data.months) || 0;
                    const diff = newVal - oldVal;
                    if (diff > 0) {
                        // 增加 diff 笔明细（单价为0时不生成）
                        const unitPrice = getRecordUnitPrice(record);
                        if (unitPrice > 0) {
                            const d = new Date();
                            const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                            const hp = record.data.host_purchase || '';
                            for (let i = 0; i < diff; i++) {
                                const currentCount = (record._hostExpenseDetails || []).length;
                                let useDate;
                                if (currentCount === 0) {
                                    useDate = /^\d{4}-\d{2}-\d{2}/.test(hp) ? hp.substring(0, 10) : today;
                                } else {
                                    useDate = calcHostExpire(hp || today, currentCount);
                                }
                                try {
                                    const resp = await API.post('/host-expense', {
                                        record_id: id,
                                        unit_price: unitPrice,
                                        expense_date: useDate
                                    });
                                    if (!record._hostExpenseDetails) record._hostExpenseDetails = [];
                                    record._hostExpenseDetails.push({
                                        id: resp.id,
                                        unit_price: resp.unit_price,
                                        expense_date: resp.expense_date
                                    });
                                } catch (err) { console.error('同步新增明细失败:', err); }
                            }
                            record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                        }
                    } else if (diff < 0) {
                        // 删除 |diff| 笔最晚的明细
                        for (let i = 0; i < -diff; i++) {
                            if (!record._hostExpenseDetails || record._hostExpenseDetails.length === 0) break;
                            try {
                                await API.delete('/host-expense/latest/' + id);
                                record._hostExpenseDetails.sort((a, b) => {
                                    const da = a.expense_date || '', db = b.expense_date || '';
                                    if (da !== db) return da < db ? -1 : 1;
                                    return a.id - b.id;
                                });
                                record._hostExpenseDetails.pop();
                            } catch (err) { console.error('同步删除明细失败:', err); }
                        }
                        record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                    }
                }
                handleCellChange(this);
            };
        });

        // 地址下拉
        $$('.address-select').forEach(sel => {
            sel.onchange = function() {
                const tr = this.closest('tr');
                const openBtn = tr.querySelector('.open-link');
                if (openBtn) openBtn.dataset.address = this.value;
                const col = this.dataset.col;
                const id = parseInt(this.dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) return;
                if (col === 'address') {
                    record.data.ip_info = record.data.ip_address || '';
                    renderTable(false);
                    saveRecord(record);
                }
                handleCellChange(this);
            };
        });

        // 服务商快速检索下拉
        $$('.provider-search-box').forEach(box => {
            const input = box.querySelector('.provider-search-input');
            const dropdown = box.querySelector('.provider-search-dropdown');
            if (!input || !dropdown) return;

            const refreshOptions = () => {
                const keyword = input.value.trim();
                const rect = input.getBoundingClientRect();
                dropdown.style.left = rect.left + 'px';
                dropdown.style.top = (rect.bottom + 2) + 'px';
                dropdown.style.width = Math.max(rect.width, 160) + 'px';
                const options = Array.from(dropdown.querySelectorAll('.provider-search-option'));
                let visibleCount = 0;
                options.forEach(option => {
                    const name = option.dataset.value || '';
                    const visible = providerMatchesKeyword(name, keyword);
                    option.style.display = visible ? 'flex' : 'none';
                    if (visible) visibleCount++;
                });
                const empty = dropdown.querySelector('.provider-search-empty');
                if (empty) empty.style.display = visibleCount === 0 ? 'block' : 'none';
                dropdown.classList.add('show');
            };

            const saveProviderValue = (value) => {
                const colKey = input.dataset.col;
                const id = parseInt(input.dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) return;
                record.data[colKey] = value;
                record._updated = true;
                input.value = value;
                updateFilterOptionsForCol(colKey);
                saveRecord(record);
            };

            input.addEventListener('focus', refreshOptions);
            input.addEventListener('input', refreshOptions);
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const firstVisible = Array.from(dropdown.querySelectorAll('.provider-search-option'))
                        .find(option => option.style.display !== 'none');
                    if (firstVisible) {
                        saveProviderValue(firstVisible.dataset.value || '');
                        dropdown.classList.remove('show');
                    }
                }
                if (e.key === 'Escape') dropdown.classList.remove('show');
            });
            input.addEventListener('blur', () => {
                setTimeout(() => dropdown.classList.remove('show'), 180);
            });
            dropdown.querySelectorAll('.provider-search-option').forEach(option => {
                option.addEventListener('mousedown', (e) => {
                    e.preventDefault();
                    saveProviderValue(option.dataset.value || '');
                    dropdown.classList.remove('show');
                });
            });
        });

        $$('.cell-input[data-col="ip_address"]').forEach(input => {
            input.onchange = function() {
                const id = parseInt(this.dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) return;
                record.data.ip_info = this.value.trim();
                // 不调用 renderTable，避免销毁 open-link 按钮。handleCellChange 会更新 data-ip。
                saveRecord(record);
            };
        });

        // open-link 用事件委托绑定（不依赖 bindTableEvents 重新绑定）
        // (已在 document 级别的 click 委托中处理，见下方)

        // IP信息交互（点击打开主机信息弹窗）
        $$('.ip-info-cell').forEach(cell => {
            cell.addEventListener('click', function() {
                const recordId = parseInt(this.dataset.id);
                openIpInfoModal(recordId);
            });
        });

        // 支出交互（独享/共享标签：点击直接打开主机支出明细弹窗；普通记账标签：旧逻辑切换编辑）
        $$('.expense-display').forEach(display => {
            display.addEventListener('click', function(e) {
                const parent = this.parentElement; // .expense-inline
                const id = parseInt(parent.dataset.id || parent.closest('tr').dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) return;
                // 独享/共享标签：无论有无明细，点击都打开弹窗
                if (!isSimpleTab()) {
                    openHostExpenseModal(id);
                    return;
                }
                // 普通记账标签：保持旧的"点击切换为编辑"逻辑（简单标签的支出列走 _expenseTotal 弹窗，不会走到这里）
                const input = parent.querySelector('.expense-input');
                const td = parent.closest('td');
                this.style.display = 'none';
                input.style.display = 'inline-block';
                td.classList.add('editing-cell');
                input.focus();
                input.select();
            });
        });

        $$('.expense-input').forEach(input => {
            const finishEditing = async () => {
                const parent = input.closest('.expense-inline');
                const display = parent.querySelector('.expense-display');
                const td = parent.closest('td');
                const id = parseInt(parent.closest('tr').dataset.id);
                const record = state.records.find(r => r.id === id);
                if (!record) return;

                const rawValue = input.value.trim();
                const oldRaw = record.data['expense'] || '0';
                record.data['expense'] = rawValue || '0';
                record._updated = true;

                const months = parseInt(record.data.months) || 0;
                const computed = Math.round(computeExpenseValue(rawValue, months));
                display.textContent = computed;

                input.style.display = 'none';
                display.style.display = 'inline';
                td.classList.remove('editing-cell');

                // 独享/共享标签：首次填入单价时，自动生成 months 笔明细
                if (!isSimpleTab()) {
                    const newUnitPrice = parseExpenseUnitPrice(rawValue);
                    const oldUnitPrice = parseExpenseUnitPrice(oldRaw);
                    if (newUnitPrice > 0 && oldUnitPrice <= 0 && months > 0) {
                        // 需要确保明细已加载
                        if (!record._hostExpenseDetails) {
                            try {
                                const resp = await API.get('/host-expense/by-record/' + id);
                                record._hostExpenseDetails = resp.details || [];
                                record._hostExpenseTotal = resp.total || 0;
                            } catch (err) { console.error('加载明细失败:', err); }
                        }
                        const detailCount = (record._hostExpenseDetails || []).length;
                        const needToAdd = months - detailCount;
                        if (needToAdd > 0) {
                            const d = new Date();
                            const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                            const hp = record.data.host_purchase || '';
                            const firstDate = /^\d{4}-\d{2}-\d{2}/.test(hp) ? hp.substring(0, 10) : today;
                            for (let i = 0; i < needToAdd; i++) {
                                try {
                                    const resp = await API.post('/host-expense', {
                                        record_id: id,
                                        unit_price: newUnitPrice,
                                        expense_date: i === 0 ? firstDate : today
                                    });
                                    if (!record._hostExpenseDetails) record._hostExpenseDetails = [];
                                    record._hostExpenseDetails.push({
                                        id: resp.id,
                                        unit_price: resp.unit_price,
                                        expense_date: resp.expense_date
                                    });
                                } catch (err) { console.error('自动生成明细失败:', err); }
                            }
                            record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                        }
                    }
                }

                saveRecord(record);
                updateFilterOptionsForCol('expense');
                renderTable(false);
            };

            input.addEventListener('blur', finishEditing);
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    finishEditing();
                }
                if (e.key === 'Escape') {
                    const parent = input.closest('.expense-inline');
                    const display = parent.querySelector('.expense-display');
                    const td = parent.closest('td');
                    const id = parseInt(parent.closest('tr').dataset.id);
                    const record = state.records.find(r => r.id === id);
                    const raw = record ? (record.data['expense'] || '') : '';
                    input.value = raw;
                    input.blur();
                }
            });
            input.addEventListener('focus', function() {
                const td = this.closest('td');
                if (td) td.classList.add('editing-cell');
            });
            input.addEventListener('blur', function() {
                const td = this.closest('td');
                if (td) td.classList.remove('editing-cell');
            });
        });

        // 收入交互（点击打开收入管理弹窗）
        $$('.fee-summary-cell:not(.expense-summary-cell)').forEach(cell => {
            cell.addEventListener('click', function() {
                const recordId = parseInt(this.dataset.id);
                openIncomeModal(recordId);
            });
        });
        // 支出交互（点击打开支出管理弹窗）
        $$('.expense-summary-cell').forEach(cell => {
            cell.addEventListener('click', function() {
                const recordId = parseInt(this.dataset.id);
                openExpenseModal(recordId);
            });
        });
    }

    function getTextInputCellsAll() {
        return $$('input.cell-input:not(.address-select):not(.months-input):not(.expense-input):not(.fee-input):not(.provider-search-input):not(.date-text-input)');
    }

    function doMultiPaste(ds, clipboardText) {
        const colKey = ds.colKey;
        const isDateCol = (colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'client_expire');
        const lines = clipboardText.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim() !== '');
        if (lines.length === 0) return;

        var rows = Array.from(document.querySelectorAll('#dataTable tbody tr[data-id]'));
        var startIdx = -1, endIdx = -1;
        for (var i = 0; i < rows.length; i++) {
            var rid = parseInt(rows[i].dataset.id);
            if (rid === ds.startRowId) startIdx = i;
            if (rid === ds.endRowId) endIdx = i;
        }
        if (startIdx === -1 || endIdx === -1) return;
        var minIdx = Math.min(startIdx, endIdx);
        var maxIdx = Math.max(startIdx, endIdx);
        const targetRowIds = [];
        for (var j = minIdx; j <= maxIdx; j++) {
            var rid2 = parseInt(rows[j].dataset.id);
            if (!isNaN(rid2)) targetRowIds.push(rid2);
        }
        if (targetRowIds.length === 0) return;

        // 保存原始数据到撤销栈
        const undoData = [];
        targetRowIds.forEach(rowId => {
            const record = state.records.find(r => r.id === rowId);
            if (record) {
                const item = {
                    recordId: rowId,
                    colKey: colKey,
                    oldValue: record.data[colKey]
                };
                if (colKey === 'host_purchase') item.oldHostExpire = record.data.host_expire;
                if (colKey === 'client_purchase') item.oldClientExpire = record.data.client_expire;
                undoData.push(item);
            }
        });
        state.undoStack.push({ type: 'multi_paste', data: undoData });

        let changed = 0;
        targetRowIds.forEach((rowId, index) => {
            // 单行复制：用同一内容填所有；多行：按行对应
            let value = lines.length === 1 ? lines[0].trim() : (index < lines.length ? lines[index].trim() : null);
            if (value === null) return;
            const record = state.records.find(r => r.id === rowId);
            if (!record) return;
            const col = state.columns.find(c => c.col_key === colKey);
            if (!col) return;
            // 跳过 readonly 列
            if (colKey === 'expense' || colKey === 'fee' || colKey === 'host_expire' || col.col_type === 'days_remaining' || colKey === 'is_expired') return;

            // 日期列：尝试解析多种格式
            if (isDateCol && value) {
                const parsed = parseDate(value);
                if (parsed) value = parsed;
            }

            if (record.data[colKey] === value) return; // 没有变化
            record.data[colKey] = value;
            record._updated = true;

            // 同步更新 input 的值（密码/日期）
            if (colKey === 'password') {
                const cell = document.querySelector(`.password-cell[data-id="${rowId}"][data-col="password"]`);
                if (cell) {
                    const input = cell.querySelector('.password-input');
                    const mask = cell.querySelector('.password-mask');
                    if (input) input.value = value;
                    if (mask) {
                        if (value) {
                            mask.textContent = '***';
                            mask.classList.remove('password-empty');
                        } else {
                            mask.textContent = '✎ 点击设置';
                            mask.classList.add('password-empty');
                        }
                    }
                }
            } else if (isDateCol) {
                const cell = document.querySelector(`.date-cell[data-id="${rowId}"][data-col="${colKey}"]`);
                if (cell) {
                    const input = cell.querySelector('.date-text-input');
                    const hiddenInput = cell.querySelector('.date-picker-hidden');
                    // 文本输入框显示 XXXX年XX月XX日，隐藏 date 输入框保持 YYYY-MM-DD
                    if (input) input.value = formatDisplayDate(value);
                    if (hiddenInput) hiddenInput.value = value;
                    cell.classList.toggle('date-empty', !value);
                }
            } else {
                const input = document.querySelector(`input.cell-input[data-col="${colKey}"][data-id="${rowId}"]`);
                if (input) input.value = value;
            }

            // 联动计算
            if (colKey === 'ip_address') record.data.ip_info = value;
            if (colKey === 'host_purchase') {
                const months = parseInt(record.data.months) || 0;
                record.data.host_expire = calcHostExpire(value, months);
            }
            saveRecord(record);
            changed++;
        });

        if (changed > 0) {
            setStatus('已粘贴 ' + changed + ' 条数据');
            $$('.cell-input.drag-selected, .password-cell.drag-selected, .date-cell.drag-selected').forEach(el => el.classList.remove('drag-selected'));
            window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: null, lastClickCol: null };
            // 重新渲染表格以更新联动列（如 open-link 按钮、host_expire 计算等）
            if (colKey === 'ip_address' || colKey === 'months' || colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'address' || isDateCol) {
                renderTable(false);
            }
        }
    }

    function doMultiDelete(ds) {
        const colKey = ds.colKey;
        const isDateCol = (colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'client_expire');
        if (ds.startRowId === null || ds.endRowId === null || !colKey) return;

        var rows = Array.from(document.querySelectorAll('#dataTable tbody tr[data-id]'));
        var startIdx = -1, endIdx = -1;
        for (var i = 0; i < rows.length; i++) {
            var rid = parseInt(rows[i].dataset.id);
            if (rid === ds.startRowId) startIdx = i;
            if (rid === ds.endRowId) endIdx = i;
        }
        if (startIdx === -1 || endIdx === -1) return;
        var minIdx = Math.min(startIdx, endIdx);
        var maxIdx = Math.max(startIdx, endIdx);
        const targetRowIds = [];
        for (var j = minIdx; j <= maxIdx; j++) {
            var rid2 = parseInt(rows[j].dataset.id);
            if (!isNaN(rid2)) targetRowIds.push(rid2);
        }
        if (targetRowIds.length === 0) return;

        const undoData = [];
        targetRowIds.forEach(rowId => {
            const record = state.records.find(r => r.id === rowId);
            if (record) {
                undoData.push({
                    recordId: rowId,
                    colKey: colKey,
                    oldValue: record.data[colKey]
                });
            }
        });
        state.undoStack.push({ type: 'multi_paste', data: undoData });

        let changed = 0;
        targetRowIds.forEach(rowId => {
            const record = state.records.find(r => r.id === rowId);
            if (!record) return;
            const col = state.columns.find(c => c.col_key === colKey);
            if (!col) return;
            if (colKey === 'expense' || colKey === 'fee' || colKey === 'host_expire' || col.col_type === 'days_remaining' || colKey === 'is_expired') return;

            if (record.data[colKey] === '' || record.data[colKey] === null || record.data[colKey] === undefined) return;
            record.data[colKey] = '';
            record._updated = true;

            if (colKey === 'password') {
                const cell = document.querySelector(`.password-cell[data-id="${rowId}"][data-col="password"]`);
                if (cell) {
                    const input = cell.querySelector('.password-input');
                    const mask = cell.querySelector('.password-mask');
                    if (input) input.value = '';
                    if (mask) {
                        mask.textContent = '✎ 点击设置';
                        mask.classList.add('password-empty');
                    }
                }
            } else if (isDateCol) {
                const cell = document.querySelector(`.date-cell[data-id="${rowId}"][data-col="${colKey}"]`);
                if (cell) {
                    const input = cell.querySelector('.date-text-input');
                    const hiddenInput = cell.querySelector('.date-picker-hidden');
                    if (input) input.value = '';
                    if (hiddenInput) hiddenInput.value = '';
                    cell.classList.add('date-empty');
                }
            } else {
                const input = document.querySelector(`input.cell-input[data-col="${colKey}"][data-id="${rowId}"]`);
                if (input) input.value = '';
            }

            if (colKey === 'ip_address') record.data.ip_info = '';
            saveRecord(record);
            changed++;
        });

        if (changed > 0) {
            setStatus('已删除 ' + changed + ' 条数据');
            $$('.cell-input.drag-selected, .password-cell.drag-selected, .date-cell.drag-selected').forEach(el => el.classList.remove('drag-selected'));
            window._dragSelect = { active: false, colKey: null, startRowId: null, endRowId: null, lastClickRowId: null, lastClickCol: null };
            if (colKey === 'ip_address' || colKey === 'months' || colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'address' || isDateCol) {
                renderTable(false);
            }
        }
    }

    function handleDateTextChange(input) {
        const colKey = input.dataset.col;
        const id = parseInt(input.dataset.id);
        let val = input.value.trim();
        const record = state.records.find(r => r.id === id);
        if (!record) return;

        const oldValue = record.data[colKey] !== undefined ? record.data[colKey] : '';

        // 尝试解析日期（支持多种格式）
        if (val) {
            const parsed = parseDate(val);
            if (parsed) {
                val = parsed;
            } else {
                // 解析失败，恢复旧值（显示格式）
                input.value = formatDisplayDate(oldValue);
                setStatus('⚠️ 日期格式无法识别，支持格式：YYYY-MM-DD、YYYY/MM/DD、YYYY年MM月DD日');
                return;
            }
        }

        // 更新输入框显示为 XXXX年XX月XX日 格式（非编辑状态）
        input.value = formatDisplayDate(val);

        if (record.data[colKey] === val) return;

        let oldHostExpire = null;
        let oldClientExpire = null;
        if (colKey === 'host_purchase') oldHostExpire = record.data.host_expire || null;
        if (colKey === 'client_purchase') oldClientExpire = record.data.client_expire || null;

        state.undoStack.push({
            type: 'cell_edit',
            recordId: id,
            colKey: colKey,
            oldValue: oldValue,
            newValue: val,
            oldHostExpire: oldHostExpire,
            oldClientExpire: oldClientExpire
        });

        record.data[colKey] = val;
        record._updated = true;
        if (colKey === 'host_purchase') {
            const months = parseInt(record.data.months) || 0;
            record.data.host_expire = calcHostExpire(val, months);
            // 同步首笔主机支出明细日期到 host_purchase
            if (record._hostExpenseDetails && record._hostExpenseDetails.length > 0) {
                const dateStr = /^\d{4}-\d{2}-\d{2}/.test(val) ? val.substring(0, 10) : null;
                if (dateStr) {
                    API.post('/host-expense/sync-first-date/' + record.id, { expense_date: dateStr })
                        .then(() => {
                            // 同步本地缓存
                            const sorted = [...record._hostExpenseDetails].sort((a, b) => {
                                const da = a.expense_date || '', db = b.expense_date || '';
                                if (da !== db) return da < db ? -1 : 1;
                                return a.id - b.id;
                            });
                            if (sorted[0]) sorted[0].expense_date = dateStr;
                        })
                        .catch(err => console.error('同步首笔明细日期失败:', err));
                }
            }
        }
        saveRecord(record);
        // 联动列需要重新渲染（剩余天数、是否过期等）
        if (colKey === 'host_purchase' || colKey === 'host_expire' || colKey === 'client_purchase' || colKey === 'client_expire') {
            renderTable(false);
        }
    }

    function handleCellChange(input) {
        const colKey = input.dataset.col;
        const id = parseInt(input.dataset.id);
        let val = input.value;
        const col = state.columns.find(c => c.col_key === colKey);
        if (!col) return;
        if (colKey === 'expense' || colKey === 'fee' || colKey === 'host_expire' || col.col_type === 'days_remaining' || colKey === 'is_expired') return;

        const record = state.records.find(r => r.id === id);
        if (!record) return;

        const oldValue = record.data[colKey] !== undefined ? record.data[colKey] : '';

        if (col.col_type === 'number') {
            if (val !== '' && !isNaN(val)) val = parseFloat(val);
            else val = 0;
        } else if (col.col_type === 'boolean') {
            if (val === 'true') val = true;
            else if (val === 'false') val = false;
            else val = null;
        }

        if (record.data[colKey] === val || (record.data[colKey] === undefined && val === '')) return;

        let oldHostExpire = null;
        let oldIpInfo = null;
        if (colKey === 'months') {
            oldHostExpire = record.data.host_expire || null;
        }
        if (colKey === 'ip_address') {
            oldIpInfo = record.data.ip_info || null;
        }

        state.undoStack.push({
            type: 'cell_edit',
            recordId: id,
            colKey: colKey,
            oldValue: oldValue,
            newValue: val,
            oldHostExpire: oldHostExpire,
            oldIpInfo: oldIpInfo
        });

        record.data[colKey] = val;
        record._updated = true;

        if (colKey === 'months') {
            const purchase = record.data.host_purchase;
            if (purchase) record.data.host_expire = calcHostExpire(purchase, val);
            else record.data.host_expire = '';
        }
        if (colKey === 'ip_address') record.data.ip_info = val;

        saveRecord(record);
        // 只有联动更新其他字段时才重新渲染，普通文本修改不渲染（避免输入框丢失焦点）
        // ip_address / domain 修改后只需更新 open-link 按钮的 data 属性，不需要重新渲染整个表格
        if (colKey === 'ip_address' || colKey === 'domain') {
            const tr = input.closest('tr');
            if (tr) {
                const openBtn = tr.querySelector('.open-link');
                if (openBtn) {
                    if (colKey === 'ip_address') openBtn.dataset.ip = val;
                    if (colKey === 'domain') openBtn.dataset.domain = val;
                }
            }
        } else if (colKey === 'months' || colKey === 'host_purchase' || colKey === 'client_purchase' || colKey === 'address') {
            renderTable(false);
        }
    }

    async function saveRecord(record) {
        if (!record || !record._updated) return;
        record._updated = false;
        state.pendingSaves.add(record.id);
        try {
            await API.put('/records/' + record.id, { data: record.data });
            updateTabCache(state.currentTabId);
            setStatus('保存成功');
        } catch (err) {
            setStatus('保存失败: ' + err.message);
            record._updated = true;
        } finally {
            state.pendingSaves.delete(record.id);
        }
    }

    async function flushPendingSaves() {
        if (state.pendingSaves.size === 0) return;
        setStatus('保存中...');
        // 找出所有标记为_updated但不在pendingSaves中的记录也一起保存
        const recordsToSave = state.records.filter(r => r._updated && !state.pendingSaves.has(r.id));
        const pendingIds = Array.from(state.pendingSaves);
        // 等待已经在进行中的保存
        let waited = 0;
        while (state.pendingSaves.size > 0 && waited < 50) {
            await new Promise(r => setTimeout(r, 100));
            waited++;
        }
        // 保存剩余未保存的
        for (const rec of recordsToSave) {
            await saveRecord(rec);
        }
    }

    function updateRowSelection() {
        $$('#tableBody tr').forEach(tr => {
            const id = parseInt(tr.dataset.id);
            if (state.selectedRows.has(id)) tr.classList.add('selected');
            else tr.classList.remove('selected');
        });
    }

    // --- 增删 ---}

    function showAddRowModal() {
        const modal = document.getElementById('addRowModal');
        const confirmBtn = document.getElementById('addRowConfirm');
        const cancelBtn = document.getElementById('addRowCancel');
        const closeBtn = document.getElementById('closeAddRowModal');
        const customInput = document.getElementById('addRowCustomCount');

        // 每次打开默认勾选第一个（添加1行）
        const radios = document.querySelectorAll('input[name="addRowCount"]');
        radios.forEach(r => { r.checked = r.value === '1'; });
        if (customInput) customInput.value = 3;

        modal.classList.add('show');

        const closeModal = () => {
            modal.classList.remove('show');
            confirmBtn.removeEventListener('click', onConfirm);
            cancelBtn.removeEventListener('click', closeModal);
            closeBtn.removeEventListener('click', closeModal);
            document.removeEventListener('keydown', onKeyDown);
        };

        const onConfirm = async () => {
            const checked = document.querySelector('input[name="addRowCount"]:checked');
            let count = 1;
            if (checked && checked.value === 'custom' && customInput) {
                let n = parseInt(customInput.value);
                if (isNaN(n) || n < 1) n = 1;
                if (n > 50) n = 50;
                count = n;
            } else {
                count = checked ? (parseInt(checked.value) || 1) : 1;
            }
            closeModal();
            await addRow(count);
        };

        const onKeyDown = (e) => {
            if (e.key === 'Enter') {
                // 如果光标在自定义输入框里 → Enter 直接确认
                if (document.activeElement && document.activeElement.id === 'addRowCustomCount') {
                    // 自动切换到 custom 选项再确认
                    const customRadio = document.querySelector('input[name="addRowCount"][value="custom"]');
                    if (customRadio) customRadio.checked = true;
                }
                e.preventDefault();
                onConfirm();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                closeModal();
            }
        };

        confirmBtn.addEventListener('click', onConfirm);
        cancelBtn.addEventListener('click', closeModal);
        closeBtn.addEventListener('click', closeModal);
        document.addEventListener('keydown', onKeyDown);

        confirmBtn.focus();
    }

    async function addRow(count = 1) {
        if (!state.currentTabId) return;
        try {
            setStatus(`添加 ${count} 行中...`);
            const now = new Date();
            const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            const nextMonth = getNextMonth(now);

            for (let i = 0; i < count; i++) {
                const data = {};
                state.columns.forEach(col => { data[col.col_key] = ''; });
                data.host_purchase = today;
                data.months = 1;
                data.host_expire = calcHostExpire(today, 1);
                data.client_purchase = today;
                data.client_expire = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, '0')}-${String(nextMonth.getDate()).padStart(2, '0')}`;
                data.expense = '0';
                data.fee = '';
                data.address = 'IP地址';

                const result = await API.post('/records', { tab_id: state.currentTabId, data });
                state.total++;

                state.undoStack.push({
                    type: 'add_row',
                    recordId: result.id
                });
            }

            // 跳转到最后一页
            state.page = Math.ceil(state.total / state.pageSize);
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('添加成功');
            // 滚动到最后一行，focus 最后一行的输入框（避免跳转到顶部）
            const rows = document.querySelectorAll('tr[data-id]');
            if (rows.length > 0) {
                const lastRow = rows[rows.length - 1];
                lastRow.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                const lastInput = lastRow.querySelector('.cell-input');
                if (lastInput) setTimeout(() => lastInput.focus(), 100);
            }
        } catch (err) { setStatus('添加失败: ' + err.message); }
    }

    async function deleteSelected() {
        const ids = Array.from(state.selectedRows);
        if (ids.length === 0) { setStatus('请选择行'); return; }

        const blocked = [];
        const deletable = [];
        ids.forEach(id => {
            const r = state.records.find(x => x.id === id);
            if (!r) return;
            const expenseTotal = r._hostExpenseTotal || r._expenseTotal || 0;
            const incomeTotal = r._incomeTotal || 0;
            if (expenseTotal !== 0 || incomeTotal !== 0) {
                blocked.push(id);
            } else {
                deletable.push(id);
            }
        });

        if (blocked.length > 0) {
            if (deletable.length === 0) {
                await showConfirm('存在支出或收入记录,不可以删除（支出和收入都为 0 才能删除）');
                return;
            }
            if (!await showConfirm(`选中的 ${ids.length} 条记录中，有 ${blocked.length} 条存在支出/收入记录将被跳过，确定删除剩余 ${deletable.length} 条？（只有支出和收入都为 0 才能删除）`)) return;
        } else {
            if (!await showConfirm(`确定删除 ${ids.length} 条记录吗？`)) return;
        }

        try {
            setStatus('删除中...');

            const deletedRecords = state.records
                .filter(r => deletable.includes(r.id))
                .map(r => ({ ...r, data: { ...r.data } }));

            state.undoStack.push({
                type: 'delete_rows',
                records: deletedRecords
            });

            const result = await API.post('/records/batch-delete', { ids: deletable });
            state.selectedRows.clear();
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus(result?.message || `已删除 ${deletable.length} 条记录`);
        } catch (err) { setStatus('删除失败: ' + err.message); }
    }

    // 导出/导入
    async function exportData() {
        if (state.records.length === 0) { setStatus('⚠️ 无数据'); return; }
        try {
            setStatus('🔄 导出中...');
            const visibleColumns = state.columns.filter(c => c.col_visible !== 0);
            if (typeof XLSX === 'undefined') await loadXLSX();
            const headers = visibleColumns.map(c => c.col_name);
            const rows = state.records.map(r => visibleColumns.map(c => r.data[c.col_key] ?? ''));
            const wsData = [headers, ...rows];
            const ws = XLSX.utils.aoa_to_sheet(wsData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, '记账数据');
            const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
            downloadFile(buf, `记账数据_${new Date().toISOString().slice(0,10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            setStatus('✅ 导出成功');
        } catch (err) { setStatus('❌ 导出失败: ' + err.message); }
    }

    function showExportClientInfoModal() {
        exportClientStatus.textContent = '';
        exportClientInfoModal.classList.add('show');
    }

    async function exportClientInfo() {
        const format = document.querySelector('input[name="exportClientFormat"]:checked')?.value || 'excel';
        const clientRecords = state.records;
        if (clientRecords.length === 0) {
            exportClientStatus.textContent = '⚠️ 没有客户数据';
            return;
        }

        const exportFields = [
            { key: 'ip_info', name: 'IP信息' },
            { key: 'client_purchase', name: '客户购买时间' },
            { key: 'client_expire', name: '客户到期时间' },
            { key: 'client_remaining', name: '客户剩余天数' },
            { key: 'client_name', name: '客户名' },
            { key: 'income_total', name: '单价/元' }
        ];

        try {
            // 严格按收入弹窗顶部单价（不走明细合计）
            const getIncomePrice = await buildIncomePriceMap();
            if (format === 'excel') {
                exportClientStatus.textContent = '🔄 导出中...';
                if (typeof XLSX === 'undefined') await loadXLSX();
                const headers = exportFields.map(f => f.name);
                const rows = clientRecords.map(r => {
                    return exportFields.map(f => {
                        if (f.key === 'client_remaining') {
                            const days = computeDaysRemaining(r.data.client_expire);
                            return days !== '' ? days + ' 天' : '';
                        }
                        if (f.key === 'client_purchase' || f.key === 'client_expire') {
                            return formatDisplayDate(r.data[f.key]);
                        }
                        if (f.key === 'income_total') {
                            const v = getIncomePrice(r.id);
                            if (v === '' || v === null || v === undefined) return '';
                            return Math.round(Number(v));
                        }
                        return r.data[f.key] ?? '';
                    });
                });
                const wsData = [headers, ...rows];
                const ws = XLSX.utils.aoa_to_sheet(wsData);
                const range = XLSX.utils.decode_range(ws['!ref']);
                for (let R = range.s.r; R <= range.e.r; ++R) {
                    for (let C = range.s.c; C <= range.e.c; ++C) {
                        const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!ws[cellAddress]) continue;
                        const cell = ws[cellAddress];
                        if (!cell.s) cell.s = {};
                        cell.s.alignment = { horizontal: 'center', vertical: 'center' };
                        if (R > 0 && exportFields[C].key === 'client_remaining') {
                            const days = computeDaysRemaining(clientRecords[R - 1].data.client_expire);
                            if (days <= 3) {
                                cell.s.font = { color: { rgb: 'DC143C' }, bold: true };
                            } else if (days <= 5) {
                                cell.s.font = { color: { rgb: 'FFA500' }, bold: true };
                            }
                        }
                    }
                }
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, '客户信息');
                const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellStyles: true });
                downloadFile(buf, `客户信息_${new Date().toISOString().slice(0,10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                exportClientStatus.textContent = '✅ 导出成功';
                setTimeout(() => exportClientInfoModal.classList.remove('show'), 1500);
            } else {
                exportClientStatus.textContent = '🔄 生成图片中...';
                await exportClientInfoAsImage(clientRecords, exportFields, getIncomePrice);
                exportClientStatus.textContent = '✅ 图片已复制到剪贴板';
                setTimeout(() => exportClientInfoModal.classList.remove('show'), 2000);
            }
        } catch (err) {
            exportClientStatus.textContent = '❌ 导出失败: ' + err.message;
        }
    }

    async function buildIncomePriceMap() {
        // 严格只取"收入弹窗顶部单价"，不取明细合计或其他地方：
        // 1) 数据库 record.data.income_unit_price（用户在收入弹窗顶部输入并持久化后的值）
        // 2) localStorage incomeLastAmount_*（旧版本兼容，同样是弹窗顶部单价的备份）
        // 顶部单价为空白 → 返回 ''（导出也空白，不取明细、不取 0）
        return (recordId) => {
            const r = state.records.find(x => x.id === recordId);
            // 1) 优先读数据库持久化字段
            if (r && r.data && r.data.income_unit_price !== undefined && r.data.income_unit_price !== '') {
                const n = parseFloat(r.data.income_unit_price);
                if (!isNaN(n)) return n;
            }
            // 2) localStorage 旧数据兼容
            try {
                const saved = localStorage.getItem('incomeLastAmount_' + state.userId + '_' + recordId);
                if (saved !== null && saved !== undefined && saved !== '') {
                    const n = parseFloat(saved);
                    if (!isNaN(n)) return n;
                }
            } catch(e) {}
            // 顶部单价为空白 → 返回 ''（不取明细，不取 0）
            return '';
        };
    }

    async function exportBill(format) {
        format = format || 'excel';
        const records = state.records;
        if (!records || records.length === 0) {
            setStatus('⚠️ 没有可导出的数据');
            return;
        }
        try {
            setStatus('🔄 生成账单中...');

            const now = new Date();
            const dateStr = `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`;

            const getBillPrice = await buildIncomePriceMap();

            function addOneMonth(dateStr) {
                if (!dateStr) return '';
                const d = new Date(dateStr);
                if (isNaN(d.getTime())) return dateStr;
                d.setMonth(d.getMonth() + 1);
                return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
            }

            const billFields = [
                { key: 'seq', name: '序号' },
                { key: 'ip_info', name: 'IP信息' },
                { key: 'client_purchase', name: '客户购买时间' },
                { key: 'client_expire', name: '客户到期时间' },
                { key: 'client_name', name: '客户名' },
                { key: 'price', name: '单价/元' }
            ];

            const headers = billFields.map(f => f.name);
            let totalAmount = 0;
            const dataRows = records
                .map((r, idx) => {
                    let rawPrice = getBillPrice(r.id);
                    let price;
                    if (rawPrice === '' || rawPrice === null || rawPrice === undefined) {
                        price = ''; // 空白输入框 → 导出空白（不显示0）
                    } else {
                        price = Math.round(Number(rawPrice));
                        totalAmount += price;
                    }
                    return [
                        idx + 1,
                        r.data.ip_info || r.data.ip_address || '',
                        formatDisplayDate(r.data.client_purchase),
                        addOneMonth(r.data.client_expire),
                        r.data.client_name || '',
                        price
                    ];
                });

            if (format === 'image') {
                await exportBillAsImage(headers, dataRows, totalAmount, dateStr);
                setStatus('✅ 账单图片导出成功');
                return;
            }

            if (typeof XLSX === 'undefined') await loadXLSX();

            const wsData = [
                [],
                ['JX网络工作室新开/续费账单'],
                [],
                headers,
                ...dataRows,
                [],
                ['', '', '', '', '总计', totalAmount],
                ['', '', '', '', `账单时间：${dateStr}`, '']
            ];

            const ws = XLSX.utils.aoa_to_sheet(wsData);

            ws['!merges'] = [
                { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } },
                { s: { r: dataRows.length + 4, c: 0 }, e: { r: dataRows.length + 4, c: 4 } }
            ];

            const colWidths = [
                { wch: 6 },
                { wch: 18 },
                { wch: 16 },
                { wch: 16 },
                { wch: 16 },
                { wch: 12 }
            ];
            ws['!cols'] = colWidths;

            const range = XLSX.utils.decode_range(ws['!ref']);
            for (let R = range.s.r; R <= range.e.r; ++R) {
                for (let C = range.s.c; C <= range.e.c; ++C) {
                    const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
                    if (!ws[cellAddress]) continue;
                    const cell = ws[cellAddress];
                    if (!cell.s) cell.s = {};
                    cell.s.alignment = { horizontal: 'center', vertical: 'center' };
                    if (R === 1) {
                        cell.s.font = { bold: true, size: 16 };
                    } else if (R === 3) {
                        cell.s.font = { bold: true };
                        cell.s.fill = { fgColor: { rgb: 'F0F0F0' } };
                    } else if (R === dataRows.length + 4) {
                        cell.s.font = { bold: true };
                    }
                }
            }

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, '账单');
            const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellStyles: true });
            downloadFile(buf, `账单_${now.toISOString().slice(0,10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            setStatus('✅ 账单导出成功');
        } catch (err) {
            setStatus('❌ 导出失败: ' + err.message);
        }
    }

    async function exportBillAsImage(headers, dataRows, totalAmount, dateStr) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const colWidths = [60, 220, 160, 160, 140, 100];
        const rowHeight = 36;
        const padding = 40;
        const titleHeight = 60;
        const headerHeight = 44;
        const totalHeight = 44;
        const dateHeight = 36;
        const tableWidth = colWidths.reduce((s, w) => s + w, 0);
        const totalRows = dataRows.length;
        canvas.width = tableWidth + padding * 2;
        canvas.height = padding * 2 + titleHeight + headerHeight + totalRows * rowHeight + totalHeight + dateHeight + 20;

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#303133';
        ctx.font = 'bold 20px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('JX网络工作室新开/续费账单', canvas.width / 2, padding + titleHeight / 2);

        const tableTop = padding + titleHeight + 10;
        ctx.fillStyle = '#f0f0f0';
        ctx.fillRect(padding, tableTop, tableWidth, headerHeight);
        ctx.fillStyle = '#303133';
        ctx.font = 'bold 13px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center';
        let x = padding;
        headers.forEach((h, i) => {
            ctx.fillText(h, x + colWidths[i] / 2, tableTop + headerHeight / 2);
            x += colWidths[i];
        });

        ctx.font = '13px "Microsoft YaHei", sans-serif';
        dataRows.forEach((row, ri) => {
            const y = tableTop + headerHeight + ri * rowHeight;
            if (ri % 2 === 1) {
                ctx.fillStyle = '#fafafa';
                ctx.fillRect(padding, y, tableWidth, rowHeight);
            }
            ctx.fillStyle = '#606266';
            ctx.textAlign = 'center';
            let xPos = padding;
            row.forEach((cell, ci) => {
                ctx.fillText(String(cell || ''), xPos + colWidths[ci] / 2, y + rowHeight / 2);
                xPos += colWidths[ci];
            });
        });

        const totalY = tableTop + headerHeight + totalRows * rowHeight;
        ctx.fillStyle = '#303133';
        ctx.font = 'bold 14px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText('总计', padding + tableWidth - colWidths[5] - 10, totalY + totalHeight / 2);
        ctx.textAlign = 'center';
        ctx.fillText(String(totalAmount), padding + tableWidth - colWidths[5] / 2, totalY + totalHeight / 2);

        ctx.font = '12px "Microsoft YaHei", sans-serif';
        ctx.fillStyle = '#909399';
        ctx.textAlign = 'right';
        ctx.fillText(`账单时间：${dateStr}`, padding + tableWidth - 10, totalY + totalHeight + dateHeight / 2 + 5);

        ctx.strokeStyle = '#ebeef5';
        ctx.lineWidth = 1;
        let lineY = tableTop;
        for (let i = 0; i <= totalRows + 1; i++) {
            ctx.beginPath();
            ctx.moveTo(padding, lineY);
            ctx.lineTo(padding + tableWidth, lineY);
            ctx.stroke();
            lineY += (i === 0 ? headerHeight : rowHeight);
        }
        let lineX = padding;
        for (let i = 0; i <= colWidths.length; i++) {
            ctx.beginPath();
            ctx.moveTo(lineX, tableTop);
            ctx.lineTo(lineX, tableTop + headerHeight + totalRows * rowHeight);
            ctx.stroke();
            if (i < colWidths.length) lineX += colWidths[i];
        }

        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
        if (navigator.clipboard && navigator.clipboard.write && window.ClipboardItem) {
            await navigator.clipboard.write([
                new ClipboardItem({ 'image/png': blob })
            ]);
        } else {
            throw new Error('当前浏览器不支持剪贴板图片复制，请使用 HTTPS 协议访问');
        }
    }

    async function exportClientInfoAsImage(clientRecords, exportFields, getPriceFn) {
        const headers = exportFields.map(f => f.name);
        const rows = clientRecords.map(r => {
            return exportFields.map(f => {
                if (f.key === 'client_remaining') {
                    const days = computeDaysRemaining(r.data.client_expire);
                    return days !== '' ? days + ' 天' : '';
                }
                if (f.key === 'client_purchase' || f.key === 'client_expire') {
                    return formatDisplayDate(r.data[f.key]);
                }
                if ((f.key === 'price' || f.key === 'income_total') && getPriceFn) {
                    const v = getPriceFn(r.id);
                    if (v === '' || v === null || v === undefined) return '';
                    return Math.round(Number(v));
                }
                if (f.key === 'ip_info') {
                    return r.data.ip_info || r.data.ip_address || '';
                }
                return r.data[f.key] ?? '';
            });
        });

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const padding = 20;
        const headerHeight = 40;
        const rowHeight = 30;
        const colPadding = 15;
        ctx.font = '13px -apple-system, BlinkMacSystemFont, sans-serif';

        const colWidths = exportFields.map((f, idx) => {
            ctx.font = 'bold 14px -apple-system, BlinkMacSystemFont, sans-serif';
            let maxWidth = ctx.measureText(f.name).width + colPadding * 2;
            ctx.font = '13px -apple-system, BlinkMacSystemFont, sans-serif';
            rows.forEach(row => {
                const w = ctx.measureText(String(row[idx])).width + colPadding * 2;
                maxWidth = Math.max(maxWidth, w);
            });
            return maxWidth + 20;
        });

        const totalWidth = colWidths.reduce((a, b) => a + b, 0) + padding * 2;
        const totalHeight = headerHeight + rows.length * rowHeight + padding * 2;

        canvas.width = totalWidth;
        canvas.height = totalHeight;

        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, totalWidth, totalHeight);
        ctx.strokeStyle = '#ddd';
        ctx.lineWidth = 1;

        let x = padding;
        ctx.fillStyle = '#f5f7fa';
        ctx.fillRect(x, padding, totalWidth - padding * 2, headerHeight);
        ctx.font = 'bold 14px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.fillStyle = '#333';
        colWidths.forEach((w, idx) => {
            const headerText = headers[idx];
            const textWidth = ctx.measureText(headerText).width;
            const textX = x + w / 2 - textWidth / 2;
            ctx.fillText(headerText, textX, padding + headerHeight / 2 + 5);
            ctx.strokeRect(x, padding, w, headerHeight);
            x += w;
        });

        rows.forEach((row, rowIdx) => {
            let x = padding;
            const y = padding + headerHeight + rowIdx * rowHeight;
            row.forEach((cell, colIdx) => {
                const colKey = exportFields[colIdx].key;
                const cellText = String(cell);
                if (colKey === 'client_remaining') {
                    const days = computeDaysRemaining(clientRecords[rowIdx].data.client_expire);
                    if (days <= 3) {
                        ctx.font = 'bold 13px -apple-system, BlinkMacSystemFont, sans-serif';
                        ctx.fillStyle = '#dc143c';
                    } else if (days <= 5) {
                        ctx.font = 'bold 13px -apple-system, BlinkMacSystemFont, sans-serif';
                        ctx.fillStyle = '#ffa500';
                    } else {
                        ctx.font = '13px -apple-system, BlinkMacSystemFont, sans-serif';
                        ctx.fillStyle = '#333';
                    }
                } else {
                    ctx.font = '13px -apple-system, BlinkMacSystemFont, sans-serif';
                    ctx.fillStyle = '#333';
                }
                const textWidth = ctx.measureText(cellText).width;
                const cellX = x + colWidths[colIdx] / 2 - textWidth / 2;
                const cellY = y + rowHeight / 2 + 4;
                ctx.fillText(cellText, cellX, cellY);
                ctx.strokeRect(x, y, colWidths[colIdx], rowHeight);
                x += colWidths[colIdx];
            });
        });

        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
        if (navigator.clipboard && navigator.clipboard.write && window.ClipboardItem) {
            await navigator.clipboard.write([
                new ClipboardItem({ 'image/png': blob })
            ]);
        } else {
            throw new Error('当前浏览器不支持剪贴板图片复制，请使用 HTTPS 协议访问');
        }
    }

    function showImportModal() { importModal.classList.add('show'); importFileInput.value = ''; importStatus.textContent = ''; }
    async function handleImport() {
        const file = importFileInput.files[0];
        if (!file) { importStatus.textContent = '⚠️ 请选择文件'; return; }
        importStatus.textContent = '🔄 读取中...';
        try {
            let records = [];
            if (file.name.endsWith('.csv')) {
                const text = await file.text();
                const lines = text.split('\n').filter(l => l.trim());
                if (lines.length < 2) throw new Error('CSV格式错误');
                const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
                const visibleColumns = state.columns.filter(c => c.col_visible !== 0);
                for (let i = 1; i < lines.length; i++) {
                    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
                    const data = {};
                    visibleColumns.forEach((col, idx) => { data[col.col_key] = values[idx] || ''; });
                    records.push(data);
                }
            } else {
                await loadXLSX();
                const arrayBuffer = await file.arrayBuffer();
                const workbook = XLSX.read(arrayBuffer, { type: 'array' });
                const sheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: '' });
                if (jsonData.length === 0) throw new Error('Excel为空');
                const headers = Object.keys(jsonData[0]);
                const visibleColumns = state.columns.filter(c => c.col_visible !== 0);
                const colMap = {};
                visibleColumns.forEach(col => {
                    const matched = headers.find(h => h === col.col_name || h === col.col_key);
                    if (matched) colMap[col.col_key] = matched;
                });
                records = jsonData.map(row => {
                    const data = {};
                    visibleColumns.forEach(col => {
                        const key = colMap[col.col_key];
                        data[col.col_key] = key ? row[key] : '';
                    });
                    return data;
                });
            }
            if (records.length === 0) throw new Error('无有效数据');
            importStatus.textContent = `🔄 导入 ${records.length} 条...`;
            await API.post('/records/import', { tab_id: state.currentTabId, records });
            invalidateCurrentTabCache();
            state.page = 1;
            await loadRecords(state.currentTabId);
            renderTable(false);
            importStatus.textContent = `✅ 成功导入 ${records.length} 条`;
            setTimeout(() => importModal.classList.remove('show'), 1500);
        } catch (err) { importStatus.textContent = '❌ 导入失败: ' + err.message; }
    }

    function loadXLSX() { return new Promise((resolve, reject) => {
        if (typeof XLSX !== 'undefined') { resolve(); return; }
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
        script.onload = resolve; script.onerror = reject;
        document.head.appendChild(script);
    }); }

    function downloadFile(content, filename, mimeType) {
        const blob = content instanceof ArrayBuffer ? new Blob([content], { type: mimeType }) : new Blob(['\uFEFF' + content], { type: mimeType + ';charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url; link.download = filename;
        document.body.appendChild(link); link.click();
        document.body.removeChild(link); URL.revokeObjectURL(url);
    }

    // --- 列管理 ---
    async function showColumnManager() {
        if (!state.currentTabId) { setStatus('⚠️ 请先选择一个标签'); return; }
        columnModal.classList.add('show');
        await renderColumnList();
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        if (tab) document.getElementById('columnModalTabName').textContent = tab.name;
    }

    async function renderColumnList() {
        const cols = state.columns;
        let html = '';
        cols.forEach(col => {
            const isIncome = col.is_income || 0;
            let incomeLabel = '';
            if (isIncome === 1) incomeLabel = '💰';
            else if (isIncome === 2) incomeLabel = '💸';
            html += `
                <div class="column-item" draggable="true" data-id="${col.id}">
                    <div class="col-info">
                        <span class="col-name-wrapper">
                            <strong class="col-name-display" data-id="${col.id}" style="cursor:pointer;" title="双击编辑列名">${escapeHtml(col.col_name)}</strong>
                            <input type="text" class="col-name-input" data-id="${col.id}" style="display:none;min-width:120px;padding:2px 4px;border:1px solid #4a6cf7;border-radius:4px;font-size:13px;" />
                        </span>
                        <span class="col-key">(${escapeHtml(col.col_key)})</span>
                        <button class="income-toggle ${isIncome === 1 ? 'active-income' : (isIncome === 2 ? 'active-expense' : '')}" data-id="${col.id}">${incomeLabel || '普通'}</button>
                        <span style="color:#999;font-size:12px;">${col.col_visible === 1 ? '👁️' : '🙈'}</span>
                    </div>
                    <div class="col-actions">
                        <button onclick="toggleColumnVisibility(${col.id}, ${col.col_visible})">${col.col_visible === 1 ? '隐藏' : '显示'}</button>
                        <button class="danger" onclick="deleteColumn(${col.id})">删除</button>
                    </div>
                </div>
            `;
        });
        columnList.innerHTML = html;

        const items = columnList.querySelectorAll('.column-item');
        items.forEach(item => {
            item.addEventListener('dragstart', function(e) {
                this.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', this.dataset.id);
            });
            item.addEventListener('dragend', function() {
                this.classList.remove('dragging');
                columnList.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
            });
            item.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                columnList.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
                this.classList.add('drag-over');
            });
            item.addEventListener('dragleave', function(e) {
                const rect = this.getBoundingClientRect();
                const y = e.clientY - rect.top;
                if (y < 0 || y > rect.height) {
                    this.classList.remove('drag-over');
                }
            });
            item.addEventListener('drop', async function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
                const targetId = parseInt(this.dataset.id);
                if (draggedId === targetId) return;

                const cols = state.columns;
                const draggedIndex = cols.findIndex(c => c.id === draggedId);
                const targetIndex = cols.findIndex(c => c.id === targetId);
                if (draggedIndex === -1 || targetIndex === -1) return;

                const rect = this.getBoundingClientRect();
                const y = e.clientY - rect.top;
                const insertBefore = y < rect.height / 2;

                const draggedCol = cols[draggedIndex];
                cols.splice(draggedIndex, 1);

                let newIndex = targetIndex;
                if (draggedIndex < targetIndex) {
                    newIndex = insertBefore ? targetIndex - 1 : targetIndex;
                } else {
                    newIndex = insertBefore ? targetIndex : targetIndex + 1;
                }
                if (newIndex < 0) newIndex = 0;
                if (newIndex > cols.length) newIndex = cols.length;
                cols.splice(newIndex, 0, draggedCol);

                const orderMap = {};
                cols.forEach((c, i) => { orderMap[c.id] = i; });
                try {
                    await API.post('/columns/reorder', { orderMap });
                    state.columns = cols;
                    updateTabCache(state.currentTabId);
                    renderColumnList();
                    renderTable(false);
                    setStatus('✅ 顺序已更新');
                } catch (err) {
                    setStatus('❌ 更新失败: ' + err.message);
                    await loadColumns(state.currentTabId);
                    renderColumnList();
                }
            });
        });

        columnList.querySelectorAll('.income-toggle').forEach(btn => {
            btn.addEventListener('click', async function() {
                const id = parseInt(this.dataset.id);
                const col = state.columns.find(c => c.id === id);
                if (!col) return;
                let newVal = (col.is_income || 0) + 1;
                if (newVal > 2) newVal = 0;
                try {
                    await API.put('/columns/' + id, { is_income: newVal });
                    col.is_income = newVal;
                    updateTabCache(state.currentTabId);
                    renderColumnList();
                    renderTable(false);
                    setStatus('✅ 标记已更新');
                } catch (err) { setStatus('❌ 更新失败: ' + err.message); }
            });
        });

        // 双击列名 → 编辑列名
        columnList.querySelectorAll('.col-name-display').forEach(display => {
            display.addEventListener('dblclick', function(e) {
                e.stopPropagation();
                const id = parseInt(this.dataset.id);
                const col = state.columns.find(c => c.id === id);
                if (!col) return;
                const wrapper = this.closest('.col-name-wrapper');
                if (!wrapper) return;
                const input = wrapper.querySelector('.col-name-input');
                if (!input) return;
                input.value = col.col_name;
                this.style.display = 'none';
                input.style.display = 'inline-block';
                input.focus();
                input.select();
            });
        });
        columnList.querySelectorAll('.col-name-input').forEach(input => {
            const saveEdit = async () => {
                const id = parseInt(input.dataset.id);
                const col = state.columns.find(c => c.id === id);
                if (!col) return;
                const wrapper = input.closest('.col-name-wrapper');
                const display = wrapper ? wrapper.querySelector('.col-name-display') : null;
                const newName = input.value.trim();
                if (!newName || newName === col.col_name) {
                    if (display) display.style.display = '';
                    input.style.display = 'none';
                    return;
                }
                try {
                    await API.put('/columns/' + id, { col_name: newName });
                    col.col_name = newName;
                    updateTabCache(state.currentTabId);
                    renderColumnList();
                    renderTable(false);
                    setStatus('✅ 列名已更新');
                } catch (err) {
                    setStatus('❌ 更新失败: ' + err.message);
                    if (display) {
                        display.textContent = escapeHtml(col.col_name);
                        display.style.display = '';
                    }
                    input.style.display = 'none';
                }
            };
            input.addEventListener('blur', saveEdit);
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
                else if (e.key === 'Escape') {
                    e.preventDefault();
                    const wrapper = input.closest('.col-name-wrapper');
                    const display = wrapper ? wrapper.querySelector('.col-name-display') : null;
                    if (display) display.style.display = '';
                    input.style.display = 'none';
                }
            });
        });
    }

    window.toggleColumnVisibility = async function(id, currentVisible) {
        try {
            await API.put('/columns/' + id, { col_visible: currentVisible === 1 ? 0 : 1 });
            await loadColumns(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderColumnList();
            renderTable(false);
            setStatus('✅ 列状态已更新');
        } catch (err) { setStatus('❌ 更新失败: ' + err.message); }
    };
    window.deleteColumn = async function(id) {
        if (!await showConfirm('确定删除此列吗？')) return;
        try {
            await API.delete('/columns/' + id);
            await loadColumns(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderColumnList();
            renderTable(false);
            setStatus('✅ 列已删除');
        } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
    };

    async function addColumn() {
        const name = newColName.value.trim();
        const type = newColType.value;
        if (!name) { setStatus('⚠️ 请输入列名称'); return; }
        if (!state.currentTabId) { setStatus('⚠️ 请先选择一个标签'); return; }

        const ts = Date.now();
        const rand = Math.random().toString(36).substring(2, 6);
        const key = `col_${ts}_${rand}`;

        try {
            const result = await API.post('/columns', {
                tab_id: state.currentTabId,
                col_key: key,
                col_name: name,
                col_type: type,
                is_income: 0
            });
            if (result.success) {
                newColName.value = '';
                await loadColumns(state.currentTabId);
                updateTabCache(state.currentTabId);
                renderColumnList();
                renderTable(false);
                setStatus('✅ 列添加成功');
            } else {
                setStatus('❌ 添加失败: ' + (result.error || '未知错误'));
            }
        } catch (err) { setStatus('❌ 添加失败: ' + err.message); }
    }

    // --- 条件格式管理 ---
    function openConditionalFormatModal() {
        if (!state.currentTabId) { setStatus('⚠️ 请先选择标签'); return; }
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        cfModalTabName.textContent = tab ? tab.name : '';
        // 默认显示条件管理标签页
        $$('.cf-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'conditional'));
        $$('.cf-tab-panel').forEach(p => {
            p.style.display = p.dataset.panel === 'conditional' ? 'block' : 'none';
        });
        // 初始化高亮色输入框
        const hlInput = document.getElementById('highlightColorInput');
        const hlPreview = document.getElementById('highlightColorPreview');
        if (hlInput) hlInput.value = state.focusHighlightColor;
        if (hlPreview) hlPreview.style.background = state.focusHighlightColor;
        renderCfColSelect();
        renderCfList();
        conditionalFormatModal.classList.add('show');
    }

    function renderCfColSelect() {
        const visibleCols = state.columns.filter(c => c.col_visible !== 0);
        cfColSelect.innerHTML = visibleCols.map(c =>
            `<option value="${escapeAttr(c.col_key)}">${escapeHtml(c.col_name)}</option>`
        ).join('');
    }

    function renderCfList() {
        const formats = state.conditionalFormats || [];
        if (formats.length === 0) {
            cfList.innerHTML = '<div style="text-align:center;color:#999;padding:20px 0;">暂无条件格式</div>';
            return;
        }
        const colMap = {};
        state.columns.forEach(c => { colMap[c.col_key] = c.col_name; });
        const conditionLabels = {
            contains: '包含', equals: '等于', not_equals: '不等于',
            greater_than: '大于', less_than: '小于',
            starts_with: '开头是', ends_with: '结尾是'
        };
        let html = '';
        formats.forEach(fmt => {
            const colName = colMap[fmt.col_key] || fmt.col_key;
            const condLabel = conditionLabels[fmt.condition_type] || fmt.condition_type;
            const style = [];
            if (fmt.text_color) style.push(`color:${fmt.text_color};`);
            if (fmt.is_bold) style.push('font-weight:bold;');
            html += `
                <div class="cf-item" data-id="${fmt.id}">
                    <div class="cf-item-info">
                        <span class="cf-item-col">${escapeHtml(colName)}</span>
                        <span class="cf-item-cond">${escapeHtml(condLabel)}</span>
                        <span class="cf-item-val">"${escapeHtml(fmt.condition_value)}"</span>
                        <span class="cf-item-preview" style="${style.join('')}">预览文字</span>
                    </div>
                    <div class="cf-item-actions">
                        <button class="cf-btn cf-edit" data-id="${fmt.id}" title="编辑">✎</button>
                        <button class="cf-btn cf-up" data-id="${fmt.id}" title="上移">↑</button>
                        <button class="cf-btn cf-down" data-id="${fmt.id}" title="下移">↓</button>
                        <button class="cf-btn cf-delete" data-id="${fmt.id}" title="删除">🗑️</button>
                    </div>
                </div>
            `;
        });
        cfList.innerHTML = html;
        $$('.cf-btn.cf-edit').forEach(btn => btn.addEventListener('click', () => editCfItem(parseInt(btn.dataset.id))));
        $$('.cf-btn.cf-up').forEach(btn => btn.addEventListener('click', () => moveCfItem(parseInt(btn.dataset.id), -1)));
        $$('.cf-btn.cf-down').forEach(btn => btn.addEventListener('click', () => moveCfItem(parseInt(btn.dataset.id), 1)));
        $$('.cf-btn.cf-delete').forEach(btn => btn.addEventListener('click', () => deleteCfItem(parseInt(btn.dataset.id))));
    }

    function editCfItem(id) {
        const fmt = (state.conditionalFormats || []).find(f => f.id === id);
        if (!fmt) return;
        state.editingCfId = id;
        cfColSelect.value = fmt.col_key;
        cfConditionSelect.value = fmt.condition_type;
        cfValueInput.value = fmt.condition_value || '';
        cfColorInput.value = fmt.text_color || '#dc143c';
        cfBoldCheck.checked = !!fmt.is_bold;
        cfAddBtn.textContent = '保存';
        cfCancelEditBtn.style.display = 'inline-block';
    }

    function cancelCfEdit() {
        state.editingCfId = null;
        cfValueInput.value = '';
        cfColorInput.value = '#dc143c';
        cfBoldCheck.checked = false;
        cfAddBtn.textContent = '添加';
        cfCancelEditBtn.style.display = 'none';
    }

    async function addConditionalFormat() {
        const col_key = cfColSelect.value;
        const condition_type = cfConditionSelect.value;
        const condition_value = cfValueInput.value.trim();
        const text_color = cfColorInput.value;
        const is_bold = cfBoldCheck.checked;
        const cfStatus = document.getElementById('cfStatus');
        if (!condition_value) { if (cfStatus) { cfStatus.textContent = '⚠️ 请输入条件值'; cfStatus.style.color = '#f56c6c'; setTimeout(() => cfStatus.textContent = '', 1500); } return; }

        try {
            if (state.editingCfId) {
                await API.put('/conditional-formats/' + state.editingCfId, {
                    col_key, condition_type, condition_value, text_color, is_bold
                });
                cancelCfEdit();
                await loadConditionalFormats(state.currentTabId);
                renderCfList();
                renderTable(false);
                if (cfStatus) {
                    cfStatus.textContent = '✅ 条件格式更新成功';
                    cfStatus.style.color = '#67c23a';
                    setTimeout(() => cfStatus.textContent = '', 1500);
                }
            } else {
                await API.post('/conditional-formats', {
                    tab_id: state.currentTabId,
                    col_key, condition_type, condition_value, text_color, is_bold
                });
                cfValueInput.value = '';
                await loadConditionalFormats(state.currentTabId);
                renderCfList();
                renderTable(false);
                if (cfStatus) {
                    cfStatus.textContent = '✅ 条件格式添加成功';
                    cfStatus.style.color = '#67c23a';
                    setTimeout(() => cfStatus.textContent = '', 1500);
                }
            }
        } catch (err) { if (cfStatus) { cfStatus.textContent = '❌ 操作失败: ' + err.message; cfStatus.style.color = '#f56c6c'; } }
    }

    async function moveCfItem(id, direction) {
        const formats = state.conditionalFormats || [];
        const idx = formats.findIndex(f => f.id === id);
        if (idx === -1) return;
        const newIdx = idx + direction;
        if (newIdx < 0 || newIdx >= formats.length) return;
        const newFormats = [...formats];
        [newFormats[idx], newFormats[newIdx]] = [newFormats[newIdx], newFormats[idx]];
        try {
            for (let i = 0; i < newFormats.length; i++) {
                if (newFormats[i].sort_order !== i) {
                    await API.put('/conditional-formats/' + newFormats[i].id, { sort_order: i });
                }
            }
            await loadConditionalFormats(state.currentTabId);
            renderCfList();
            renderTable(false);
        } catch (err) { setStatus('❌ 移动失败: ' + err.message); }
    }

    async function deleteCfItem(id) {
        try {
            await API.delete('/conditional-formats/' + id);
            await loadConditionalFormats(state.currentTabId);
            renderCfList();
            renderTable(false);
            setStatus('✅ 已删除');
        } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
    }

    // --- 视觉管理 - 标签页切换 ---
    function initVisualTabs() {
        $$('.cf-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                $$('.cf-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const target = tab.dataset.tab;
                $$('.cf-tab-panel').forEach(panel => {
                    panel.style.display = panel.dataset.panel === target ? 'block' : 'none';
                });
            });
        });

        const highlightInput = document.getElementById('highlightColorInput');
        const highlightPreview = document.getElementById('highlightColorPreview');
        if (highlightInput) {
            highlightInput.addEventListener('input', () => {
                if (highlightPreview) highlightPreview.style.background = highlightInput.value;
            });
        }

        $$('.preset-color-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const color = btn.dataset.color;
                if (highlightInput) highlightInput.value = color;
                if (highlightPreview) highlightPreview.style.background = color;
            });
        });

        const saveBtn = document.getElementById('saveHighlightBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                const color = document.getElementById('highlightColorInput').value;
                state.focusHighlightColor = color;
                try {
                    localStorage.setItem('focusHighlightColor_' + state.userId, color);
                } catch(e) {}
                applyTableHighlightStyle();
                const cfStatus = document.getElementById('cfStatus');
                if (cfStatus) {
                    cfStatus.textContent = '✅ 高亮色已保存';
                    cfStatus.style.color = '#67c23a';
                    setTimeout(() => cfStatus.textContent = '', 1500);
                }
            });
        }
    }

    function applyTableHighlightStyle() {
        let styleEl = document.getElementById('tableHighlightStyle');
        if (!styleEl) {
            styleEl = document.createElement('style');
            styleEl.id = 'tableHighlightStyle';
            document.head.appendChild(styleEl);
        }
        const color = state.focusHighlightColor;
        styleEl.textContent = `
            #dataTable tbody tr.focus-highlight > td {
                background-color: ${color} !important;
            }
        `;
    }

    // --- 统计 ---
    // --- 收入管理弹窗 ---
    function setIncomeStatus(text, color) {
        const el = document.getElementById('incomeStatus');
        if (!el) return;
        el.textContent = text || '';
        el.style.color = color || '#67c23a';
        el.style.display = 'block';
        el.style.opacity = '1';
        el.style.visibility = 'visible';
        if (text) {
            clearTimeout(setIncomeStatus._t);
            setIncomeStatus._t = setTimeout(() => {
                const e = document.getElementById('incomeStatus');
                if (e && (e.textContent === '已保存' || e.textContent === '添加成功' || e.textContent === '已删除')) e.textContent = '';
            }, 1500);
        }
    }

    // 保存收入/支出弹窗顶部单价到数据库 record.data（localStorage 仅作备份，数据库才可靠）
    async function persistModalTopPrice(recordId, key, value) {
        try {
            if (!recordId) return;
            const rec = state.records.find(r => r.id === recordId);
            if (!rec) return;
            const newData = { ...(rec.data || {}) };
            if (value === '' || value === null || value === undefined) {
                delete newData[key];
            } else {
                newData[key] = String(value);
            }
            // 写回内存缓存（避免下一次 loadRecords 之前读旧值）
            rec.data = newData;
            await API.put('/records/' + recordId, { data: newData });
        } catch (e) {
            console.warn('持久化单价失败:', e);
            // 失败静默，不影响用户体验；localStorage 仍会备份
        }
    }
    let _incomePriceSaveTimer = null;
    let _expensePriceSaveTimer = null;
    function scheduleIncomePricePersist() {
        if (!state.incomeRecordId) return;
        // 立即读值 + 立即写 localStorage 兜底
        const value = incomeAmountInput.value;
        const recId = state.incomeRecordId;
        try { localStorage.setItem('incomeLastAmount_' + state.userId + '_' + recId, value); } catch(e) {}
        // 防抖写数据库 — 捕获当时的 recordId 和 value，彻底避免竞态
        if (_incomePriceSaveTimer) clearTimeout(_incomePriceSaveTimer);
        _incomePriceSaveTimer = setTimeout(() => {
            persistModalTopPrice(recId, 'income_unit_price', value);
        }, 450);
    }
    function scheduleExpensePricePersist() {
        if (!state.expenseRecordId) return;
        const value = expenseAmountInput.value;
        const recId = state.expenseRecordId;
        try { localStorage.setItem('expenseLastAmount_' + state.userId + '_' + recId, value); } catch(e) {}
        if (_expensePriceSaveTimer) clearTimeout(_expensePriceSaveTimer);
        _expensePriceSaveTimer = setTimeout(() => {
            persistModalTopPrice(recId, 'expense_unit_price', value);
        }, 450);
    }

    function getModalRowLabel(recordId, mode) {
        let rec = state.records.find(r => r.id === recordId);
        // 若当前 records 缓存没命中，尝试从当前表格行解析（兜底）
        if (!rec) {
            const tr = document.querySelector(`tr[data-id="${recordId}"]`);
            if (tr) {
                const raw = tr.dataset.data;
                if (raw) {
                    try { rec = { data: JSON.parse(raw) }; } catch (e) { rec = null; }
                }
            }
        }
        if (!rec || !rec.data) return `#${recordId}`;
        const isSimple = isSimpleTab();
        let label = '';
        if (isSimple) {
            // 普通标签：显示"备注"内容
            label = rec.data.remark || '';
        } else {
            // 独享/共享标签：
            // 收入弹窗 → 客户名（客户备注）
            // 支出弹窗 → IP地址
            if (mode === 'income') {
                label = rec.data.client_name || '';
            } else {
                label = rec.data.ip_address || '';
            }
        }
        // 空值时显示列标识
        if (!label) {
            const colLabel = isSimple ? '备注' : (mode === 'income' ? '客户名' : 'IP地址');
            label = `#${recordId}（${colLabel}为空）`;
        }
        return label;
    }

    async function openIncomeModal(recordId) {
        state.incomeRecordId = recordId;
        state.incomeRecords = [];
        incomeTotalDisplay.textContent = '0';
        renderIncomeList();
        // 设置行标识
        if (incomeModalRow) incomeModalRow.textContent = getModalRowLabel(recordId, 'income');
        // 优先读数据库 record.data.income_unit_price，localStorage 仅作旧数据兜底
        const rec = state.records.find(r => r.id === recordId);
        let savedAmount = '';
        if (rec && rec.data && rec.data.income_unit_price !== undefined && rec.data.income_unit_price !== '') {
            savedAmount = String(rec.data.income_unit_price);
        } else {
            try {
                const fromLs = localStorage.getItem('incomeLastAmount_' + state.userId + '_' + recordId);
                savedAmount = fromLs || '';
            } catch(e) { savedAmount = ''; }
        }
        incomeAmountInput.value = savedAmount;
        incomeRemarkInput.value = '';
        incomeDateInput.value = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`;
        setIncomeStatus('');
        incomeModal.classList.add('show');
        await loadIncomeRecords(recordId);
    }

    async function loadIncomeRecords(recordId) {
        try {
            const records = await API.get('/income/by-record/' + recordId);
            state.incomeRecords = records || [];
            const total = state.incomeRecords.reduce((s, r) => s + (r.amount || 0), 0);
            incomeTotalDisplay.textContent = Math.round(total);
            renderIncomeList();
        } catch (err) { setIncomeStatus('加载失败: ' + err.message, '#f56c6c'); }
    }

    function renderIncomeList() {
        if (!incomeList) return;
        if (state.incomeRecords.length === 0) {
            incomeList.innerHTML = '<div style="text-align:center;color:#999;padding:16px;">暂无收入记录</div>';
            return;
        }
        const sort = state.incomeSort;
        const sorted = [...state.incomeRecords].sort((a, b) => {
            let va, vb;
            if (sort.field === 'amount') { va = a.amount; vb = b.amount; }
            else { va = a.income_date || ''; vb = b.income_date || ''; }
            if (va < vb) return sort.order === 'asc' ? -1 : 1;
            if (va > vb) return sort.order === 'asc' ? 1 : -1;
            return a.id - b.id;
        });
        const amountCls = sort.field === 'amount' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        const dateCls = sort.field === 'date' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        incomeList.innerHTML = `
            <div class="income-list-header">
                <span class="col-id">#ID</span>
                <span class="col-amount ${amountCls}" data-sort-field="amount">单价</span>
                <span class="col-date ${dateCls}" data-sort-field="date">日期</span>
                <span class="col-remark">备注</span>
                <span class="col-action">操作</span>
            </div>
        ` + sorted.map(r => `
            <div class="income-item" data-id="${r.id}">
                <div class="income-item-info">
                    <span class="item-id">#${r.id}</span>
                    <div class="item-amount"><input type="number" class="income-amount-input" data-id="${r.id}" value="${r.amount}" step="0.01" min="0" /></div>
                    <div class="item-date"><input type="date" class="income-date-input" data-id="${r.id}" value="${escapeAttr(r.income_date || '')}" /></div>
                    <div class="item-remark"><input type="text" class="income-remark-input" data-id="${r.id}" value="${escapeAttr(r.remark || '')}" placeholder="备注" /></div>
                    <button class="income-item-delete" data-id="${r.id}">删除</button>
                </div>
            </div>
        `).join('');

        incomeList.querySelectorAll('.income-amount-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const amount = parseFloat(this.value);
                if (isNaN(amount) || amount <= 0) { setIncomeStatus('金额无效', '#f56c6c'); return; }
                try {
                    await API.put('/income/' + id, { amount });
                    setIncomeStatus('已保存');
                    this._origValue = this.value;
                    await loadIncomeRecords(state.incomeRecordId);
                } catch (err) { setIncomeStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });

        incomeList.querySelectorAll('.income-date-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const date = this.value;
                if (!date) return;
                try {
                    await API.put('/income/' + id, { income_date: date });
                    setIncomeStatus('已保存');
                    this._origValue = this.value;
                    await loadIncomeRecords(state.incomeRecordId);
                } catch (err) { setIncomeStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('change', saveFn);
        });

        incomeList.querySelectorAll('.income-remark-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const remark = this.value;
                try {
                    await API.put('/income/' + id, { remark });
                    setIncomeStatus('已保存');
                    this._origValue = this.value;
                    await loadIncomeRecords(state.incomeRecordId);
                } catch (err) { setIncomeStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });

        incomeList.querySelectorAll('.income-item-delete').forEach(btn => {
            btn.addEventListener('click', async function() {
                const id = parseInt(this.dataset.id);
                if (!await showConfirm('确定删除此收入记录？')) return;
                try {
                    await API.delete('/income/' + id);
                    await loadIncomeRecords(state.incomeRecordId);
                    await loadRecords(state.currentTabId);
                    renderTable(false);
                    setIncomeStatus('已删除');
                } catch (err) { setIncomeStatus('删除失败: ' + err.message, '#f56c6c'); }
            });
        });
    }

    async function addIncomeRecord() {
        const amount = parseFloat(incomeAmountInput.value);
        const date = incomeDateInput.value;
        if (!amount || amount <= 0) { setIncomeStatus('请输入有效金额', '#f56c6c'); return; }
        if (!date) { setIncomeStatus('请选择日期', '#f56c6c'); return; }
        try {
            await API.post('/income', {
                record_id: state.incomeRecordId,
                tab_id: state.currentTabId,
                amount: amount,
                income_date: date,
                remark: incomeRemarkInput.value.trim()
            });
            // 双重保存：localStorage + 数据库（确保单价不会因清缓存/换设备丢失）
            try { localStorage.setItem('incomeLastAmount_' + state.userId + '_' + state.incomeRecordId, String(amount)); } catch(e) {}
            await persistModalTopPrice(state.incomeRecordId, 'income_unit_price', String(amount));
            incomeRemarkInput.value = '';
            await loadIncomeRecords(state.incomeRecordId);
            await loadRecords(state.currentTabId);
            renderTable(false);
            setIncomeStatus('添加成功');
        } catch (err) { setIncomeStatus('添加失败: ' + err.message, '#f56c6c'); }
    }

    // --- 支出管理弹窗 ---
    function setExpenseStatus(text, color) {
        const el = document.getElementById('expenseStatus');
        if (!el) return;
        el.textContent = text || '';
        el.style.color = color || '#67c23a';
        el.style.display = 'block';
        el.style.opacity = '1';
        el.style.visibility = 'visible';
        if (text) {
            clearTimeout(setExpenseStatus._t);
            setExpenseStatus._t = setTimeout(() => {
                const e = document.getElementById('expenseStatus');
                if (e && (e.textContent === '已保存' || e.textContent === '添加成功' || e.textContent === '已删除')) e.textContent = '';
            }, 1500);
        }
    }

    async function openExpenseModal(recordId) {
        state.expenseRecordId = recordId;
        state.expenseRecords = [];
        expenseTotalDisplay.textContent = '0';
        renderExpenseList();
        // 设置行标识
        if (expenseModalRow) expenseModalRow.textContent = getModalRowLabel(recordId, 'expense');
        // 优先读数据库 record.data.expense_unit_price，localStorage 仅作旧数据兜底
        const rec = state.records.find(r => r.id === recordId);
        let savedAmount = '';
        if (rec && rec.data && rec.data.expense_unit_price !== undefined && rec.data.expense_unit_price !== '') {
            savedAmount = String(rec.data.expense_unit_price);
        } else {
            try {
                const fromLs = localStorage.getItem('expenseLastAmount_' + state.userId + '_' + recordId);
                savedAmount = fromLs || '';
            } catch(e) { savedAmount = ''; }
        }
        expenseAmountInput.value = savedAmount;
        expenseRemarkInput.value = '';
        expenseDateInput.value = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`;
        setExpenseStatus('');
        expenseModal.classList.add('show');
        await loadExpenseRecords(recordId);
    }

    async function loadExpenseRecords(recordId) {
        try {
            const records = await API.get('/expense/by-record/' + recordId);
            state.expenseRecords = records || [];
            const total = state.expenseRecords.reduce((s, r) => s + (r.amount || 0), 0);
            expenseTotalDisplay.textContent = Math.round(total);
            renderExpenseList();
        } catch (err) { setExpenseStatus('加载失败: ' + err.message, '#f56c6c'); }
    }

    function renderExpenseList() {
        if (!expenseList) return;
        if (state.expenseRecords.length === 0) {
            expenseList.innerHTML = '<div style="text-align:center;color:#999;padding:16px;">暂无支出记录</div>';
            return;
        }
        const sort = state.expenseSort;
        const sorted = [...state.expenseRecords].sort((a, b) => {
            let va, vb;
            if (sort.field === 'amount') { va = a.amount; vb = b.amount; }
            else { va = a.expense_date || ''; vb = b.expense_date || ''; }
            if (va < vb) return sort.order === 'asc' ? -1 : 1;
            if (va > vb) return sort.order === 'asc' ? 1 : -1;
            return a.id - b.id;
        });
        const amountCls = sort.field === 'amount' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        const dateCls = sort.field === 'date' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        expenseList.innerHTML = `
            <div class="income-list-header">
                <span class="col-id">#ID</span>
                <span class="col-amount ${amountCls}" data-sort-field="amount">金额</span>
                <span class="col-date ${dateCls}" data-sort-field="date">日期</span>
                <span class="col-remark">备注</span>
                <span class="col-action">操作</span>
            </div>
        ` + sorted.map(r => `
            <div class="income-item expense-item" data-id="${r.id}">
                <div class="income-item-info">
                    <span class="item-id">#${r.id}</span>
                    <div class="item-amount"><input type="number" class="expense-amount-input" data-id="${r.id}" value="${r.amount}" step="0.01" min="0" /></div>
                    <div class="item-date"><input type="date" class="expense-date-input" data-id="${r.id}" value="${escapeAttr(r.expense_date || '')}" /></div>
                    <div class="item-remark"><input type="text" class="expense-remark-input" data-id="${r.id}" value="${escapeAttr(r.remark || '')}" placeholder="备注" /></div>
                    <button class="income-item-delete" data-id="${r.id}">删除</button>
                </div>
            </div>
        `).join('');

        expenseList.querySelectorAll('.expense-amount-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const amount = parseFloat(this.value);
                if (isNaN(amount) || amount < 0) { setExpenseStatus('金额无效', '#f56c6c'); return; }
                try {
                    await API.put('/expense/' + id, { amount });
                    setExpenseStatus('已保存');
                    this._origValue = this.value;
                    await loadExpenseRecords(state.expenseRecordId);
                } catch (err) { setExpenseStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });

        expenseList.querySelectorAll('.expense-date-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const date = this.value;
                if (!date) return;
                try {
                    await API.put('/expense/' + id, { expense_date: date });
                    setExpenseStatus('已保存');
                    this._origValue = this.value;
                    await loadExpenseRecords(state.expenseRecordId);
                } catch (err) { setExpenseStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('change', saveFn);
        });

        expenseList.querySelectorAll('.expense-remark-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                const id = parseInt(this.dataset.id);
                const remark = this.value;
                try {
                    await API.put('/expense/' + id, { remark });
                    setExpenseStatus('已保存');
                    this._origValue = this.value;
                    await loadExpenseRecords(state.expenseRecordId);
                } catch (err) { setExpenseStatus('保存失败: ' + err.message, '#f56c6c'); }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });

        expenseList.querySelectorAll('.income-item-delete').forEach(btn => {
            btn.addEventListener('click', async function() {
                const id = parseInt(this.dataset.id);
                if (!await showConfirm('确定删除此支出记录？')) return;
                try {
                    await API.delete('/expense/' + id);
                    await loadExpenseRecords(state.expenseRecordId);
                    await loadRecords(state.currentTabId);
                    renderTable(false);
                    setExpenseStatus('已删除');
                } catch (err) { setExpenseStatus('删除失败: ' + err.message, '#f56c6c'); }
            });
        });
    }

    async function addExpenseRecord() {
        const amount = parseFloat(expenseAmountInput.value);
        const date = expenseDateInput.value;
        if (!amount || amount <= 0) { setExpenseStatus('请输入有效金额', '#f56c6c'); return; }
        if (!date) { setExpenseStatus('请选择日期', '#f56c6c'); return; }
        try {
            await API.post('/expense', {
                record_id: state.expenseRecordId,
                tab_id: state.currentTabId,
                amount: amount,
                expense_date: date,
                remark: expenseRemarkInput.value.trim()
            });
            // 双重保存：localStorage + 数据库（确保单价不会因清缓存/换设备丢失）
            try { localStorage.setItem('expenseLastAmount_' + state.userId + '_' + state.expenseRecordId, String(amount)); } catch(e) {}
            await persistModalTopPrice(state.expenseRecordId, 'expense_unit_price', String(amount));
            expenseRemarkInput.value = '';
            await loadExpenseRecords(state.expenseRecordId);
            await loadRecords(state.currentTabId);
            renderTable(false);
            setExpenseStatus('添加成功');
        } catch (err) { setExpenseStatus('添加失败: ' + err.message, '#f56c6c'); }
    }

    // --- 主机支出明细弹窗（独享/共享标签） ---
    // 当前编辑的 record 引用缓存在 state.hostExpenseRecordId
    async function openHostExpenseModal(recordId) {
        state.hostExpenseRecordId = recordId;
        state.hostExpenseDetails = [];
        renderHostExpenseList();
        updateHostExpenseTotalDisplay();
        // 设置行标识
        if (hostExpenseModalRow) hostExpenseModalRow.textContent = getModalRowLabel(recordId, 'expense');
        const record = state.records.find(r => r.id === recordId);
        if (!record) return;

        // 单价 / 附加 / 备注输入框：从 record.data 独立字段读取（与外面支出列分离）
        hostExpenseUnitPriceInput.value = record.data.host_expense_unit_price ?? '';
        hostExpenseExtraInput.value = record.data.host_expense_extra ?? '';
        hostExpenseRemarkInput.value = record.data.host_expense_remark || '';
        hostExpenseStatus.textContent = '';
        hostExpenseModal.classList.add('show');
        await loadHostExpenseDetails(recordId);
    }

    async function loadHostExpenseDetails(recordId) {
        try {
            const data = await API.get('/host-expense/by-record/' + recordId);
            const details = (data && data.details) || [];
            state.hostExpenseDetails = details;
            // 同步到 record 缓存，避免渲染时再次请求
            const record = state.records.find(r => r.id === recordId);
            if (record) {
                record._hostExpenseDetails = details;
                record._hostExpenseTotal = (data && data.total) || 0;
            }
            renderHostExpenseList();
            updateHostExpenseTotalDisplay();
        } catch (err) {
            hostExpenseStatus.textContent = '加载失败: ' + err.message;
            hostExpenseStatus.style.color = '#f56c6c';
        }
    }

    function updateHostExpenseTotalDisplay() {
        const sum = (state.hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
        const extra = parseFloat(hostExpenseExtraInput.value) || 0;
        hostExpenseTotalDisplay.textContent = Math.round(sum + extra);
    }

    function renderHostExpenseList() {
        if (!hostExpenseList) return;
        const details = state.hostExpenseDetails || [];
        if (details.length === 0) {
            hostExpenseList.innerHTML = '<div style="text-align:center;color:#999;padding:16px;">暂无明细，点击"+月数"或"+ 添加明细"创建</div>';
            return;
        }
        const sort = state.hostExpenseSort;
        const sorted = [...details].sort((a, b) => {
            let va, vb;
            if (sort.field === 'amount') { va = a.unit_price; vb = b.unit_price; }
            else { va = a.expense_date || ''; vb = b.expense_date || ''; }
            if (va < vb) return sort.order === 'asc' ? -1 : 1;
            if (va > vb) return sort.order === 'asc' ? 1 : -1;
            return a.id - b.id;
        });
        const amountCls = sort.field === 'amount' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        const dateCls = sort.field === 'date' ? (sort.order === 'asc' ? 'col-sort-asc' : 'col-sort-desc') : '';
        hostExpenseList.innerHTML = `
            <div class="income-list-header">
                <span class="col-id">#ID</span>
                <span class="col-amount ${amountCls}" data-sort-field="amount">单价</span>
                <span class="col-date ${dateCls}" data-sort-field="date">日期</span>
                <span class="col-remark">备注</span>
                <span class="col-action">操作</span>
            </div>
        ` + sorted.map((d, idx) => `
            <div class="income-item expense-item" data-id="${d.id}">
                <div class="income-item-info">
                    <span class="item-id">#${idx + 1}</span>
                    <div class="item-amount"><input type="number" class="host-expense-price-input" data-id="${d.id}" value="${d.unit_price}" step="0.01" min="0" /></div>
                    <div class="item-date"><input type="date" class="host-expense-date-input" data-id="${d.id}" value="${escapeAttr(d.expense_date || '')}" /></div>
                    <div class="item-remark"><input type="text" class="host-expense-remark-input" data-id="${d.id}" value="${escapeAttr(d.remark || '')}" placeholder="备注" /></div>
                    <button class="income-item-delete host-expense-delete" data-id="${d.id}">删除</button>
                </div>
            </div>
        `).join('');

        hostExpenseList.querySelectorAll('.host-expense-price-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                if (this.value === this._origValue) return;
                const id = parseInt(this.dataset.id);
                const price = parseFloat(this.value);
                if (isNaN(price) || price < 0) { hostExpenseStatus.textContent = '单价无效'; hostExpenseStatus.style.color = '#f56c6c'; return; }
                try {
                    await API.put('/host-expense/' + id, { unit_price: price });
                    const d = (state.hostExpenseDetails || []).find(x => x.id === id);
                    if (d) d.unit_price = price;
                    updateHostExpenseTotalDisplay();
                    hostExpenseStatus.textContent = '已保存';
                    hostExpenseStatus.style.color = '#67c23a';
                    this._origValue = this.value;
                    setTimeout(() => { if (hostExpenseStatus.textContent === '已保存') hostExpenseStatus.textContent = ''; }, 1500);
                } catch (err) { hostExpenseStatus.textContent = '保存失败: ' + err.message; hostExpenseStatus.style.color = '#f56c6c'; }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });
        hostExpenseList.querySelectorAll('.host-expense-date-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                if (this.value === this._origValue) return;
                const id = parseInt(this.dataset.id);
                const date = this.value;
                if (!date) return;
                try {
                    await API.put('/host-expense/' + id, { expense_date: date });
                    const d = (state.hostExpenseDetails || []).find(x => x.id === id);
                    if (d) d.expense_date = date;
                    hostExpenseStatus.textContent = '已保存';
                    hostExpenseStatus.style.color = '#67c23a';
                    this._origValue = this.value;
                    setTimeout(() => { if (hostExpenseStatus.textContent === '已保存') hostExpenseStatus.textContent = ''; }, 1500);
                } catch (err) { hostExpenseStatus.textContent = '保存失败: ' + err.message; hostExpenseStatus.style.color = '#f56c6c'; }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('change', saveFn);
        });
        hostExpenseList.querySelectorAll('.host-expense-remark-input').forEach(inp => {
            inp._origValue = inp.value;
            inp.addEventListener('focus', function() { this._origValue = this.value; });
            const saveFn = async function() {
                if (this.value === this._origValue) return;
                const id = parseInt(this.dataset.id);
                const remark = this.value;
                try {
                    await API.put('/host-expense/' + id, { remark });
                    const d = (state.hostExpenseDetails || []).find(x => x.id === id);
                    if (d) d.remark = remark;
                    hostExpenseStatus.textContent = '已保存';
                    hostExpenseStatus.style.color = '#67c23a';
                    this._origValue = this.value;
                    setTimeout(() => { if (hostExpenseStatus.textContent === '已保存') hostExpenseStatus.textContent = ''; }, 1500);
                } catch (err) { hostExpenseStatus.textContent = '保存失败: ' + err.message; hostExpenseStatus.style.color = '#f56c6c'; }
            };
            inp.addEventListener('blur', saveFn);
            inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); this.blur(); } });
        });
        hostExpenseList.querySelectorAll('.host-expense-delete').forEach(btn => {
            btn.addEventListener('click', async function() {
                const id = parseInt(this.dataset.id);
                if (!await showConfirm('确定删除此笔明细？对应月数会自动 -1')) return;
                try {
                    await API.delete('/host-expense/' + id);
                    const record = state.records.find(r => r.id === state.hostExpenseRecordId);
                    if (record) {
                        let m = parseInt(record.data.months) || 0;
                        if (m > 0) {
                            record.data.months = m - 1;
                            if (record.data.host_purchase) {
                                record.data.host_expire = calcHostExpire(record.data.host_purchase, record.data.months);
                            }
                            record._updated = true;
                            saveRecord(record);
                        }
                    }
                    await loadHostExpenseDetails(state.hostExpenseRecordId);
                    await loadRecords(state.currentTabId);
                    renderTable(false);
                    hostExpenseStatus.textContent = '已删除';
                    hostExpenseStatus.style.color = '#67c23a';
                    setTimeout(() => hostExpenseStatus.textContent = '', 1200);
                } catch (err) { hostExpenseStatus.textContent = '删除失败: ' + err.message; }
            });
        });
    }

    // 保存单价 / 附加 / 备注配置（光标离开自动保存）
    async function saveHostExpenseConfig(field) {
        const record = state.records.find(r => r.id === state.hostExpenseRecordId);
        if (!record) return;
        const oldUnitPrice = parseFloat(record.data.host_expense_unit_price) || 0;
        const rawUnitPrice = hostExpenseUnitPriceInput.value.trim();
        const unitPrice = rawUnitPrice === '' ? 0 : (parseFloat(rawUnitPrice) || 0);
        const rawExtra = hostExpenseExtraInput.value.trim();
        const extra = rawExtra === '' ? 0 : (parseFloat(rawExtra) || 0);
        const remark = hostExpenseRemarkInput.value;
        record.data.host_expense_unit_price = unitPrice;
        record.data.host_expense_extra = extra;
        record.data.host_expense_remark = remark;
        // 同步 expense 字段，保证页面刷新时回退公式计算正确
        record.data.expense = buildExpenseString(unitPrice, extra);
        record._updated = true;
        try {
            await saveRecord(record);
            await API.put('/host-expense/record-config/' + state.hostExpenseRecordId, {
                unit_price: unitPrice,
                extra: extra,
                remark: remark
            });

            // 首次填入单价时，自动补齐 months 笔明细
            const months = parseInt(record.data.months) || 0;
            if (unitPrice > 0 && oldUnitPrice <= 0 && months > 0) {
                if (!record._hostExpenseDetails) {
                    const resp = await API.get('/host-expense/by-record/' + state.hostExpenseRecordId);
                    record._hostExpenseDetails = resp.details || [];
                    record._hostExpenseTotal = resp.total || 0;
                }
                const detailCount = (record._hostExpenseDetails || []).length;
                const needToAdd = months - detailCount;
                if (needToAdd > 0) {
                    const d = new Date();
                    const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                    const hp = record.data.host_purchase || '';
                    for (let i = 0; i < needToAdd; i++) {
                        const currentCount = (record._hostExpenseDetails || []).length;
                        let useDate;
                        if (currentCount === 0) {
                            useDate = /^\d{4}-\d{2}-\d{2}/.test(hp) ? hp.substring(0, 10) : today;
                        } else {
                            useDate = calcHostExpire(hp || today, currentCount);
                        }
                        try {
                            const resp = await API.post('/host-expense', {
                                record_id: state.hostExpenseRecordId,
                                unit_price: unitPrice,
                                expense_date: useDate
                            });
                            record._hostExpenseDetails.push({
                                id: resp.id,
                                unit_price: resp.unit_price,
                                expense_date: resp.expense_date
                            });
                        } catch (err) { console.error('自动补齐明细失败:', err); }
                    }
                    record._hostExpenseTotal = (record._hostExpenseDetails || []).reduce((s, d) => s + (parseFloat(d.unit_price) || 0), 0);
                    await loadHostExpenseDetails(state.hostExpenseRecordId);
                }
            }

            updateHostExpenseTotalDisplay();
            renderTable(false);
            hostExpenseStatus.textContent = '已保存';
            hostExpenseStatus.style.color = '#67c23a';
            setTimeout(() => hostExpenseStatus.textContent = '', 1200);
        } catch (err) {
            hostExpenseStatus.textContent = '保存失败: ' + err.message;
            hostExpenseStatus.style.color = '#f56c6c';
        }
    }

    // 手动添加一笔明细（使用当前单价、附加、备注输入框的值，日期默认今天）
    async function addHostExpenseDetailManually() {
        const record = state.records.find(r => r.id === state.hostExpenseRecordId);
        if (!record) return;
        const rawUnitPrice = hostExpenseUnitPriceInput.value.trim();
        const unitPrice = rawUnitPrice === '' ? NaN : parseFloat(rawUnitPrice);
        if (isNaN(unitPrice) || unitPrice < 0) {
            hostExpenseStatus.textContent = '请先填入有效单价';
            hostExpenseStatus.style.color = '#f56c6c';
            return;
        }
        const d = new Date();
        const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        try {
            await API.post('/host-expense', {
                record_id: state.hostExpenseRecordId,
                unit_price: unitPrice,
                expense_date: today,
                remark: hostExpenseRemarkInput.value || ''
            });
            let m = parseInt(record.data.months) || 0;
            record.data.months = m + 1;
            if (record.data.host_purchase) {
                record.data.host_expire = calcHostExpire(record.data.host_purchase, record.data.months);
            }
            record._updated = true;
            await saveRecord(record);
            await loadHostExpenseDetails(state.hostExpenseRecordId);
            await loadRecords(state.currentTabId);
            renderTable(false);
            hostExpenseStatus.textContent = '已添加明细';
            hostExpenseStatus.style.color = '#67c23a';
            setTimeout(() => hostExpenseStatus.textContent = '', 1200);
        } catch (err) {
            hostExpenseStatus.textContent = '添加失败: ' + err.message;
            hostExpenseStatus.style.color = '#f56c6c';
        }
    }

    // --- IP信息弹窗（联动主机管理） ---
    async function openIpInfoModal(recordId) {
        const record = state.records.find(r => r.id === recordId);
        if (!record) return;

        const ipAddr = record.data.ip_address || '';
        const clientName = record.data.client_name || '';
        const password = record.data.password || '';

        // 尝试查找已保存的主机信息
        let savedHost = null;
        if (ipAddr) {
            try {
                savedHost = await API.get(`/hosts/by-ip/${encodeURIComponent(ipAddr)}`);
            } catch (e) { /* 忽略 */ }
        }

        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:480px;">
                <div class="modal-header">
                    <h2>🔗 IP信息管理</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>主机名称（取自客户名）</label><input type="text" id="ipInfoName" value="${escapeAttr(clientName)}" placeholder="主机名称" /></div>
                    <div class="input-group"><label>主机地址（取自IP地址）</label><input type="text" id="ipInfoHost" value="${escapeAttr(ipAddr)}" placeholder="IP地址" /></div>
                    <div class="input-group"><label>密码（取自表格密码列）</label><input type="password" id="ipInfoPwd" value="${escapeAttr(password)}" placeholder="密码" /></div>
                    <div class="input-group"><label>端口</label><input type="number" id="ipInfoPort" value="${savedHost ? savedHost.port : 22}" placeholder="22" /></div>
                    <div class="input-group"><label>用户名</label><input type="text" id="ipInfoUser" value="${savedHost ? escapeAttr(savedHost.username) : ''}" placeholder="root" /></div>
                    <div class="input-group"><label>备注</label><input type="text" id="ipInfoRemark" value="${savedHost ? escapeAttr(savedHost.remark || '') : ''}" placeholder="可选" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="ipInfoSaveBtn">💾 保存</button>
                        <button class="tool-btn" id="ipInfoSaveConnBtn" style="background:#67c23a;color:#fff;">🔌 保存并连接</button>
                        <button class="tool-btn cancel-ip-info-btn">取消</button>
                    </div>
                    <span id="ipInfoStatus" style="color:#67c23a;display:block;margin-top:8px;"></span>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        const closeBtn = overlay.querySelector('.modal-close');
        const cancelBtn = overlay.querySelector('.cancel-ip-info-btn');
        const saveBtn = overlay.querySelector('#ipInfoSaveBtn');
        const saveConnBtn = overlay.querySelector('#ipInfoSaveConnBtn');
        const status = overlay.querySelector('#ipInfoStatus');

        function closeModal() { overlay.remove(); }

        closeBtn.onclick = closeModal;
        cancelBtn.onclick = closeModal;
        overlay.onclick = (e) => { if (e.target === overlay) closeModal(); };

        async function saveHost() {
            const name = overlay.querySelector('#ipInfoName').value.trim();
            const host = overlay.querySelector('#ipInfoHost').value.trim();
            const pwd = overlay.querySelector('#ipInfoPwd').value.trim();
            const port = parseInt(overlay.querySelector('#ipInfoPort').value) || 22;
            const username = overlay.querySelector('#ipInfoUser').value.trim();
            const remark = overlay.querySelector('#ipInfoRemark').value.trim();

            if (!host) { status.style.color = '#f56c6c'; status.textContent = '主机地址不能为空'; return null; }
            if (!username) { status.style.color = '#f56c6c'; status.textContent = '用户名不能为空'; return null; }

            try {
                if (savedHost && savedHost.id) {
                    // 编辑时：只有输入了密码才更新密码字段，否则保留原有密码
                    const body = { name: name || host, host, port, username, remark };
                    if (pwd) body.password = pwd;
                    await API.put(`/hosts/${savedHost.id}`, body);
                    status.style.color = '#67c23a';
                    status.textContent = '✅ 已更新主机信息';
                    return { id: savedHost.id, name: name || host, host, port, username };
                } else {
                    const data = await API.post('/hosts', { name: name || host, host, port, username, password: pwd, remark });
                    if (data.success) {
                        status.style.color = '#67c23a';
                        status.textContent = '✅ 主机已保存';
                        return { id: data.id, name: name || host, host, port, username };
                    } else {
                        status.style.color = '#f56c6c';
                        status.textContent = data.error || '保存失败';
                        return null;
                    }
                }
            } catch (err) {
                status.style.color = '#f56c6c';
                status.textContent = '保存失败: ' + err.message;
                return null;
            }
        }

        saveBtn.onclick = async () => {
            const result = await saveHost();
            if (result) {
                setTimeout(closeModal, 800);
                await loadHosts();
            }
        };

        saveConnBtn.onclick = async () => {
            const result = await saveHost();
            if (result) {
                closeModal();
                $$('.menu-item').forEach(i => i.classList.remove('active'));
                const hostMenu = document.querySelector('.menu-item[data-view="hosts"]');
                if (hostMenu) hostMenu.classList.add('active');
                $$('.view-panel').forEach(p => p.classList.remove('active'));
                const target = document.getElementById('view-hosts');
                if (target) target.classList.add('active');
                await loadHosts();
                await loadCommandFolders();
                setTimeout(() => connectSSH(result), 300);
            }
        };
    }

    // --- 全标签财务统计 ---
    async function getAllTabRecordsForStats() {
        await flushPendingSaves();
        const all = [];
        // 并行加载所有标签的全部记录（pageSize=0 获取全部）
        const recordPromises = state.tabs.map(tab =>
            API.get('/records?tabId=' + tab.id + '&pageSize=0')
                .then(result => {
                    const records = result.records || result || [];
                    records.forEach(record => all.push({ ...record, tabId: tab.id, tabName: tab.name }));
                })
                .catch(() => {})
        );
        // 加载收入和支出明细（用于按月统计，不重复累加 _incomeTotal/_expenseTotal）
        const incomePromises = state.tabs.map(tab =>
            API.get('/income/by-tab/' + tab.id).catch(() => [])
        );
        const expensePromises = state.tabs.map(tab =>
            API.get('/expense/by-tab/' + tab.id).catch(() => [])
        );

        const [_, incomeResults, expenseResults] = await Promise.all([
            Promise.all(recordPromises),
            Promise.all(incomePromises),
            Promise.all(expensePromises)
        ]);

        // 匹配收入明细到记录（仅用于按月统计，不修改 _incomeTotal）
        incomeResults.forEach((incomes, idx) => {
            (incomes || []).forEach(inc => {
                const rec = all.find(r => r.id === inc.record_id);
                if (rec) {
                    if (!rec._incomes) rec._incomes = [];
                    rec._incomes.push(inc);
                }
            });
        });
        // 匹配支出明细到记录（仅用于按月统计，不修改 _expenseTotal）
        expenseResults.forEach((expenses, idx) => {
            (expenses || []).forEach(exp => {
                const rec = all.find(r => r.id === exp.record_id);
                if (rec) {
                    if (!rec._expenses) rec._expenses = [];
                    rec._expenses.push(exp);
                }
            });
        });
        return all;
    }

    function getStatsDate(record) {
        const dateVal = record.data.host_purchase || record.data.client_purchase || record.created_at || '';
        const d = new Date(dateVal);
        return isNaN(d) ? null : d;
    }

    function getRecordFinancials(record) {
        // 跳过结余调整记录（不参与财务统计）
        if (record.data.remark && String(record.data.remark).includes('结余调整')) {
            return { income: 0, expense: 0, net: 0 };
        }

        const months = parseInt(record.data.months) || 0;
        let expense = 0;
        // 普通记账标签：支出在 expense_records 表，用 _expenseTotal
        // 独享/共享标签：只认 host_expense_details 明细，没明细就是 0
        if (record._expenseTotal !== undefined && record._expenseTotal > 0) {
            expense = record._expenseTotal;
        } else if (record._hostExpenseDetails && record._hostExpenseDetails.length > 0) {
            // 有主机支出明细：总支出 = 明细总和 + 附加
            expense = (record._hostExpenseTotal || 0) + parseExpenseExtra(record.data.expense);
        }
        // 没明细 → 支出 = 0，不再用 computeExpenseValue 公式兜底
        // Income: 优先用 _incomeTotal（income_records 表汇总）
        // 独享/共享标签收入在 record.data.fee 中，_incomeTotal 为 0 时 fallback
        let income = record._incomeTotal || 0;
        if (income <= 0) {
            income = evalAmountExpr(record.data.fee) || 0;
        }
        return { income, expense, net: income - expense };
    }

    function getRecordFinancialsByMonth(record) {
        // 跳过结余调整记录（不参与财务统计）
        if (record.data.remark && String(record.data.remark).includes('结余调整')) {
            return [];
        }

        // Returns array of { month: 'YYYY-MM', income, expense } broken down by month
        const results = [];
        const months = parseInt(record.data.months) || 0;
        // 优先用 host_purchase，其次 client_purchase，最后 created_at
        const purchaseDate = record.data.host_purchase || record.data.client_purchase;
        const startDate = purchaseDate ? new Date(purchaseDate) : (record.created_at ? new Date(record.created_at) : null);

        // 优先使用明细统计（避免 _expenseTotal / computeExpenseValue 与 _expenses 重复计算）
        const expenses = record._expenses || [];
        const hostDetails = record._hostExpenseDetails || [];
        const incomes = record._incomes || [];

        // 支出优先级（与 getRecordFinancials 一致）：
        // expense_records > host_expense_details
        // 没明细 → 不产生任何支出（不再用 月数×单价 公式平摊）
        if (expenses.length > 0) {
            // 有 expense_records 明细：支出按明细日期分配（见下方统一处理）
        } else if (hostDetails.length > 0) {
            // 独享/共享标签：按主机支出明细的实际日期+金额统计
            hostDetails.forEach(d => {
                if (d.expense_date) {
                    const dd = new Date(d.expense_date);
                    if (!isNaN(dd)) {
                        const monthKey = `${dd.getFullYear()}-${String(dd.getMonth() + 1).padStart(2, '0')}`;
                        let bucket = results.find(r => r.month === monthKey);
                        if (!bucket) {
                            bucket = { month: monthKey, income: 0, expense: 0 };
                            results.push(bucket);
                        }
                        bucket.expense += (parseFloat(d.unit_price) || 0);
                    }
                }
            });
            // 附加金额（一次性）：记到 host_purchase 当月（或第一笔明细的当月）
            const extra = parseExpenseExtra(record.data.expense);
            if (extra !== 0) {
                let anchorDate = null;
                if (startDate && !isNaN(startDate)) anchorDate = startDate;
                else if (hostDetails[0] && hostDetails[0].expense_date) {
                    anchorDate = new Date(hostDetails[0].expense_date);
                }
                if (anchorDate && !isNaN(anchorDate)) {
                    const monthKey = `${anchorDate.getFullYear()}-${String(anchorDate.getMonth() + 1).padStart(2, '0')}`;
                    let bucket = results.find(r => r.month === monthKey);
                    if (!bucket) {
                        bucket = { month: monthKey, income: 0, expense: 0 };
                        results.push(bucket);
                    }
                    bucket.expense += extra;
                }
            }
        }
        // 没明细 → 不产生支出，删除了平摊和兜底分支

        // ========== 收入 ==========
        // 所有标签：有 income_records 时按 income_date 分配月度收入
        if (incomes.length > 0) {
            incomes.forEach(inc => {
                if (inc.income_date) {
                    const d = new Date(inc.income_date);
                    if (!isNaN(d)) {
                        const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
                        let bucket = results.find(r => r.month === monthKey);
                        if (!bucket) {
                            bucket = { month: monthKey, income: 0, expense: 0 };
                            results.push(bucket);
                        }
                        bucket.income += (inc.amount || 0);
                    }
                }
            });
        } else {
            // 无 _incomes 明细时，从 records.data.fee 读取（所有标签，支持 =80+10 表达式）
            const fee = evalAmountExpr(record.data.fee);
            if (fee > 0 && startDate && !isNaN(startDate)) {
                const monthKey = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}`;
                let bucket = results.find(r => r.month === monthKey);
                if (!bucket) {
                    bucket = { month: monthKey, income: 0, expense: 0 };
                    results.push(bucket);
                }
                bucket.income += fee;
            }
        }

        // 所有标签：按 expense_records 日期分配月度支出
        if (expenses.length > 0) {
            expenses.forEach(exp => {
                if (exp.expense_date) {
                    const d = new Date(exp.expense_date);
                    if (!isNaN(d)) {
                        const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
                        let bucket = results.find(r => r.month === monthKey);
                        if (!bucket) {
                            bucket = { month: monthKey, income: 0, expense: 0 };
                            results.push(bucket);
                        }
                        bucket.expense += (exp.amount || 0);
                    }
                }
            });
        }

        return results;
    }

    function sumStats(records) {
        return records.reduce((acc, record) => {
            const f = getRecordFinancials(record);
            acc.income += f.income;
            acc.expense += f.expense;
            acc.net += f.net;
            acc.count += 1;
            return acc;
        }, { income: 0, expense: 0, net: 0, count: 0 });
    }

    function formatMoney(value) {
        return Number(value || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function renderMiniBars(items, maxValue, valueKey, colorClass) {
        if (items.length === 0) return '<div class="stats-empty">暂无数据</div>';
        return items.map(item => {
            const value = Math.abs(item[valueKey] || 0);
            const width = maxValue > 0 ? Math.max(4, Math.round(value / maxValue * 100)) : 4;
            return `
                <div class="stats-bar-row">
                    <div class="stats-bar-label">${escapeHtml(item.label)}</div>
                    <div class="stats-bar-track"><div class="stats-bar ${colorClass}" style="width:${width}%;"></div></div>
                    <div class="stats-bar-value">${formatMoney(item[valueKey])}</div>
                </div>
            `;
        }).join('');
    }

    async function renderStats() {
        try {
            statsContainer.innerHTML = '<div class="stats-loading">正在汇总所有标签数据...</div>';
            const records = await getAllTabRecordsForStats();
            if (records.length === 0) {
                statsContainer.innerHTML = '<div class="stats-empty large">暂无可统计数据</div>';
                return;
            }

            const total = sumStats(records);
            const profitRate = total.income > 0 ? (total.net / total.income * 100) : 0;
            const avgIncome = total.count ? total.income / total.count : 0;
            const avgExpense = total.count ? total.expense / total.count : 0;
            const expiredCount = records.filter(r => checkExpired(r.data.host_expire) === '过期').length;
            const activeCount = records.filter(r => checkExpired(r.data.host_expire) === '有效').length;

            const monthMap = {};
            const yearMap = {};
            const tabMap = {};
            const providerMap = {};

            records.forEach(record => {
                const f = getRecordFinancials(record);
                const d = getStatsDate(record);

                // Use monthly breakdown for accurate per-month allocation
                const monthlyBreakdown = getRecordFinancialsByMonth(record);
                monthlyBreakdown.forEach(mb => {
                    monthMap[mb.month] = monthMap[mb.month] || { label: mb.month, income: 0, expense: 0, net: 0, count: 0 };
                    monthMap[mb.month].income += mb.income;
                    monthMap[mb.month].expense += mb.expense;
                    monthMap[mb.month].net += (mb.income - mb.expense);
                    monthMap[mb.month].count += 1;

                    const year = mb.month.split('-')[0];
                    yearMap[year] = yearMap[year] || { label: year, income: 0, expense: 0, net: 0, count: 0 };
                    yearMap[year].income += mb.income;
                    yearMap[year].expense += mb.expense;
                    yearMap[year].net += (mb.income - mb.expense);
                    yearMap[year].count += 1;
                });

                const tabName = record.tabName || '未命名标签';
                tabMap[tabName] = tabMap[tabName] || { label: tabName, income: 0, expense: 0, net: 0, count: 0 };
                tabMap[tabName].income += f.income;
                tabMap[tabName].expense += f.expense;
                tabMap[tabName].net += f.net;
                tabMap[tabName].count += 1;

                const provider = record.data.provider || '未填写服务商';
                providerMap[provider] = providerMap[provider] || { label: provider, income: 0, expense: 0, net: 0, count: 0 };
                providerMap[provider].income += f.income;
                providerMap[provider].expense += f.expense;
                providerMap[provider].net += f.net;
                providerMap[provider].count += 1;
            });

            const months = Object.values(monthMap).sort((a, b) => a.label.localeCompare(b.label));
            const years = Object.values(yearMap).sort((a, b) => a.label.localeCompare(b.label));
            const tabs = Object.values(tabMap).sort((a, b) => b.net - a.net);
            const providers = Object.values(providerMap).sort((a, b) => b.net - a.net).slice(0, 8);

            // 过滤掉未来的年份和月份（只显示当前年月及之前）
            const now = new Date();
            const currentYear = now.getFullYear();
            const currentMonth = `${currentYear}-${String(now.getMonth() + 1).padStart(2, '0')}`;
            const filteredMonths = months.filter(m => m.label <= currentMonth);
            const filteredYears = years.filter(y => parseInt(y.label) <= currentYear);

            // 从 state 获取或默认时间范围
            const monthRange = isNaN(state.statsMonthRange) ? 6 : state.statsMonthRange;
            const yearRange = isNaN(state.statsYearRange) ? 6 : state.statsYearRange;
            const recentMonths = monthRange === 0 ? filteredMonths : filteredMonths.slice(-monthRange);
            const recentYears = yearRange === 0 ? filteredYears : filteredYears.slice(-yearRange);
            const maxMonthAmount = Math.max(1, ...recentMonths.map(m => Math.max(Math.abs(m.income), Math.abs(m.expense), Math.abs(m.net))));
            const maxTabNet = Math.max(1, ...tabs.map(t => Math.abs(t.net)));
            const maxProviderNet = Math.max(1, ...providers.map(p => Math.abs(p.net)));

            const bestMonth = filteredMonths.length ? filteredMonths.reduce((best, item) => item.net > best.net ? item : best, filteredMonths[0]) : null;
            const worstMonth = filteredMonths.length ? filteredMonths.reduce((worst, item) => item.net < worst.net ? item : worst, filteredMonths[0]) : null;

            // 辅助：利润率（净额 / 收入），收入为 0 时显示 —
            function profitRateText(income, net) {
                const inAmt = Number(income) || 0;
                if (inAmt <= 0) return '—';
                const rate = (Number(net) || 0) / inAmt * 100;
                return rate.toFixed(1) + '%';
            }
            const monthRows = recentMonths.map(item => {
                const rateTxt = profitRateText(item.income, item.net);
                const rateClass = (Number(item.income) || 0) > 0 && (Number(item.net) || 0) >= 0 ? 'positive' : 'negative';
                return `
                <tr>
                    <td>${escapeHtml(item.label)}</td>
                    <td class="positive">${formatMoney(item.income)}</td>
                    <td class="negative">${formatMoney(item.expense)}</td>
                    <td class="${item.net >= 0 ? 'positive' : 'negative'}">${formatMoney(item.net)}</td>
                    <td class="${rateClass}">${rateTxt}</td>
                    <td>${item.count}</td>
                </tr>
            `}).join('');

            const yearRows = recentYears.map(item => {
                const rateTxt = profitRateText(item.income, item.net);
                const rateClass = (Number(item.income) || 0) > 0 && (Number(item.net) || 0) >= 0 ? 'positive' : 'negative';
                return `
                <tr>
                    <td>${escapeHtml(item.label)}</td>
                    <td class="positive">${formatMoney(item.income)}</td>
                    <td class="negative">${formatMoney(item.expense)}</td>
                    <td class="${item.net >= 0 ? 'positive' : 'negative'}">${formatMoney(item.net)}</td>
                    <td class="${rateClass}">${rateTxt}</td>
                    <td>${item.count}</td>
                </tr>
            `}).join('');

            const hidden = state.statsHidden;
            const maskVal = () => '••••••';
            const realNet = formatMoney(total.net);
            const realIncome = formatMoney(total.income);
            const realExpense = formatMoney(total.expense);
            const realProfit = profitRate.toFixed(1) + '%';
            const realAvgIncome = formatMoney(avgIncome);
            const realAvgExpense = formatMoney(avgExpense);
            const showNet = hidden ? maskVal() : realNet;
            const showIncome = hidden ? maskVal() : realIncome;
            const showExpense = hidden ? maskVal() : realExpense;
            const showProfit = hidden ? maskVal() : realProfit;
            const showAvgIncome = hidden ? maskVal() : realAvgIncome;
            const showAvgExpense = hidden ? maskVal() : realAvgExpense;
            const eyeIcon = hidden ? '👁️' : '🙈';
            const eyeTitle = hidden ? '显示敏感数字' : '隐藏敏感数字';

            statsContainer.innerHTML = `
                <div class="stats-hero">
                    <div>
                        <div class="stats-eyebrow">All Tabs Financial Intelligence</div>
                        <h2>全标签财务统计
                            <button class="stats-eye-btn" id="statsEyeBtn" title="${eyeTitle}">${eyeIcon}</button>
                        </h2>
                        <p>已合并 ${state.tabs.length} 个标签，共 ${records.length} 条记录。</p>
                    </div>
                    <div class="stats-hero-net ${total.net >= 0 ? 'positive' : 'negative'}">
                        <span>净收入</span>
                        <strong class="stats-sensitive" data-real="${realNet}">${showNet}</strong>
                    </div>
                </div>

                <div class="stats-grid premium">
                    <div class="stat-card dark"><div class="stat-label">总收入</div><div class="stat-value positive stats-sensitive" data-real="${realIncome}">${showIncome}</div><div class="stat-sub">平均每条 <span class="stats-sensitive" data-real="${realAvgIncome}">${showAvgIncome}</span></div></div>
                    <div class="stat-card dark"><div class="stat-label">总支出</div><div class="stat-value negative stats-sensitive" data-real="${realExpense}">${showExpense}</div><div class="stat-sub">平均每条 <span class="stats-sensitive" data-real="${realAvgExpense}">${showAvgExpense}</span></div></div>
                    <div class="stat-card dark"><div class="stat-label">利润率</div><div class="stat-value neutral stats-sensitive" data-real="${realProfit}">${showProfit}</div><div class="stat-sub">收入转化净额占比</div></div>
                    <div class="stat-card dark"><div class="stat-label">到期状态</div><div class="stat-value neutral">${activeCount}/${expiredCount}</div><div class="stat-sub">有效 / 过期</div></div>
                </div>

                <div class="stats-insight-grid">
                    <div class="stats-panel">
                        <h3>近 ${monthRange === 0 ? '所有' : monthRange} 个月趋势</h3>
                        <div class="stats-month-bars">
                            ${recentMonths.map(item => `
                                <div class="month-bar-card">
                                    <div class="month-bar-title">${escapeHtml(item.label)}</div>
                                    <div class="month-bar-stack">
                                        <div class="month-bar income" style="height:${Math.max(6, Math.abs(item.income) / maxMonthAmount * 100)}%;"></div>
                                        <div class="month-bar expense" style="height:${Math.max(6, Math.abs(item.expense) / maxMonthAmount * 100)}%;"></div>
                                        <div class="month-bar net ${item.net >= 0 ? 'positive' : 'negative'}" style="height:${Math.max(6, Math.abs(item.net) / maxMonthAmount * 100)}%;"></div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                        <div class="stats-legend"><span class="income"></span>收入 <span class="expense"></span>支出 <span class="net"></span>净额</div>
                    </div>

                    <div class="stats-panel">
                        <h3>关键洞察</h3>
                        <div class="insight-list">
                            <div><span>最佳月份</span><strong>${bestMonth ? `${escapeHtml(bestMonth.label)} / ${formatMoney(bestMonth.net)}` : '暂无'}</strong></div>
                            <div><span>压力月份</span><strong>${worstMonth ? `${escapeHtml(worstMonth.label)} / ${formatMoney(worstMonth.net)}` : '暂无'}</strong></div>
                            <div><span>标签数量</span><strong>${state.tabs.length}</strong></div>
                            <div><span>服务商数量</span><strong>${Object.keys(providerMap).length}</strong></div>
                        </div>
                    </div>
                </div>

                <div class="stats-insight-grid">
                    <div class="stats-panel">
                        <h3>标签净额排行</h3>
                        ${renderMiniBars(tabs, maxTabNet, 'net', 'net')}
                    </div>
                    <div class="stats-panel">
                        <h3>服务商贡献排行</h3>
                        ${renderMiniBars(providers, maxProviderNet, 'net', 'net')}
                    </div>
                </div>

                <div class="stats-detail premium-table">
                    <div class="stats-detail-header"><h3>年度对比</h3><select class="stats-range-select" data-range-type="year" style="margin-left:8px;padding:2px 6px;font-size:13px;border-radius:4px;border:1px solid #dcdfe6;"><option value="6" ${yearRange===6?'selected':''}>近6年</option><option value="12" ${yearRange===12?'selected':''}>近12年</option><option value="0" ${yearRange===0?'selected':''}>所有年份</option></select></div>
                    <table><thead><tr><th>年份</th><th>收入</th><th>支出</th><th>净额</th><th>利润率</th><th>记录数</th></tr></thead><tbody>${yearRows}</tbody></table>
                </div>

                <div class="stats-detail premium-table">
                    <div class="stats-detail-header"><h3>月份明细</h3><select class="stats-range-select" data-range-type="month" style="margin-left:8px;padding:2px 6px;font-size:13px;border-radius:4px;border:1px solid #dcdfe6;"><option value="6" ${monthRange===6?'selected':''}>近6月</option><option value="12" ${monthRange===12?'selected':''}>近12月</option><option value="24" ${monthRange===24?'selected':''}>近24月</option><option value="0" ${monthRange===0?'selected':''}>所有月份</option></select></div>
                    <table><thead><tr><th>月份</th><th>收入</th><th>支出</th><th>净额</th><th>利润率</th><th>记录数</th></tr></thead><tbody>${monthRows}</tbody></table>
                </div>
            `;
        } catch (err) {
            statsContainer.innerHTML = `<div class="stats-empty large">统计加载失败：${escapeHtml(err.message)}</div>`;
        }
    }

    // 统计时间范围下拉框事件委托
    document.addEventListener('change', function(e) {
        if (!e.target.classList.contains('stats-range-select')) return;
        const rangeType = e.target.dataset.rangeType;
        const rangeVal = parseInt(e.target.value);
        if (rangeType === 'month') {
            state.statsMonthRange = rangeVal;
        } else if (rangeType === 'year') {
            state.statsYearRange = rangeVal;
        }
        renderStats();
    });

    // 财务统计眼睛按钮（显示/隐藏敏感数字）— 只切换DOM，不重新统计
    document.addEventListener('click', function(e) {
        if (!e.target.classList.contains('stats-eye-btn')) return;
        state.statsHidden = !state.statsHidden;
        try {
            if (state.userId) localStorage.setItem('statsHidden_' + state.userId, state.statsHidden ? '1' : '0');
        } catch(e) {}
        const hidden = state.statsHidden;
        const mask = '••••••';
        // 切换按钮图标
        e.target.textContent = hidden ? '👁️' : '🙈';
        e.target.title = hidden ? '显示敏感数字' : '隐藏敏感数字';
        // 切换所有敏感值文本
        const sensitives = statsContainer.querySelectorAll('.stats-sensitive');
        sensitives.forEach(el => {
            if (hidden) {
                el.dataset.real = el.textContent;
                el.textContent = mask;
            } else {
                el.textContent = el.dataset.real || el.textContent;
            }
        });
    });

    // 收入/支出/主机支出明细：点击表头排序
    document.addEventListener('click', function(e) {
        const field = e.target.dataset.sortField;
        if (!field) return;
        const header = e.target.closest('.income-list-header');
        if (!header) return;
        const list = header.parentElement;
        let sortState, renderFn;
        if (list.id === 'incomeList') { sortState = state.incomeSort; renderFn = renderIncomeList; }
        else if (list.id === 'expenseList') { sortState = state.expenseSort; renderFn = renderExpenseList; }
        else if (list.id === 'hostExpenseList') { sortState = state.hostExpenseSort; renderFn = renderHostExpenseList; }
        else return;
        if (sortState.field === field) {
            sortState.order = sortState.order === 'asc' ? 'desc' : 'asc';
        } else {
            sortState.field = field;
            sortState.order = field === 'date' ? 'desc' : 'asc';
        }
        renderFn();
    });

    // --- 密码修改 ---
    async function changePassword() {
        const oldPwd = oldPwdInput.value.trim();
        const newPwd = newPwdInput.value.trim();
        const confirmPwd = confirmPwdInput.value.trim();
        if (!oldPwd) { changePwdStatus.textContent = '⚠️ 请输入当前密码'; return; }
        if (newPwd.length < 6) { changePwdStatus.textContent = '⚠️ 新密码至少6位'; return; }
        if (newPwd !== confirmPwd) { changePwdStatus.textContent = '⚠️ 两次密码不一致'; return; }
        try {
            await API.post('/auth/change-password', { oldPassword: oldPwd, newPassword: newPwd });
            changePwdStatus.textContent = '✅ 密码修改成功';
            oldPwdInput.value = ''; newPwdInput.value = ''; confirmPwdInput.value = '';
        } catch (err) { changePwdStatus.textContent = '❌ 修改失败: ' + err.message; }
    }

    async function changeUsername() {
        const password = usernamePasswordInput.value.trim();
        const newUsername = newUsernameInput.value.trim();
        if (!password) { changeUsernameStatus.textContent = '⚠️ 请输入当前密码'; return; }
        if (!newUsername) { changeUsernameStatus.textContent = '⚠️ 请输入新用户名'; return; }
        try {
            const res = await API.post('/auth/change-username', { password, newUsername });
            changeUsernameStatus.textContent = '✅ 用户名修改成功';
            usernamePasswordInput.value = ''; newUsernameInput.value = '';
            usernameDisplay.textContent = res.username;
        } catch (err) { changeUsernameStatus.textContent = '❌ 修改失败: ' + err.message; }
    }

    // --- 注册开关 ---
    async function loadRegisterSwitch() {
        try {
            const data = await API.get('/settings/allow_register');
            if (data.value !== undefined) allowRegisterCheckbox.checked = data.value !== false;
        } catch (err) {}
    }
    async function saveRegisterSwitch() {
        const value = allowRegisterCheckbox.checked;
        try {
            await API.post('/settings', { key: 'allow_register', value });
            registerSwitchStatus.textContent = '✅ 已保存';
            setTimeout(() => registerSwitchStatus.textContent = '', 3000);
        } catch (err) { registerSwitchStatus.textContent = '❌ 保存失败: ' + err.message; }
    }

    // --- 地址后缀 ---
    async function loadSuffixSettings() {
        try {
            const ipSuffix = await API.get('/settings/ip_port_suffix');
            const domainSuffix = await API.get('/settings/domain_port_suffix');
            if (ipSuffix.value !== null) { state.ipPortSuffix = ipSuffix.value; ipPortSuffixInput.value = ipSuffix.value; }
            if (domainSuffix.value !== null) { state.domainPortSuffix = domainSuffix.value; domainPortSuffixInput.value = domainSuffix.value; }
        } catch (err) { console.warn('加载后缀设置失败:', err); }
    }
    async function saveSuffixSettings() {
        const ipSuffix = ipPortSuffixInput.value.trim();
        const domainSuffix = domainPortSuffixInput.value.trim();
        try {
            await API.post('/settings/batch', {
                settings: {
                    ip_port_suffix: ipSuffix,
                    domain_port_suffix: domainSuffix
                }
            });
            state.ipPortSuffix = ipSuffix; state.domainPortSuffix = domainSuffix;
            suffixStatus.textContent = '✅ 已保存';
            setTimeout(() => suffixStatus.textContent = '', 3000);
        } catch (err) { suffixStatus.textContent = '❌ 保存失败: ' + err.message; }
    }

    // --- 服务商管理 ---
    function normalizeProviderOptions(options) {
        const result = [];
        (options || []).forEach(item => {
            const name = String(item || '').trim();
            if (name && !result.includes(name)) result.push(name);
        });
        return result;
    }

    function collectProviderOptionsFromRecords() {
        // 不再从记录中自动收集服务商（避免删除后重新出现）
        state.providerOptions = normalizeProviderOptions(state.providerOptions);
    }

    async function loadProviderOptions() {
        try {
            const data = await API.get('/settings/provider_options');
            state.providerOptions = normalizeProviderOptions(Array.isArray(data.value) ? data.value : []);
        } catch (err) {
            state.providerOptions = [];
        }
    }

    async function saveProviderOptions() {
        await API.post('/settings', { key: 'provider_options', value: state.providerOptions });
    }

    function renderProviderList() {
        if (!providerList) return;
        if (state.providerOptions.length === 0) {
            providerList.innerHTML = '<div class="provider-empty">暂无服务商</div>';
            return;
        }
        providerList.innerHTML = state.providerOptions.map(name => `
            <div class="provider-item">
                <span class="provider-item-name">${escapeHtml(name)}</span>
                <button type="button" class="delete-provider-btn" data-name="${escapeAttr(name)}">删除</button>
            </div>
        `).join('');
        providerList.querySelectorAll('.delete-provider-btn').forEach(btn => {
            btn.addEventListener('click', async function() {
                const name = this.dataset.name;
                if (!await showConfirm(`确定删除服务商"${name}"吗？已使用的记录不会被清空。`)) return;
                try {
                    state.providerOptions = state.providerOptions.filter(item => item !== name);
                    await saveProviderOptions();
                    renderProviderList();
                    renderTable(false);
                    providerStatus.textContent = '✅ 已删除';
                    setTimeout(() => providerStatus.textContent = '', 2000);
                } catch (err) { providerStatus.textContent = '❌ 删除失败: ' + err.message; }
            });
        });
    }

    function openProviderModal() {
        collectProviderOptionsFromRecords();
        providerNameInput.value = '';
        providerStatus.textContent = '';
        renderProviderList();
        providerModal.classList.add('show');
        setTimeout(() => providerNameInput.focus(), 0);
    }

    async function addProvider() {
        const name = providerNameInput.value.trim();
        if (!name) { providerStatus.textContent = '⚠️ 请输入服务商名称'; return; }
        if (state.providerOptions.includes(name)) { providerStatus.textContent = '⚠️ 服务商已存在'; return; }
        try {
            state.providerOptions.unshift(name);
            state.providerOptions = normalizeProviderOptions(state.providerOptions);
            await saveProviderOptions();
            providerNameInput.value = '';
            providerStatus.textContent = '✅ 已添加';
            renderProviderList();
            renderTable(false);
            setTimeout(() => providerStatus.textContent = '', 2000);
        } catch (err) { providerStatus.textContent = '❌ 添加失败: ' + err.message; }
    }

    // --- 应用 LOGO（登录页 + 左上角 网络管理系统前图标）---
    function applyAppLogo(logoValue) {
        const logoIcon = document.getElementById('navLogoIcon');
        const previewImg = document.getElementById('appLogoPreviewImg');
        const previewDefault = document.getElementById('appLogoPreviewDefault');
        const logoUrl = (() => {
            if (!logoValue) return null;
            if (logoValue.type === 'url') return logoValue.url;
            if (logoValue.type === 'local') return logoValue.path;
            return null;
        })();
        // 左上角（主界面）
        if (logoIcon) {
            if (logoUrl) {
                logoIcon.innerHTML = `<img src="${cssUrl(logoUrl)}" alt="logo" style="height:24px;width:auto;max-width:48px;object-fit:contain;display:block;" onerror="this.parentNode.innerHTML='🌐';" />`;
            } else {
                logoIcon.innerHTML = '🌐';
            }
        }
        // 设置里的预览
        if (previewImg) {
            if (logoUrl) {
                previewImg.src = cssUrl(logoUrl);
                previewImg.style.display = 'inline-block';
            } else {
                previewImg.style.display = 'none';
                previewImg.removeAttribute('src');
            }
        }
        if (previewDefault) {
            previewDefault.style.display = logoUrl ? 'none' : 'inline-block';
        }
    }
    async function uploadAppLogoFromUrl() {
        const input = document.getElementById('appLogoUrlInput');
        const status = document.getElementById('appLogoStatus');
        const url = (input ? input.value : '').trim();
        if (!url) { if (status) status.textContent = '⚠️ 请输入图片 URL'; return; }
        if (!/^https?:\/\//i.test(url)) { if (status) status.textContent = '⚠️ URL 必须是 http(s):// 开头'; return; }
        try {
            if (status) status.textContent = '🔄 保存中...';
            await API.post('/settings', { key: 'app_logo', value: { type: 'url', url } });
            applyAppLogo({ type: 'url', url });
            if (status) status.textContent = '✅ 已应用 LOGO（刷新浏览器登录页也会生效）';
            setTimeout(() => { if (status) status.textContent = ''; }, 3000);
        } catch (err) { if (status) status.textContent = '❌ 设置失败: ' + err.message; }
    }
    async function uploadAppLogoFromFile() {
        const fileInput = document.getElementById('appLogoFileInput');
        const status = document.getElementById('appLogoStatus');
        const file = fileInput ? fileInput.files[0] : null;
        if (!file) { if (status) status.textContent = '⚠️ 请先选择图片'; return; }
        try {
            if (status) status.textContent = '🔄 上传中...';
            const formData = new FormData();
            formData.append('image', file);
            const res = await fetch('/api/upload', { method: 'POST', credentials: 'include', body: formData });
            const data = await res.json().catch(() => ({ error: '上传返回格式错误' }));
            if (!res.ok || data.error) throw new Error(data.error || '上传失败');
            if (!data.success) throw new Error(data.error || '上传失败');
            await API.post('/settings', { key: 'app_logo', value: { type: 'local', path: data.url } });
            applyAppLogo({ type: 'local', path: data.url });
            if (status) status.textContent = '✅ LOGO 已保存（刷新浏览器登录页也会生效）';
            setTimeout(() => { if (status) status.textContent = ''; }, 3000);
        } catch (err) { if (status) status.textContent = '❌ 上传失败: ' + err.message; }
    }
    async function removeAppLogo() {
        const status = document.getElementById('appLogoStatus');
        try {
            if (!await showConfirm('确定恢复默认 🌐 图标吗？')) return;
            await API.post('/settings', { key: 'app_logo', value: null });
            applyAppLogo(null);
            const urlInput = document.getElementById('appLogoUrlInput');
            if (urlInput) urlInput.value = '';
            if (status) status.textContent = '✅ 已恢复默认';
            setTimeout(() => { if (status) status.textContent = ''; }, 2500);
        } catch (err) { if (status) status.textContent = '❌ 移除失败: ' + err.message; }
    }

    // --- Favicon ---
    async function uploadFavicon() {
        const fileInput = document.getElementById('faviconFileInput');
        const file = fileInput.files[0];
        if (!file) { document.getElementById('faviconStatus').textContent = '⚠️ 请选择文件'; return; }
        const formData = new FormData();
        formData.append('image', file);
        try {
            const res = await fetch('/api/upload', { method: 'POST', credentials: 'include', body: formData });
            const data = await res.json().catch(() => ({ error: '服务器返回格式错误，请确认上传接口正常' }));
            if (!res.ok || data.error) throw new Error(data.error || '上传失败');
            if (data.success) {
                const response = await fetch('/api/settings/favicon', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ path: data.url })
                });
                const result = await response.json().catch(() => ({ error: '服务器返回格式错误，请确认图标保存接口正常' }));
                if (!response.ok || result.error) throw new Error(result.error || '保存图标失败');
                if (result.success) {
                    document.getElementById('faviconStatus').textContent = '✅ 图标已更新，请刷新浏览器查看';
                    const link = document.querySelector("link[rel*='icon']");
                    if (link) link.href = data.url + '?v=' + Date.now();
                } else { document.getElementById('faviconStatus').textContent = '❌ 保存图标失败: ' + (result.error || ''); }
            } else { document.getElementById('faviconStatus').textContent = '❌ 上传失败: ' + (data.error || ''); }
        } catch (err) { document.getElementById('faviconStatus').textContent = '❌ 上传失败: ' + err.message; }
    }

    // --- 加载设置 ---
    async function loadSettings() {
        try {
            const cert = await API.get('/settings/cert_path');
            const key = await API.get('/settings/key_path');
            if (cert.value) document.getElementById('certPathInput').value = cert.value;
            if (key.value) document.getElementById('keyPathInput').value = key.value;
            const bg = await API.get('/settings/background');
            if (bg.value) {
                const bgData = bg.value;
                const preview = document.getElementById('bgPreview');
                if (bgData.type === 'url' || bgData.type === 'local') {
                    const url = bgData.type === 'url' ? bgData.url : bgData.path;
                    preview.style.backgroundImage = `url("${cssUrl(url)}")`;
                    preview.classList.add('has-bg'); preview.textContent = '';
                }
            }
            // 加载标题栏颜色
            try {
                const headerColors = await API.get('/settings/header_colors');
                if (headerColors.value) {
                    applyHeaderColors(headerColors.value);
                    const DEFAULTS = DEFAULT_HEADER_COLORS || { navbar:'#1a1a2e', navbarText:'#ffffff', menubar:'#16213e', menubarText:'#ffffff' };
                    if (document.getElementById('navbarColorInput')) document.getElementById('navbarColorInput').value = headerColors.value.navbar || DEFAULTS.navbar;
                    if (document.getElementById('navbarColorText')) document.getElementById('navbarColorText').value = headerColors.value.navbar || DEFAULTS.navbar;
                    if (document.getElementById('navbarTextColorInput')) document.getElementById('navbarTextColorInput').value = headerColors.value.navbarText || DEFAULTS.navbarText;
                    if (document.getElementById('navbarTextColorText')) document.getElementById('navbarTextColorText').value = headerColors.value.navbarText || DEFAULTS.navbarText;
                    if (document.getElementById('menubarColorInput')) document.getElementById('menubarColorInput').value = headerColors.value.menubar || DEFAULTS.menubar;
                    if (document.getElementById('menubarColorText')) document.getElementById('menubarColorText').value = headerColors.value.menubar || DEFAULTS.menubar;
                    if (document.getElementById('menubarTextColorInput')) document.getElementById('menubarTextColorInput').value = headerColors.value.menubarText || DEFAULTS.menubarText;
                    if (document.getElementById('menubarTextColorText')) document.getElementById('menubarTextColorText').value = headerColors.value.menubarText || DEFAULTS.menubarText;
                }
            } catch (e) { /* 忽略旧版本没有这个设置的情况 */ }
            // 加载 LOGO（应用到左上角 + 设置预览）
            try {
                const logo = await API.get('/settings/app_logo');
                if (logo.value) applyAppLogo(logo.value);
                else applyAppLogo(null);
            } catch (e) { /* 旧版本忽略 */ }
            await loadRegisterSwitch();
            await loadSuffixSettings();
            await loadProviderOptions();
            collectProviderOptionsFromRecords();
            const auth = await API.get('/auth/check');
            if (auth.loggedIn && auth.user.id === 1) registerSwitchGroup.style.display = 'block';
        } catch (err) { console.warn('加载设置失败:', err); }
    }

    function applyHeaderColors(colors) {
        if (!colors) return;
        const navbar = document.querySelector('.navbar');
        const menubar = document.querySelector('.top-menu');
        // 用 background 覆盖 CSS 中的渐变（linear-gradient）
        if (navbar && colors.navbar) navbar.style.background = colors.navbar;
        if (menubar && colors.menubar) menubar.style.background = colors.menubar;
        // 导航栏字体颜色（给 navbar 下主要文字类直接设置）
        if (navbar) {
            if (colors.navbarText) {
                navbar.style.color = colors.navbarText;
                navbar.querySelectorAll('.nav-logo, .nav-logo span, .server-status, .ss-item, .nav-right, .user-info, .nav-user-menu, .ss-value').forEach(el => el.style.color = colors.navbarText);
                navbar.querySelectorAll('button, a').forEach(el => el.style.color = colors.navbarText);
                navbar.querySelectorAll('.traffic-item, .traffic-arrow, .traffic-speed').forEach(el => el.style.color = colors.navbarText);
                navbar.querySelectorAll('.network-status').forEach(el => el.style.color = colors.navbarText);
            } else {
                navbar.style.color = '';
                navbar.querySelectorAll('.nav-logo, .nav-logo span, .server-status, .ss-item, .nav-right, .user-info, .nav-user-menu, .ss-value, button, a').forEach(el => el.style.color = '');
                navbar.querySelectorAll('.traffic-item, .traffic-arrow, .traffic-speed, .network-status').forEach(el => el.style.color = '');
            }
        }
        // 菜单栏字体颜色
        if (menubar) {
            if (colors.menubarText) {
                menubar.style.color = colors.menubarText;
                menubar.querySelectorAll('.menu-item, .top-menu-title, .menu-group, .tab-label, button, a').forEach(el => el.style.color = colors.menubarText);
            } else {
                menubar.style.color = '';
                menubar.querySelectorAll('.menu-item, .top-menu-title, .menu-group, .tab-label, button, a').forEach(el => el.style.color = '');
            }
        }
        // 存到 localStorage，刷新时立即应用（避免闪烁）
        try { localStorage.setItem('header_colors', JSON.stringify(colors)); } catch (e) {}
    }

    // --- 事件绑定 ---
    addRowBtn.addEventListener('click', showAddRowModal);
    manageRowsBtn.addEventListener('click', function() {
        state.rowManageMode = !state.rowManageMode;
        if (!state.rowManageMode) {
            state.selectedRows.clear();
        }
        if (manageRowsBtn) {
            manageRowsBtn.classList.toggle('active', state.rowManageMode);
            // 保持两个状态都带 emoji，避免切换时按钮宽度跳动
            manageRowsBtn.textContent = state.rowManageMode ? '✅ 完成' : '📝 管理行';
        }
        renderTable(false);
    });
    deleteRowsBtn.addEventListener('click', deleteSelected);
    exportBtn.addEventListener('click', exportData);
    if (exportInfoBtn) {
        exportInfoBtn.addEventListener('click', () => {
            exportInfoStatus.textContent = '';
            exportInfoModal.classList.add('show');
        });
    }
    if (closeExportInfoModal) {
        closeExportInfoModal.addEventListener('click', () => {
            exportInfoModal.classList.remove('show');
        });
    }
    if (exportInfoCancel) {
        exportInfoCancel.addEventListener('click', () => {
            exportInfoModal.classList.remove('show');
        });
    }
    exportInfoModal.querySelectorAll('.export-info-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            exportInfoModal.querySelectorAll('.export-info-tab').forEach(t => t.classList.remove('active'));
            exportInfoModal.querySelectorAll('.export-info-panel').forEach(p => p.classList.remove('active'));
            tab.classList.add('active');
            const panel = exportInfoModal.querySelector(`.export-info-panel[data-panel="${tab.dataset.tab}"]`);
            if (panel) panel.classList.add('active');
        });
    });
    if (exportInfoConfirm) {
        exportInfoConfirm.addEventListener('click', async () => {
            const activeTab = exportInfoModal.querySelector('.export-info-tab.active');
            const tabType = activeTab ? activeTab.dataset.tab : 'info';
            const infoExportFields = [
                { key: 'ip_info', name: 'IP信息' },
                { key: 'client_purchase', name: '客户购买时间' },
                { key: 'client_expire', name: '客户到期时间' },
                { key: 'client_remaining', name: '客户剩余天数' },
                { key: 'client_name', name: '客户名' },
                { key: 'price', name: '单价' }
            ];
            if (tabType === 'info') {
                const format = document.querySelector('input[name="exportInfoFormat"]:checked');
                const fmt = format ? format.value : 'excel';
                const clientRecords = state.records || [];
                if (clientRecords.length === 0) {
                    exportInfoStatus.textContent = '⚠️ 没有客户数据';
                    return;
                }
                try {
                    const getPrice = await buildIncomePriceMap(state.currentTabId);
                    if (fmt === 'excel') {
                        exportInfoStatus.textContent = '🔄 导出中...';
                        if (typeof XLSX === 'undefined') await loadXLSX();
                        const headers = infoExportFields.map(f => f.name);
                        const rows = clientRecords.map(r => {
                            return infoExportFields.map(f => {
                                if (f.key === 'client_remaining') {
                                    const days = computeDaysRemaining(r.data.client_expire);
                                    return days !== '' ? days + ' 天' : '';
                                }
                                if (f.key === 'client_purchase' || f.key === 'client_expire') {
                                    return formatDisplayDate(r.data[f.key]);
                                }
                                if (f.key === 'price') {
                                    return Math.round(getPrice(r.id));
                                }
                                if (f.key === 'ip_info') {
                                    return r.data.ip_info || r.data.ip_address || '';
                                }
                                return r.data[f.key] ?? '';
                            });
                        });
                        const wsData = [headers, ...rows];
                        const ws = XLSX.utils.aoa_to_sheet(wsData);
                        const colWidths = infoExportFields.map((f, i) => {
                            let maxW = headers[i].length * 14;
                            rows.forEach(r => { maxW = Math.max(maxW, String(r[i]).length * 14); });
                            return { wch: Math.min(Math.max(Math.round(maxW / 7), 10), 30) };
                        });
                        ws['!cols'] = colWidths;
                        const wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(wb, ws, '客户信息');
                        const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
                        downloadFile(buf, `客户信息_${new Date().toISOString().slice(0,10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        exportInfoStatus.textContent = '✅ 导出成功';
                        setTimeout(() => { exportInfoModal.classList.remove('show'); exportInfoStatus.textContent = ''; }, 1500);
                    } else {
                        exportInfoStatus.textContent = '🔄 生成图片中...';
                        await exportClientInfoAsImage(clientRecords, infoExportFields, getPrice);
                        exportInfoStatus.textContent = '✅ 图片已复制到剪贴板';
                        setTimeout(() => { exportInfoModal.classList.remove('show'); exportInfoStatus.textContent = ''; }, 1500);
                    }
                } catch (err) {
                    exportInfoStatus.textContent = '❌ 导出失败: ' + err.message;
                }
            } else {
                const format = document.querySelector('input[name="exportBillFormat"]:checked');
                const fmt = format ? format.value : 'excel';
                try {
                    exportInfoStatus.textContent = '🔄 生成账单中...';
                    await exportBill(fmt);
                    exportInfoStatus.textContent = '✅ 账单导出成功';
                    setTimeout(() => { exportInfoModal.classList.remove('show'); exportInfoStatus.textContent = ''; }, 1500);
                } catch (err) {
                    exportInfoStatus.textContent = '❌ 导出失败: ' + err.message;
                }
            }
        });
    }
    closeExportClientInfoModal.addEventListener('click', () => exportClientInfoModal.classList.remove('show'));
    exportClientConfirm.addEventListener('click', exportClientInfo);
    exportClientCancel.addEventListener('click', () => exportClientInfoModal.classList.remove('show'));
    importBtn.addEventListener('click', showImportModal);
    refreshBtn.addEventListener('click', function() {
        // 按刷新键：清除剪切/提取的服务器/客户信息（用户要求：剪切后不想粘贴了按刷新清除）
        state.copiedServerData = null;
        state.copiedServerRecordId = null;
        state.copiedServerIsSimpleCut = false;
        state.copiedClientRecordId = null;
        state.extractedClientData = null;
        state.extractedBothData = null;
        $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
        // 清除左下角系统提示/错误信息
        setStatus('');
        if (state.currentTabId) {
            showTableLoading();
            state.page = 1;
            invalidateCurrentTabCache();
            loadRecords(state.currentTabId).then(() => { renderTable(false); hideTableLoading(); });
        } else {
            setStatus('✅ 已清除剪切信息');
        }
    });
    manageColumnsBtn.addEventListener('click', showColumnManager);
    conditionalFormatBtn.addEventListener('click', openConditionalFormatModal);
    closeConditionalFormatModal.addEventListener('click', () => conditionalFormatModal.classList.remove('show'));

    // 收支统计：调用后端接口汇总整个标签
    async function openIncomeExpenseStats() {
        if (!state.currentTabId) return;
        try {
            const result = await API.get('/records/stats?tabId=' + state.currentTabId);
            statsTotalIncome.textContent = result.totalIncome.toFixed(2);
            statsTotalExpense.textContent = result.totalExpense.toFixed(2);
            statsNetProfit.textContent = (result.netProfit >= 0 ? '+' : '') + result.netProfit.toFixed(2);
            statsNetProfit.style.color = result.netProfit >= 0 ? '#2e7d32' : '#c62828';
            statsRecordCount.textContent = result.recordCount;
            // 利润率显示（同财务统计：净利/收入，保留1位小数，>=0 positive，<0 negative）
            const wrap = document.getElementById('statsProfitRatioWrap');
            if (wrap && statsProfitRatio) {
                const profitRate = result.profitRate;
                if (profitRate === null || profitRate === undefined) {
                    wrap.style.background = '#f5f5f5';
                    statsProfitRatio.textContent = '—';
                    statsProfitRatio.style.color = '#333';
                } else {
                    const positive = profitRate >= 0;
                    wrap.style.background = positive ? '#e8f5e9' : '#ffebee';
                    const prefix = positive ? '+' : '';
                    statsProfitRatio.textContent = prefix + profitRate.toFixed(1) + '%';
                    statsProfitRatio.style.color = positive ? '#2e7d32' : '#c62828';
                }
            }
            incomeExpenseStatsModal.classList.add('show');
        } catch (err) {
            setStatus('统计失败: ' + err.message);
        }
    }

    incomeExpenseStatsBtn.addEventListener('click', openIncomeExpenseStats);
    closeIncomeExpenseStatsModal.addEventListener('click', () => incomeExpenseStatsModal.classList.remove('show'));
    cfAddBtn.addEventListener('click', addConditionalFormat);
    cfCancelEditBtn.addEventListener('click', cancelCfEdit);
    cfValueInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') addConditionalFormat(); });
    logoutBtn.addEventListener('click', async function() {
        if (!await showConfirm('确定退出吗？')) return;
        // 退出前保存当前筛选状态
        if (state.currentTabId) {
            state.tabFilters[state.currentTabId] = { ...state.filters };
            saveTabFiltersToStorage();
        }
        try { await API.post('/auth/logout'); window.location.href = '/login'; } catch (err) { setStatus('❌ 退出失败: ' + err.message); }
    });

    addressSuffixBtn.addEventListener('click', () => addressSuffixModal.classList.add('show'));
    providerManageBtn.addEventListener('click', openProviderModal);
    closeAddressSuffixModal.addEventListener('click', () => addressSuffixModal.classList.remove('show'));
    closeProviderModal.addEventListener('click', () => providerModal.classList.remove('show'));
    // 关闭弹窗前强制落盘单价，避免用户点击 × 时 input 仍聚焦而未触发 blur 导致单价丢失
    closeIncomeModal.addEventListener('click', () => {
        if (_incomePriceSaveTimer) { clearTimeout(_incomePriceSaveTimer); _incomePriceSaveTimer = null; }
        if (state.incomeRecordId) {
            persistModalTopPrice(state.incomeRecordId, 'income_unit_price', incomeAmountInput.value);
        }
        incomeModal.classList.remove('show');
    });
    closeColumnModal.addEventListener('click', () => columnModal.classList.remove('show'));
    if (addColBtn) addColBtn.addEventListener('click', addColumn);
    closeImport.addEventListener('click', () => importModal.classList.remove('show'));
    confirmImport.addEventListener('click', handleImport);
    cancelImport.addEventListener('click', () => importModal.classList.remove('show'));
    changePwdBtn.addEventListener('click', changePassword);
    confirmPwdInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') changePassword(); });
    changeUsernameBtn.addEventListener('click', changeUsername);
    newUsernameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') changeUsername(); });
    addProviderBtn.addEventListener('click', addProvider);
    providerNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') addProvider();
        if (e.key === 'Escape') providerModal.classList.remove('show');
    });
    addIncomeBtn.addEventListener('click', addIncomeRecord);
    // 收入单价：输入+失焦都立即（防抖）持久化到数据库，不再依赖脆弱的 localStorage 单点保存
    incomeAmountInput.addEventListener('input', scheduleIncomePricePersist);
    incomeAmountInput.addEventListener('blur', () => {
        if (_incomePriceSaveTimer) { clearTimeout(_incomePriceSaveTimer); _incomePriceSaveTimer = null; }
        persistModalTopPrice(state.incomeRecordId, 'income_unit_price', incomeAmountInput.value);
    });
    incomeAmountInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') addIncomeRecord();
    });

    closeExpenseModal.addEventListener('click', () => {
        if (_expensePriceSaveTimer) { clearTimeout(_expensePriceSaveTimer); _expensePriceSaveTimer = null; }
        if (state.expenseRecordId) {
            persistModalTopPrice(state.expenseRecordId, 'expense_unit_price', expenseAmountInput.value);
        }
        expenseModal.classList.remove('show');
    });
    addExpenseBtn.addEventListener('click', addExpenseRecord);
    // 支出单价：输入+失焦都立即（防抖）持久化到数据库
    expenseAmountInput.addEventListener('input', scheduleExpensePricePersist);
    expenseAmountInput.addEventListener('blur', () => {
        if (_expensePriceSaveTimer) { clearTimeout(_expensePriceSaveTimer); _expensePriceSaveTimer = null; }
        persistModalTopPrice(state.expenseRecordId, 'expense_unit_price', expenseAmountInput.value);
    });
    expenseAmountInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') addExpenseRecord();
    });

    // 主机支出明细弹窗事件
    if (closeHostExpenseModal) closeHostExpenseModal.addEventListener('click', () => {
        // 关闭主机支出弹窗前强制保存单价、附加
        if (state.hostExpenseRecordId) {
            persistModalTopPrice(state.hostExpenseRecordId, 'host_expense_unit_price', hostExpenseUnitPriceInput ? hostExpenseUnitPriceInput.value : '');
            persistModalTopPrice(state.hostExpenseRecordId, 'host_expense_extra', hostExpenseExtraInput ? hostExpenseExtraInput.value : '');
        }
        hostExpenseModal.classList.remove('show');
    });
    if (addHostExpenseDetailBtn) addHostExpenseDetailBtn.addEventListener('click', addHostExpenseDetailManually);
    if (hostExpenseUnitPriceInput) {
        hostExpenseUnitPriceInput.addEventListener('input', updateHostExpenseTotalDisplay);
        hostExpenseUnitPriceInput.addEventListener('blur', () => saveHostExpenseConfig('unit_price'));
        hostExpenseUnitPriceInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); addHostExpenseDetailManually(); }
        });
    }
    if (hostExpenseExtraInput) {
        hostExpenseExtraInput.addEventListener('input', updateHostExpenseTotalDisplay);
        hostExpenseExtraInput.addEventListener('blur', () => saveHostExpenseConfig('extra'));
        hostExpenseExtraInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); addHostExpenseDetailManually(); }
        });
    }
    if (hostExpenseRemarkInput) {
        hostExpenseRemarkInput.addEventListener('blur', () => saveHostExpenseConfig('remark'));
        hostExpenseRemarkInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); addHostExpenseDetailManually(); }
        });
    }

    // --- 分页事件 ---
    firstPageBtn.addEventListener('click', async () => {
        if (state.page <= 1) return;
        state.page = 1;
        await loadRecords(state.currentTabId);
        renderTable(false);
        const tw = $('#tableWrapper');
        if (tw) tw.scrollTop = 0;
    });
    prevPageBtn.addEventListener('click', async () => {
        if (state.page <= 1) return;
        state.page--;
        await loadRecords(state.currentTabId);
        renderTable(false);
        const tw = $('#tableWrapper');
        if (tw) tw.scrollTop = 0;
    });
    nextPageBtn.addEventListener('click', async () => {
        if (state.page >= state.totalPages) return;
        state.page++;
        await loadRecords(state.currentTabId);
        renderTable(false);
        const tw = $('#tableWrapper');
        if (tw) tw.scrollTop = 0;
    });
    lastPageBtn.addEventListener('click', async () => {
        if (state.page >= state.totalPages) return;
        state.page = state.totalPages;
        await loadRecords(state.currentTabId);
        renderTable(false);
        const tw = $('#tableWrapper');
        if (tw) tw.scrollTop = 0;
    });
    pageSizeSelect.addEventListener('change', async () => {
        state.pageSize = parseInt(pageSizeSelect.value) || 50;
        state.page = 1;
        await loadRecords(state.currentTabId);
        renderTable(false);
        const tw = $('#tableWrapper');
        if (tw) tw.scrollTop = 0;
    });

    if (pageJumpBtn) {
        pageJumpBtn.addEventListener('click', async () => {
            const target = parseInt(pageJumpInput.value);
            if (target >= 1 && target <= state.totalPages && target !== state.page) {
                state.page = target;
                await loadRecords(state.currentTabId);
                renderTable(false);
            }
        });
    }
    if (pageJumpInput) {
        pageJumpInput.addEventListener('keydown', async (e) => {
            if (e.key === 'Enter' && pageJumpBtn) pageJumpBtn.click();
        });
    }

    // --- 右键菜单（共享标签：添加客户/删除行） ---
    let contextTargetId = null;
    let contextTargetColKey = null; // 右键点击所在列的 col_key（用于"复制选中"兜底复制单元格值）

    document.addEventListener('contextmenu', function(e) {
        const tr = e.target.closest('tr[data-id]');
        if (!tr) { contextMenu.style.display = 'none'; return; }
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        const tabType = tab ? tab.tab_type : 'dedicated';
        const isShared = tabType === 'shared';
        const isDedicated = tabType === 'dedicated';
        const isSimple = tabType === 'simple';
        if (!isShared && !isDedicated && !isSimple) { contextMenu.style.display = 'none'; return; }

        e.preventDefault();
        contextTargetId = parseInt(tr.dataset.id);
        // 解析右键点击所在列的 col_key（通过 td 在 tr 中的索引对齐 thead th 的 data-col）
        contextTargetColKey = null;
        try {
            const clickedTd = e.target.closest('td');
            if (clickedTd && tr.contains(clickedTd)) {
                const tdIdx = Array.prototype.indexOf.call(tr.children, clickedTd);
                const ths = document.querySelectorAll('#tableHead tr th');
                if (ths[tdIdx]) contextTargetColKey = ths[tdIdx].dataset.col || null;
            }
        } catch (err) { contextTargetColKey = null; }
        const recordType = tr.dataset.type || 'server';
        const targetRec = state.records.find(r => r.id === contextTargetId);
        // 独享/共享/简单标签：在上方插入一行/多行（普通标签也启用）
        ctxInsertMultiAbove.style.display = (isDedicated || isShared || isSimple) ? 'block' : 'none';
        ctxInsertAbove.style.display = (isDedicated || isShared || isSimple) ? 'block' : 'none';

        const isServerRow = recordType === 'server';
        // 动态切换服务器菜单项文本（独享/共享 → 服务器信息；普通 → 本行信息）
        if (isSimple) {
            ctxCopyServer.textContent = '✂️ 提取本行信息';
            ctxPasteServer.textContent = '📌 粘贴本行信息';
        } else {
            ctxCopyServer.textContent = '✂️ 提取服务器信息';
            ctxPasteServer.textContent = '📌 粘贴服务器信息';
        }
        // 空白行判定：
        //   独享：支出列总额 = 0
        //   共享：共享空白按收支 = 0（不变）
        //   普通：支出列=0 且 收入列=0 且 备注为空（用户要求：备注/支出/收入 都是0）
        const expenseTotal = targetRec ? (targetRec._hostExpenseTotal || targetRec._expenseTotal || 0) : 0;
        const incomeTotal = targetRec ? (targetRec._incomeTotal || 0) : 0;
        const remark = targetRec && targetRec.data ? (targetRec.data.remark || '').trim() : '';
        let isEmptyRow;
        if (isSimple) {
            isEmptyRow = (expenseTotal === 0 && incomeTotal === 0 && remark === '');
        } else {
            isEmptyRow = (expenseTotal === 0 && incomeTotal === 0);
        }

        if (isDedicated) {
            // ===== 独享标签：3个提取 + 3个粘贴（互斥）=====
            // 隐藏共享专用菜单
            ctxAddClient.style.display = 'none';
            ctxCopyClient.style.display = 'none';
            ctxPasteClient.style.display = 'none';

            // 粘贴菜单：根据提取类型互斥显示，且需满足条件
            // 粘贴服务器+客户信息：收入列和支出列都是0
            ctxPasteBoth.style.display = state.extractedBothData && incomeTotal === 0 && expenseTotal === 0 ? 'block' : 'none';
            // 粘贴服务器信息：支出列是0
            ctxPasteServer.style.display = state.copiedServerData && expenseTotal === 0 ? 'block' : 'none';
            // 粘贴客户信息：收入列是0
            ctxPasteExtractedClient.style.display = state.extractedClientData && incomeTotal === 0 ? 'block' : 'none';

            const anyPasteVisible = ctxPasteBoth.style.display === 'block'
                || ctxPasteServer.style.display === 'block'
                || ctxPasteExtractedClient.style.display === 'block';

            if (anyPasteVisible) {
                // 有可粘贴项时：只显示对应粘贴，隐藏所有提取（用户要求"只有粘贴"）
                ctxExtractBoth.style.display = 'none';
                ctxCopyServer.style.display = 'none';
                ctxExtractClient.style.display = 'none';
            } else {
                // 无可粘贴项时：显示3个提取菜单（允许提取/重新提取）
                ctxExtractBoth.style.display = 'block';
                ctxCopyServer.style.display = 'block';
                ctxExtractClient.style.display = 'block';
            }
        } else {
            // ===== 共享/简单标签：保持原有逻辑 =====
            // 隐藏独享专用菜单
            ctxExtractBoth.style.display = 'none';
            ctxPasteBoth.style.display = 'none';
            ctxExtractClient.style.display = 'none';
            ctxPasteExtractedClient.style.display = 'none';

            // 共享标签专用菜单
            ctxAddClient.style.display = (isShared && recordType === 'server') ? 'block' : 'none';
            ctxCopyClient.style.display = (isShared && recordType === 'client') ? 'block' : 'none';
            ctxPasteClient.style.display = (isShared && recordType === 'server' && state.copiedClientRecordId) ? 'block' : 'none';
            // 服务器提取/粘贴（共享+simple，原有逻辑：空白行条件）
            ctxCopyServer.style.display = (isShared || isSimple) && isServerRow ? 'block' : 'none';
            ctxPasteServer.style.display = (isShared || isSimple) && isServerRow && state.copiedServerData && isEmptyRow ? 'block' : 'none';
        }
        // 共享标签：服务器行不显示删除（有客户关联），客户行可以删除；独享标签不显示删除
        const canDelete = isShared ? (recordType === 'client') : false;
        ctxDeleteRecord.style.display = canDelete ? 'block' : 'none';
        // 批量粘贴：当选中了多个单元格时显示
        const ds = window._dragSelect;
        const hasMultiSelection = ds && ds.startRowId && ds.endRowId && ds.startRowId !== ds.endRowId && ds.colKey;
        ctxBatchPaste.style.display = hasMultiSelection ? 'block' : 'none';
        // 复制选中：独享/共享/普通标签都始终显示（支持三种"选中"方式）
        ctxCopySelected.style.display = (isDedicated || isShared || isSimple) ? 'block' : 'none';

        contextMenu.style.display = 'block';
        contextMenu.style.left = e.clientX + 'px';
        contextMenu.style.top = e.clientY + 'px';
        // 防止菜单被任务栏/视口底部遮挡
        setTimeout(() => {
            const menuRect = contextMenu.getBoundingClientRect();
            const viewportH = window.innerHeight || document.documentElement.clientHeight || 800;
            if (menuRect.bottom > viewportH - 8) {
                const newTop = Math.max(8, e.clientY - menuRect.height);
                contextMenu.style.top = newTop + 'px';
            }
            const viewportW = window.innerWidth || document.documentElement.clientWidth || 1200;
            if (menuRect.right > viewportW - 8) {
                const newLeft = Math.max(8, viewportW - menuRect.width - 8);
                contextMenu.style.left = newLeft + 'px';
            }
        }, 0);
    });

    document.addEventListener('click', function() { contextMenu.style.display = 'none'; });

    ctxInsertAbove.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.currentTabId) return;
        // 在目标行上方插入一行
        const targetRec = state.records.find(r => r.id === contextTargetId);
        if (!targetRec) return;
        try {
            setStatus('插入中...');
            const data = {};
            state.columns.forEach(col => { data[col.col_key] = ''; });
            const now = new Date();
            const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            const nextMonth = getNextMonth(now);
            data.host_purchase = today;
            data.months = 1;
            data.host_expire = calcHostExpire(today, 1);
            data.client_purchase = today;
            data.client_expire = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, '0')}-${String(nextMonth.getDate()).padStart(2, '0')}`;
            data.expense = '0';
            data.fee = '';
            data.address = 'IP地址';
            // sort_order 使用目标行的 sort_order
            const sortOrder = targetRec.sort_order || 0;
            await API.post('/records', {
                tab_id: state.currentTabId,
                data,
                record_type: 'server',
                sort_order: sortOrder
            });
            state.total++;
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('插入成功');
        } catch (err) { setStatus('插入失败: ' + err.message); }
    });

    ctxInsertMultiAbove.addEventListener('click', () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.currentTabId) return;
        insertMultiRowCount.value = 2;
        insertMultiRowModal.classList.add('show');
        setTimeout(() => insertMultiRowCount.focus(), 50);
    });

    function closeInsertMultiRow() {
        insertMultiRowModal.classList.remove('show');
    }
    if (closeInsertMultiRowModal) closeInsertMultiRowModal.addEventListener('click', closeInsertMultiRow);
    if (cancelInsertMultiRowBtn) cancelInsertMultiRowBtn.addEventListener('click', closeInsertMultiRow);
    insertMultiRowModal && insertMultiRowModal.addEventListener('click', (e) => { if (e.target === insertMultiRowModal) closeInsertMultiRow(); });

    if (insertMultiRowCount) {
        insertMultiRowCount.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') confirmInsertMultiRowBtn && confirmInsertMultiRowBtn.click();
        });
    }

    if (confirmInsertMultiRowBtn) confirmInsertMultiRowBtn.addEventListener('click', async () => {
        let count = parseInt(insertMultiRowCount.value);
        if (isNaN(count) || count < 1) count = 1;
        if (count > 50) count = 50;
        closeInsertMultiRow();
        if (!contextTargetId || !state.currentTabId) return;
        const targetRec = state.records.find(r => r.id === contextTargetId);
        if (!targetRec) return;
        try {
            setStatus('插入 ' + count + ' 行中...');
            const sortOrder = targetRec.sort_order || 0;
            const now = new Date();
            const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            const nextMonth = getNextMonth(now);
            const nextMonthStr = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, '0')}-${String(nextMonth.getDate()).padStart(2, '0')}`;
            for (let i = 0; i < count; i++) {
                const data = {};
                state.columns.forEach(col => { data[col.col_key] = ''; });
                data.host_purchase = today;
                data.months = 1;
                data.host_expire = calcHostExpire(today, 1);
                data.client_purchase = today;
                data.client_expire = nextMonthStr;
                data.expense = '0';
                data.fee = '';
                data.address = 'IP地址';
                await API.post('/records', {
                    tab_id: state.currentTabId,
                    data,
                    record_type: 'server',
                    sort_order: sortOrder
                });
                state.total++;
            }
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('已插入 ' + count + ' 行');
        } catch (err) { setStatus('插入失败: ' + err.message); }
    });

    ctxAddClient.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.currentTabId) return;
        await addRowClient(contextTargetId);
    });

    ctxCopyClient.addEventListener('click', () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId) return;
        const record = state.records.find(r => r.id === contextTargetId);
        if (!record || record.record_type !== 'client') return;
        state.copiedClientRecordId = record.id;
        $$('tr.client-row.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
        const tr = document.querySelector(`tr[data-id="${contextTargetId}"]`);
        if (tr) tr.classList.add('cut-pending');
        setStatus('客户信息已剪切 ✂️，请在目标服务器行右键粘贴');
    });

    ctxPasteClient.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.copiedClientRecordId || !state.currentTabId) {
            setStatus('无法粘贴：缺少目标或数据');
            return;
        }
        const parentRecord = state.records.find(r => r.id === contextTargetId);
        if (!parentRecord || parentRecord.record_type !== 'server') {
            setStatus('无法粘贴：请在服务器行上右键粘贴');
            return;
        }
        try {
            setStatus('移动中...');
            await API.post('/records/move', {
                record_id: state.copiedClientRecordId,
                new_parent_id: contextTargetId
            });
            state.copiedClientRecordId = null;
            $$('tr.client-row.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));

            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('客户已移动到新服务器 ✓');
        } catch (err) { setStatus('移动失败: ' + err.message); }
    });

    // ===== 独享标签：提取/粘贴 服务器信息 =====
    ctxCopyServer.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId) return;
        const record = state.records.find(r => r.id === contextTargetId);
        if (!record) return;
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        const isDedicatedTab = tab && tab.tab_type === 'dedicated';
        const isSimpleTab = tab && tab.tab_type === 'simple';
        // 尝试加载当前记录IP对应的主机信息（端口/用户名），粘贴时复制到目标IP
        let copiedHostInfo = null;
        if (record.data && record.data.ip_address) {
            try {
                const h = await API.get('/hosts/by-ip/' + encodeURIComponent(record.data.ip_address)).catch(() => null);
                if (h && h.host) copiedHostInfo = { name: h.name, host: h.host, port: h.port || 22, username: h.username, remark: h.remark };
            } catch(e) { copiedHostInfo = null; }
        }
        if (isDedicatedTab) {
            // 独享标签：提取服务器字段（服务商~IP信息 + 弹窗单价），支出明细通过API迁移
            const serverData = {};
            SERVER_FIELDS.forEach(k => { serverData[k] = record.data[k] !== undefined ? record.data[k] : ''; });
            state.copiedServerData = serverData;
            state.copiedServerHostInfo = copiedHostInfo;
            state.copiedServerRecordId = record.id;
            // 互斥：清空其他提取状态
            state.extractedClientData = null;
            state.extractedBothData = null;
            state.copiedClientRecordId = null;
            $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
            const tr = document.querySelector(`tr[data-id="${contextTargetId}"]`);
            if (tr) tr.classList.add('cut-pending');
            setStatus('本行信息已提取 ✂️，请在支出列为0的行右键粘贴');
        } else {
            // 共享标签：原有逻辑（只剪切服务器字段，迁移支出明细）
            // 普通标签：剪切整行——备注 + 所有支出明细 + 所有收入明细（用户要求"剪切"语义）
            if (isSimpleTab) {
                // 普通：剪切所有字段 + 迁移收入+支出明细（类似 ctxExtractBoth）
                state.copiedServerData = { ...record.data };
                state.copiedServerHostInfo = copiedHostInfo;
                state.copiedServerRecordId = record.id;
                state.copiedServerIsSimpleCut = true; // 标记：是普通标签的"全量剪切"
                // 互斥：清空其他提取状态
                state.extractedClientData = null;
                state.extractedBothData = null;
                state.copiedClientRecordId = null;
                $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
                const tr = document.querySelector(`tr[data-id="${contextTargetId}"]`);
                if (tr) tr.classList.add('cut-pending');
                setStatus('本行信息已提取 ✂️（含备注+支出+收入明细），请在空白行（备注/支出/收入均为0）右键粘贴');
            } else {
                // 共享标签：原有逻辑
                var hostTotal = record._hostExpenseTotal || 0;
                if (hostTotal === 0) {
                    if (!await showConfirm('当前0支出,确定剪切吗?')) return;
                }
                state.copiedServerData = { ...record.data };
                state.copiedServerHostInfo = copiedHostInfo;
                state.copiedServerRecordId = record.id;
                state.copiedServerIsSimpleCut = false;
                setStatus('服务器信息已提取，可在支出列为0的行右键粘贴');
            }
        }
    });

    ctxPasteServer.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.copiedServerData || !state.currentTabId) return;
        const targetRecord = state.records.find(r => r.id === contextTargetId);
        if (!targetRecord) return;
        const tab = state.tabs.find(t => t.id === state.currentTabId);
        const isDedicatedTab = tab && tab.tab_type === 'dedicated';
        const isSimpleTab = tab && tab.tab_type === 'simple';
        const isSimpleCut = !!state.copiedServerIsSimpleCut;
        if (isDedicatedTab) {
            // 独享标签：粘贴条件是支出列为0
            const expTotal = targetRecord._hostExpenseTotal || targetRecord._expenseTotal || 0;
            if (expTotal !== 0) {
                setStatus('粘贴失败：目标行支出列不为0');
                return;
            }
        } else if (isSimpleTab || isSimpleCut) {
            // 普通标签：空白行判定 = 支出0 + 收入0 + 备注为空（必须同时满足）
            const expTotal = targetRecord._hostExpenseTotal || targetRecord._expenseTotal || 0;
            const incTotal = targetRecord._incomeTotal || 0;
            const remark = (targetRecord.data && targetRecord.data.remark ? targetRecord.data.remark : '').trim();
            if (expTotal !== 0 || incTotal !== 0 || remark !== '') {
                setStatus('粘贴失败：目标行不是空白行（支出/收入/备注必须都为0）');
                return;
            }
        }
        try {
            setStatus(isSimpleTab ? '粘贴本行信息中...' : '粘贴服务器信息中...');
            const sourceId = state.copiedServerRecordId;
            // 跨标签：找出剪切来源记录所在的 tabId（不是当前 tab 时，粘贴后需要刷新来源 tab 的数据）
            let sourceTabId = null;
            if (sourceId) {
                const srcInCurrent = state.records.find(r => r.id === sourceId);
                if (srcInCurrent) sourceTabId = state.currentTabId;
                else {
                    for (const t of state.tabs) {
                        const cache = state.tabRecordCache && state.tabRecordCache[t.id];
                        if (cache && Array.isArray(cache) && cache.some(r => r.id === sourceId)) {
                            sourceTabId = t.id;
                            break;
                        }
                    }
                    if (!sourceTabId) sourceTabId = null;
                }
            }
            const updateData = { ...targetRecord.data };
            if (isDedicatedTab) {
                // 独享标签：只写服务器字段
                SERVER_FIELDS.forEach(k => {
                    updateData[k] = state.copiedServerData[k] !== undefined ? state.copiedServerData[k] : '';
                });
            } else if (isSimpleTab || isSimpleCut) {
                // 普通标签的全量剪切：把所有字段原样写入（包含 remark、所有单价、IP、收入 display fee、支出 display expense）
                Object.keys(state.copiedServerData).forEach(k => {
                    updateData[k] = state.copiedServerData[k] !== undefined && state.copiedServerData[k] !== null ? state.copiedServerData[k] : '';
                });
            } else {
                // 共享标签：写 OLD_SERVER_FIELDS
                const OLD_SERVER_FIELDS = ['provider', 'months', 'host_purchase', 'host_expire', 'host_remaining', 'ip_address', 'password', 'domain', 'remark', 'address', 'expense', 'ip_info', 'host_expense_unit_price', 'host_expense_extra', 'host_expense_remark', 'fee', 'income_unit_price', 'expense_unit_price'];
                OLD_SERVER_FIELDS.forEach(k => {
                    const val = state.copiedServerData[k];
                    updateData[k] = val !== undefined && val !== null ? val : '';
                });
            }
            // 迁移支出明细（把原行"支出列弹窗"里所有明细移动到目标行——这是剪切语义的核心）
            if (sourceId && sourceId !== contextTargetId) {
                try { await API.post('/host-expense/move', { from_record_id: sourceId, to_record_id: contextTargetId }); } catch(e) {}
                // 普通标签全量剪切：同时迁移收入明细和支出记录（expense_records）
                // ★ 普通标签的"支出列"显示的是 expense_records 表的汇总（_expenseTotal），
                //   不是 host_expense_details，所以必须迁移 expense_records 才能把支出列真正搬走
                if (isSimpleTab || isSimpleCut) {
                    try { await API.post('/income/migrate', { from_record_id: sourceId, to_record_id: contextTargetId }); } catch(e) {}
                    try { await API.post('/expense/migrate', { from_record_id: sourceId, to_record_id: contextTargetId }); } catch(e) {}
                }
                // 清空原行：只做"用户要求的最小清除"，其他信息保留不删（用户自行审核后手动清除）
                if (isDedicatedTab) {
                    // ★ 独享标签：原行不要清空服务器字段！只把"支出列弹窗"的明细通过 /host-expense/move 搬走即可。
                    // 不调用 /records/:id PUT 改写源行，其他信息（IP/服务商/备注/单价等）一律保留
                } else if (isSimpleTab || isSimpleCut) {
                    // ★ 普通标签：必须真正"剪切"—— 备注 清为空；支出显示 置0；收入显示 置空
                    //   （支出/收入弹窗内的明细已经通过 /host-expense/move 和 /income/migrate 迁移走了）
                    try {
                        const srcRec = state.records.find(r => r.id === sourceId);
                        const sourceData = srcRec
                            ? { ...srcRec.data, remark: '', expense: '0', fee: '' }
                            : { remark: '', expense: '0', fee: '' };
                        await API.put('/records/' + sourceId, { data: sourceData });
                    } catch(e) {}
                } else {
                    // ★ 共享标签：同独享——只把"支出列弹窗"明细搬走即可，其他服务器字段不清空
                    // 不调用 /records/:id PUT 改写源行
                }
            }
            await API.put('/records/' + contextTargetId, { data: updateData });
            // 把提取到的 IP 弹窗端口/用户名信息同步写入目标 IP 对应的 hosts 记录
            if (state.copiedServerHostInfo && updateData.ip_address && updateData.ip_address !== '') {
                try {
                    await API.post('/hosts/upsert-by-ip', {
                        name: state.copiedServerHostInfo.name || updateData.ip_address,
                        host: updateData.ip_address,
                        port: state.copiedServerHostInfo.port || 22,
                        username: state.copiedServerHostInfo.username || '',
                        remark: state.copiedServerHostInfo.remark || ''
                    }).catch(() => {});
                } catch(e) {}
            }
            state.copiedServerData = null;
            state.copiedServerHostInfo = null;
            state.copiedServerRecordId = null;
            state.copiedServerIsSimpleCut = false;
            $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            if (sourceTabId && sourceTabId !== state.currentTabId) {
                updateTabCache(sourceTabId);
                setStatus((isSimpleTab ? '本行信息' : '服务器信息') + '已粘贴 ✓（跨标签：来源标签已刷新缓存）');
            } else {
                setStatus((isSimpleTab ? '本行信息' : '服务器信息') + '已粘贴 ✓');
            }
        } catch (err) { setStatus('粘贴失败: ' + err.message); }
    });

    // ===== 独享标签：提取/粘贴 客户信息 =====
    ctxExtractClient.addEventListener('click', () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId) return;
        const record = state.records.find(r => r.id === contextTargetId);
        if (!record) return;
        // 客户信息：客户购买时间、客户到期时间、客户剩余天数、客户名、单价备注、收入明细
        const clientData = {};
        CLIENT_FIELDS.forEach(k => { clientData[k] = record.data[k] !== undefined ? record.data[k] : ''; });
        state.extractedClientData = {
            recordId: record.id,
            tabId: state.currentTabId,
            data: clientData
        };
        // 互斥：清空其他提取状态
        state.copiedServerData = null;
        state.copiedServerRecordId = null;
        state.extractedBothData = null;
        state.copiedClientRecordId = null;
        $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
        const tr = document.querySelector(`tr[data-id="${contextTargetId}"]`);
        if (tr) tr.classList.add('cut-pending');
        setStatus('客户信息已提取 ✂️，请在收入列为0的行右键粘贴');
    });

    ctxPasteExtractedClient.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.extractedClientData || !state.currentTabId) {
            setStatus('无法粘贴：缺少目标或提取的数据');
            return;
        }
        const targetRec = state.records.find(r => r.id === contextTargetId);
        if (!targetRec) return;
        // 粘贴条件：收入列为0
        const incTotal = targetRec._incomeTotal || 0;
        if (incTotal !== 0) {
            setStatus('粘贴失败：目标行收入列不为0');
            return;
        }
        try {
            setStatus('粘贴客户信息中...');
            const src = state.extractedClientData;
            // 1. 收入明细迁移
            if (src.recordId !== contextTargetId) {
                try { await API.post('/income/migrate', { from_record_id: src.recordId, to_record_id: contextTargetId }); } catch(e) {}
            }
            // 2. 将客户字段写入目标行
            const updateData = { ...targetRec.data };
            CLIENT_FIELDS.forEach(k => {
                updateData[k] = src.data[k] !== undefined ? src.data[k] : '';
            });
            await API.put('/records/' + contextTargetId, { data: updateData });
            // 3. 清空原行客户字段（移动语义）——支持跨标签：原行不在当前 state.records 时从后端获取
            if (src.recordId !== contextTargetId) {
                let srcData = null;
                const srcRec = state.records.find(r => r.id === src.recordId);
                if (srcRec) {
                    srcData = { ...srcRec.data };
                } else {
                    // 跨标签：从后端读取来源行的完整 data
                    try {
                        const r = await API.get('/records/' + src.recordId);
                        srcData = { ...(r.data || {}) };
                    } catch (e) { srcData = null; }
                }
                if (srcData) {
                    CLIENT_FIELDS.forEach(k => { srcData[k] = ''; });
                    try { await API.put('/records/' + src.recordId, { data: srcData }); } catch(e) {}
                }
            }
            state.extractedClientData = null;
            $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            // 跨标签：刷新来源标签缓存，这样切回去时原行客户字段已清空
            if (src.tabId && src.tabId !== state.currentTabId) {
                updateTabCache(src.tabId);
                setStatus('客户信息已粘贴 ✓（跨标签：来源标签已刷新缓存）');
            } else {
                setStatus('客户信息已粘贴 ✓');
            }
            renderTable(false);
        } catch (err) { setStatus('粘贴客户信息失败: ' + err.message); }
    });

    // ===== 独享标签：提取/粘贴 服务器+客户信息 =====
    ctxExtractBoth.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId) return;
        const record = state.records.find(r => r.id === contextTargetId);
        if (!record) return;
        // 提取服务器字段+客户字段（整行所有信息），同时尝试加载IP对应的主机信息
        let copiedHostInfo = null;
        if (record.data && record.data.ip_address) {
            try {
                const h = await API.get('/hosts/by-ip/' + encodeURIComponent(record.data.ip_address)).catch(() => null);
                if (h && h.host) copiedHostInfo = { name: h.name, host: h.host, port: h.port || 22, username: h.username, remark: h.remark };
            } catch(e) { copiedHostInfo = null; }
        }
        const bothData = {};
        SERVER_FIELDS.forEach(k => { bothData[k] = record.data[k] !== undefined ? record.data[k] : ''; });
        CLIENT_FIELDS.forEach(k => { bothData[k] = record.data[k] !== undefined ? record.data[k] : ''; });
        state.extractedBothData = {
            recordId: record.id,
            tabId: state.currentTabId,
            data: bothData,
            hostInfo: copiedHostInfo
        };
        // 互斥：清空其他提取状态
        state.copiedServerData = null;
        state.copiedServerHostInfo = null;
        state.copiedServerRecordId = null;
        state.copiedServerIsSimpleCut = false;
        state.extractedClientData = null;
        state.copiedClientRecordId = null;
        $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
        const tr = document.querySelector(`tr[data-id="${contextTargetId}"]`);
        if (tr) tr.classList.add('cut-pending');
        setStatus('服务器+客户信息已提取 ✂️，请在收入和支出列都为0的行右键粘贴');
    });

    ctxPasteBoth.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId || !state.extractedBothData || !state.currentTabId) {
            setStatus('无法粘贴：缺少目标或提取的数据');
            return;
        }
        const targetRec = state.records.find(r => r.id === contextTargetId);
        if (!targetRec) return;
        // 粘贴条件：收入列和支出列都是0
        const incTotal = targetRec._incomeTotal || 0;
        const expTotal = targetRec._hostExpenseTotal || targetRec._expenseTotal || 0;
        if (incTotal !== 0 || expTotal !== 0) {
            setStatus('粘贴失败：目标行收入列或支出列不为0');
            return;
        }
        try {
            setStatus('粘贴服务器+客户信息中...');
            const src = state.extractedBothData;
            // 1. 迁移支出明细 + 收入明细
            if (src.recordId !== contextTargetId) {
                try { await API.post('/host-expense/move', { from_record_id: src.recordId, to_record_id: contextTargetId }); } catch(e) {}
                try { await API.post('/income/migrate', { from_record_id: src.recordId, to_record_id: contextTargetId }); } catch(e) {}
            }
            // 2. 将服务器+客户字段写入目标行
            const updateData = { ...targetRec.data };
            [...SERVER_FIELDS, ...CLIENT_FIELDS].forEach(k => {
                updateData[k] = src.data[k] !== undefined ? src.data[k] : '';
            });
            await API.put('/records/' + contextTargetId, { data: updateData });
            // 2.1 把提取到的 IP 弹窗端口/用户名信息同步写入目标 IP 对应的 hosts 记录
            if (src.hostInfo && updateData.ip_address && updateData.ip_address !== '') {
                try {
                    await API.post('/hosts/upsert-by-ip', {
                        name: src.hostInfo.name || updateData.ip_address,
                        host: updateData.ip_address,
                        port: src.hostInfo.port || 22,
                        username: src.hostInfo.username || '',
                        remark: src.hostInfo.remark || ''
                    }).catch(() => {});
                } catch(e) {}
            }
            // 3. 清空原行所有服务器+客户字段（移动语义）——支持跨标签：原行不在当前 state.records 时从后端获取
            if (src.recordId !== contextTargetId) {
                let srcData = null;
                const srcRec = state.records.find(r => r.id === src.recordId);
                if (srcRec) {
                    srcData = { ...srcRec.data };
                } else {
                    // 跨标签：从后端读取来源行的完整 data
                    try {
                        const r = await API.get('/records/' + src.recordId);
                        srcData = { ...(r.data || {}) };
                    } catch (e) { srcData = null; }
                }
                if (srcData) {
                    [...SERVER_FIELDS, ...CLIENT_FIELDS].forEach(k => { srcData[k] = ''; });
                    try { await API.put('/records/' + src.recordId, { data: srcData }); } catch(e) {}
                }
            }
            state.extractedBothData = null;
            $$('tr.cut-pending').forEach(tr => tr.classList.remove('cut-pending'));
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            // 跨标签：刷新来源标签缓存，这样切回去时原行服务器+客户字段已清空
            if (src.tabId && src.tabId !== state.currentTabId) {
                updateTabCache(src.tabId);
                setStatus('服务器+客户信息已粘贴 ✓（跨标签：来源标签已刷新缓存）');
            } else {
                setStatus('服务器+客户信息已粘贴 ✓');
            }
            renderTable(false);
        } catch (err) { setStatus('粘贴失败: ' + err.message); }
    });

    ctxDeleteRecord.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        if (!contextTargetId) return;
        const r = state.records.find(x => x.id === contextTargetId);
        if (r) {
            const expenseTotal = r._hostExpenseTotal || r._expenseTotal || 0;
            const incomeTotal = r._incomeTotal || 0;
            if (expenseTotal !== 0 || incomeTotal !== 0) {
                await showConfirm('当前有支出或收入记录,不可以删除（支出和收入都为 0 才能删除）');
                return;
            }
        }
        if (!await showConfirm('确定删除此行？')) return;
        try {
            await API.delete('/records/' + contextTargetId);
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('已删除');
        } catch (err) { setStatus('删除失败: ' + err.message); }
    });

    ctxBatchPaste.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        const ds = window._dragSelect;
        if (!ds || !ds.startRowId || !ds.endRowId || ds.startRowId === ds.endRowId || !ds.colKey) return;
        // 多种方式读取剪贴板
        let text = '';
        try {
            if (navigator.clipboard && navigator.clipboard.readText) {
                text = await navigator.clipboard.readText();
            }
        } catch (e) {}
        if (!text) {
            // 提示用户使用 Ctrl+V
            setStatus('请使用 Ctrl+V 进行批量粘贴（菜单无法直接读取剪贴板）');
            // 触发一次 paste 事件
            const pasteEvent = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: new DataTransfer() });
            // 无法通过 ClipboardEvent 设置剪贴板内容，提示用户手动粘贴
            return;
        }
        if (text) doMultiPaste(ds, text);
    });

    // ===== 右键菜单：复制选中（只复制"用户实际选中"的内容，而非整行所有列）
    // 选中优先级：
    //   1) 浏览器原生选中文本（用户在输入框里选中了部分文字）→ 复制选中文本
    //   2) 拖拽区域选中（window._dragSelect，某列多行）→ 只复制选中列的单元格值（一列，用换行分隔）
    //   3) 右键点击的单元格（contextTargetId + contextTargetColKey）→ 复制该单元格值
    ctxCopySelected.addEventListener('click', async () => {
        contextMenu.style.display = 'none';
        setStatus('复制选中: 正在处理...');
        // 写入剪贴板的辅助函数（优先 textarea+execCommand，兼容 HTTP；失败回退 navigator.clipboard）
        async function writeClipboard(text) {
            let ok = false;
            try {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;';
                document.body.appendChild(ta);
                ta.focus();
                ta.select();
                ta.setSelectionRange(0, text.length);
                ok = document.execCommand('copy');
                document.body.removeChild(ta);
            } catch (e) { ok = false; }
            if (!ok) {
                try {
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        await navigator.clipboard.writeText(text);
                        ok = true;
                    }
                } catch (e) { ok = false; }
            }
            return ok;
        }

        // 从某个 record 的某个 colKey 读出显示值（与已有 copy 监听器口径一致）
        function readCellValue(rowId, colKey) {
            // 先尝试从正在编辑的输入框读当前值
            try {
                if (colKey === 'password') {
                    const cell = document.querySelector(`.password-cell[data-id="${rowId}"][data-col="${colKey}"]`);
                    if (cell) {
                        const input = cell.querySelector('.password-input');
                        if (input && input.style.display !== 'none') return input.value || '';
                    }
                }
                const input = document.querySelector(`input.cell-input[data-col="${colKey}"][data-id="${rowId}"]`);
                if (input && document.activeElement === input) return input.value || '';
            } catch (e) {}
            const rec = state.records.find(r => r.id === rowId);
            return rec && rec.data ? (rec.data[colKey] != null ? String(rec.data[colKey]) : '') : '';
        }

        try {
            // 1) 浏览器原生选中文本
            const sel = window.getSelection();
            const nativeText = sel ? sel.toString() : '';
            if (nativeText && nativeText.trim()) {
                const ok = await writeClipboard(nativeText);
                setStatus(ok ? '已复制选中文本到剪贴板' : '复制失败，请手动 Ctrl+C');
                return;
            }

            // 2) 拖拽选中（某列多行）→ 只复制选中列的单元格值
            const ds = window._dragSelect;
            if (ds && ds.colKey && ds.startRowId != null && ds.endRowId != null) {
                const tbodyTrs = document.querySelectorAll('#tableBody tr[data-id]');
                const order = [];
                tbodyTrs.forEach(tr => order.push(parseInt(tr.dataset.id)));
                const sIdx = order.indexOf(ds.startRowId);
                const eIdx = order.indexOf(ds.endRowId);
                if (sIdx !== -1 && eIdx !== -1) {
                    const [lo, hi] = sIdx < eIdx ? [sIdx, eIdx] : [eIdx, sIdx];
                    const values = [];
                    for (let i = lo; i <= hi; i++) {
                        values.push(readCellValue(order[i], ds.colKey));
                    }
                    if (values.length > 0) {
                        const ok = await writeClipboard(values.join('\n'));
                        setStatus(ok ? `已复制 ${values.length} 个值到剪贴板` : '复制失败，请手动 Ctrl+C');
                        return;
                    }
                }
            }

            // 3) 兜底：右键点击的单元格值
            if (contextTargetId && contextTargetColKey) {
                const v = readCellValue(contextTargetId, contextTargetColKey);
                const ok = await writeClipboard(v || '');
                setStatus(ok ? '已复制单元格值到剪贴板' : '复制失败，请手动 Ctrl+C');
                return;
            }

            setStatus('复制失败: 未选中具体内容（请先选中文字、拖拽选中单元格或右键点击单元格）');
        } catch (err) { setStatus('复制失败: ' + err.message); }
    });

    async function addRowClient(parentId) {
        if (!state.currentTabId) return;
        try {
            setStatus('添加中...');
            const data = {};
            state.columns.forEach(col => { data[col.col_key] = ''; });
            // New client defaults: today + 1 month (same day or last day of next month)
            const now = new Date();
            data.client_purchase = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            // +1 month: same day next month, or last day if overflow (e.g. 8-31 → 9-30)
            const expDate = new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
            // If day overflowed (e.g. 31 → next month has 30), JS auto-corrects to next-next month
            // Detect overflow and clamp to last day of next month + 1 day
            if (expDate.getMonth() !== now.getMonth() + 1 || (now.getMonth() === 11 && expDate.getMonth() !== 0)) {
                // Overflow occurred, use last day of next month + 1 day
                const lastDay = new Date(now.getFullYear(), now.getMonth() + 2, 0);
                expDate.setTime(lastDay.getTime() + 86400000); // +1 day
            }
            data.client_expire = `${expDate.getFullYear()}-${String(expDate.getMonth() + 1).padStart(2, '0')}-${String(expDate.getDate()).padStart(2, '0')}`;
            data.fee = '';

            const result = await API.post('/records', {
                tab_id: state.currentTabId,
                data,
                record_type: 'client',
                parent_id: parentId
            });
            await loadRecords(state.currentTabId);
            updateTabCache(state.currentTabId);
            renderTable(false);
            setStatus('客户已添加');
        } catch (err) { setStatus('添加客户失败: ' + err.message); }
    }

    document.getElementById('saveCertBtn').addEventListener('click', async function() {
        const certPath = document.getElementById('certPathInput').value.trim();
        const keyPath = document.getElementById('keyPathInput').value.trim();
        if (!certPath || !keyPath) { setStatus('⚠️ 请填写完整路径'); return; }
        try {
            await API.post('/settings/cert', { certPath, keyPath });
            setStatus('✅ 证书路径已保存，重启服务生效');
            document.getElementById('certStatus').textContent = '✅ 已保存，请重启服务';
        } catch (err) { setStatus('❌ 保存失败: ' + err.message); }
    });

    document.getElementById('setBgUrl').addEventListener('click', async function() {
        const url = document.getElementById('bgUrlInput').value.trim();
        if (!url) { setStatus('⚠️ 请输入URL'); return; }
        if (!/^https?:\/\//i.test(url)) { setStatus('⚠️ 图片地址必须以 http:// 或 https:// 开头'); return; }
        try {
            await API.post('/settings', { key: 'background', value: { type: 'url', url } });
            const preview = document.getElementById('bgPreview');
            preview.style.backgroundImage = `url("${cssUrl(url)}")`; preview.classList.add('has-bg'); preview.textContent = '';
            setStatus('✅ 背景已更新');
        } catch (err) { setStatus('❌ 设置失败: ' + err.message); }
    });
    document.getElementById('uploadBgBtn').addEventListener('click', () => document.getElementById('bgFileInput').click());
    document.getElementById('bgFileInput').addEventListener('change', async function() {
        const file = this.files[0];
        if (!file) return;
        try {
            setStatus('🔄 上传中...');
            const formData = new FormData();
            formData.append('image', file);
            const res = await fetch('/api/upload', { method: 'POST', credentials: 'include', body: formData });
            const data = await res.json().catch(() => ({ error: '服务器返回格式错误，请确认上传接口正常' }));
            if (!res.ok || data.error) throw new Error(data.error || '上传失败');
            if (data.success) {
                await API.post('/settings', { key: 'background', value: { type: 'local', path: data.url } });
                const preview = document.getElementById('bgPreview');
                preview.style.backgroundImage = `url("${cssUrl(data.url)}")`; preview.classList.add('has-bg'); preview.textContent = '';
                setStatus('✅ 背景已应用');
            } else { setStatus('❌ 上传失败: ' + (data.error || '')); }
        } catch (err) { setStatus('❌ 上传失败: ' + err.message); }
    });
    document.getElementById('removeBgBtn').addEventListener('click', async function() {
        if (!await showConfirm('确定移除背景吗？')) return;
        try {
            await API.delete('/settings/background');
            const preview = document.getElementById('bgPreview');
            preview.style.backgroundImage = ''; preview.classList.remove('has-bg'); preview.textContent = '暂无背景';
            setStatus('✅ 背景已移除');
        } catch (err) { setStatus('❌ 移除失败: ' + err.message); }
    });

    document.getElementById('uploadFaviconBtn').addEventListener('click', uploadFavicon);
    document.getElementById('faviconFileInput').addEventListener('change', () => document.getElementById('faviconStatus').textContent = '');
    // 网站 LOGO 控件
    try {
        const setLogoUrl = document.getElementById('setAppLogoUrlBtn');
        if (setLogoUrl) setLogoUrl.addEventListener('click', uploadAppLogoFromUrl);
        const uploadLogoBtn = document.getElementById('uploadAppLogoBtn');
        if (uploadLogoBtn) uploadLogoBtn.addEventListener('click', uploadAppLogoFromFile);
        const removeLogoBtn = document.getElementById('removeAppLogoBtn');
        if (removeLogoBtn) removeLogoBtn.addEventListener('click', removeAppLogo);
        const appLogoFileInput = document.getElementById('appLogoFileInput');
        if (appLogoFileInput) appLogoFileInput.addEventListener('change', () => { const s = document.getElementById('appLogoStatus'); if (s) s.textContent = ''; });
        const appLogoUrlInput = document.getElementById('appLogoUrlInput');
        if (appLogoUrlInput) appLogoUrlInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); uploadAppLogoFromUrl(); } });
    } catch (e) { /* 旧版本页面 DOM 缺元素时忽略 */ }
    saveRegisterSwitchBtn.addEventListener('click', saveRegisterSwitch);
    saveSuffixBtn.addEventListener('click', saveSuffixSettings);

    // 标题栏颜色设置
    const DEFAULT_HEADER_COLORS = { navbar: '#1a1a2e', navbarText: '#ffffff', menubar: '#16213e', menubarText: '#ffffff' };
    const navbarInput = document.getElementById('navbarColorInput');
    const navbarText = document.getElementById('navbarColorText');
    const navbarTextInput = document.getElementById('navbarTextColorInput');
    const navbarTextText = document.getElementById('navbarTextColorText');
    const menubarInput = document.getElementById('menubarColorInput');
    const menubarText = document.getElementById('menubarColorText');
    const menubarTextInput = document.getElementById('menubarTextColorInput');
    const menubarTextText = document.getElementById('menubarTextColorText');

    // 颜色选择器和文本框联动（底色+字体色各一组）
    function bindColorPair(colorInput, textInput) {
        if (!colorInput || !textInput) return;
        colorInput.addEventListener('input', () => { textInput.value = colorInput.value; });
        textInput.addEventListener('input', () => {
            if (/^#[0-9a-fA-F]{6}$/.test(textInput.value)) colorInput.value = textInput.value;
        });
    }
    bindColorPair(navbarInput, navbarText);
    bindColorPair(navbarTextInput, navbarTextText);
    bindColorPair(menubarInput, menubarText);
    bindColorPair(menubarTextInput, menubarTextText);

    // 重置按钮
    const resetNavbar = document.getElementById('resetNavbarColor');
    const resetNavbarText = document.getElementById('resetNavbarTextColor');
    const resetMenubar = document.getElementById('resetMenubarColor');
    const resetMenubarText = document.getElementById('resetMenubarTextColor');
    if (resetNavbar) resetNavbar.addEventListener('click', () => {
        if (navbarInput) navbarInput.value = DEFAULT_HEADER_COLORS.navbar;
        if (navbarText) navbarText.value = DEFAULT_HEADER_COLORS.navbar;
    });
    if (resetNavbarText) resetNavbarText.addEventListener('click', () => {
        if (navbarTextInput) navbarTextInput.value = DEFAULT_HEADER_COLORS.navbarText;
        if (navbarTextText) navbarTextText.value = DEFAULT_HEADER_COLORS.navbarText;
    });
    if (resetMenubar) resetMenubar.addEventListener('click', () => {
        if (menubarInput) menubarInput.value = DEFAULT_HEADER_COLORS.menubar;
        if (menubarText) menubarText.value = DEFAULT_HEADER_COLORS.menubar;
    });
    if (resetMenubarText) resetMenubarText.addEventListener('click', () => {
        if (menubarTextInput) menubarTextInput.value = DEFAULT_HEADER_COLORS.menubarText;
        if (menubarTextText) menubarTextText.value = DEFAULT_HEADER_COLORS.menubarText;
    });

    // 保存按钮
    const saveHeaderBtn = document.getElementById('saveHeaderColorBtn');
    if (saveHeaderBtn) saveHeaderBtn.addEventListener('click', async () => {
        const colors = {
            navbar: navbarInput ? navbarInput.value : DEFAULT_HEADER_COLORS.navbar,
            navbarText: navbarTextInput ? navbarTextInput.value : DEFAULT_HEADER_COLORS.navbarText,
            menubar: menubarInput ? menubarInput.value : DEFAULT_HEADER_COLORS.menubar,
            menubarText: menubarTextInput ? menubarTextInput.value : DEFAULT_HEADER_COLORS.menubarText
        };
        try {
            await API.post('/settings', { key: 'header_colors', value: colors });
            applyHeaderColors(colors);
            const status = document.getElementById('headerColorStatus');
            if (status) { status.textContent = '✅ 已保存'; setTimeout(() => status.textContent = '', 2000); }
            setStatus('✅ 标题栏颜色已保存');
        } catch (err) { setStatus('❌ 保存失败: ' + err.message); }
    });

    async function undoLastAction() {
        if (state.undoStack.length === 0) {
            setStatus('⚠️ 没有可撤销的操作');
            return;
        }
        const lastAction = state.undoStack.pop();
        try {
            if (lastAction.type === 'multi_paste') {
                lastAction.data.forEach(item => {
                    const record = state.records.find(r => r.id === item.recordId);
                    if (record) {
                        record.data[item.colKey] = item.oldValue;
                        if (item.oldHostExpire !== undefined) record.data.host_expire = item.oldHostExpire;
                        if (item.oldClientExpire !== undefined) record.data.client_expire = item.oldClientExpire;
                        record._updated = true;
                    }
                });
                await flushPendingSaves();
                renderTable(false);
                setStatus('✅ 已撤销批量粘贴操作');
            } else if (lastAction.type === 'cell_edit') {
                const record = state.records.find(r => r.id === lastAction.recordId);
                if (record) {
                    record.data[lastAction.colKey] = lastAction.oldValue;
                    if (lastAction.colKey === 'months' && lastAction.oldHostExpire !== null) {
                        record.data.host_expire = lastAction.oldHostExpire;
                    }
                    if (lastAction.colKey === 'ip_address' && lastAction.oldIpInfo !== null) {
                        record.data.ip_info = lastAction.oldIpInfo;
                    }
                    if (lastAction.colKey === 'host_purchase' && lastAction.oldHostExpire !== null) {
                        record.data.host_expire = lastAction.oldHostExpire;
                    }
                    if (lastAction.colKey === 'client_purchase' && lastAction.oldClientExpire !== null) {
                        record.data.client_expire = lastAction.oldClientExpire;
                    }
                    record._updated = true;
                    await saveRecord(record);
                    renderTable(false);
                    setStatus('✅ 已撤销单元格编辑');
                }
            } else if (lastAction.type === 'add_row') {
                await API.delete('/records/' + lastAction.recordId);
                state.selectedRows.delete(lastAction.recordId);
                await loadRecords(state.currentTabId);
                updateTabCache(state.currentTabId);
                renderTable(false);
                setStatus('✅ 已撤销添加行');
            } else if (lastAction.type === 'delete_rows') {
                const records = lastAction.records || [];
                for (const rec of records) {
                    await API.post('/records', {
                        tab_id: state.currentTabId,
                        data: rec.data,
                        record_type: rec.record_type,
                        parent_id: rec.parent_id,
                        sort_order: rec.sort_order
                    });
                }
                await loadRecords(state.currentTabId);
                updateTabCache(state.currentTabId);
                renderTable(false);
                setStatus(`✅ 已撤销删除 ${records.length} 条记录`);
            }
        } catch (err) {
            setStatus('❌ 撤销失败: ' + err.message);
        }
    }

    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'n') { e.preventDefault(); showAddRowModal(); }
        if (e.key === 'Delete' && !e.target.closest('input') && !e.target.closest('select')) deleteSelected();
        if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undoLastAction(); }
    });

    let tableLoadingStartTime = 0;
    const TABLE_LOADING_MIN_TIME = 300;
    function showTableLoading() {
        const el = document.getElementById('tableLoading');
        if (el) { el.classList.remove('hidden'); tableLoadingStartTime = Date.now(); }
    }
    function hideTableLoading() {
        const el = document.getElementById('tableLoading');
        if (!el) return;
        const elapsed = Date.now() - tableLoadingStartTime;
        const remaining = TABLE_LOADING_MIN_TIME - elapsed;
        if (remaining > 0) setTimeout(() => el.classList.add('hidden'), remaining);
        else el.classList.add('hidden');
    }

    // --- 初始化 ---
    async function init() {
        try {
            const auth = await API.get('/auth/check');
            if (!auth.loggedIn) { window.location.href = '/login'; return; }
            usernameDisplay.textContent = auth.user.username;
            state.userName = auth.user.username;
            state.isAdmin = (auth.user.id === 1);
            state.userId = auth.user.id;
            await loadProviderOptions();
            await loadTabs();
            // 从 localStorage 恢复筛选状态
            try {
                const savedFilters = localStorage.getItem('tabFilters_' + auth.user.id);
                if (savedFilters) state.tabFilters = JSON.parse(savedFilters);
                const savedHidden = localStorage.getItem('statsHidden_' + auth.user.id);
                if (savedHidden !== null) state.statsHidden = savedHidden === '1';
                const savedHighlight = localStorage.getItem('focusHighlightColor_' + auth.user.id);
                if (savedHighlight) state.focusHighlightColor = savedHighlight;
            } catch(e) {}
            if (state.tabs.length === 0) await createDefaultTab();
            else {
                state.currentTabId = state.tabs[0].id;
                state.filters = state.tabFilters[state.tabs[0].id] ? { ...state.tabFilters[state.tabs[0].id] } : {};
                await loadDataForTab(state.currentTabId);
            }
            collectProviderOptionsFromRecords();
            renderTabs();
            renderTable(false);
            setStatus('✅ 加载完成');
            const tab = state.tabs.find(t => t.id === state.currentTabId);
            if (tab) document.getElementById('columnModalTabName').textContent = tab.name;
            loadSettings();
            applyTableHighlightStyle();
            initVisualTabs();
            startHeartbeat();

            // 行焦点高亮事件委托：绑定一次，不依赖 renderTable 重新绑定
            (function bindRowFocusHighlight() {
                let currentHighlightRow = null;

                function clearHighlight() {
                    if (currentHighlightRow) {
                        currentHighlightRow.classList.remove('focus-highlight');
                        currentHighlightRow = null;
                    }
                }

                function setHighlight(e) {
                    const input = e.target.closest('.cell-input, .select-cell, .address-select, .provider-search-input, .months-input, .date-text-input, .expense-input, .password-input');
                    if (!input) return;
                    const tr = input.closest('tr');
                    if (!tr) return;
                    clearHighlight();
                    tr.classList.add('focus-highlight');
                    currentHighlightRow = tr;
                }

                document.addEventListener('focusin', setHighlight);
                document.addEventListener('focusout', clearHighlight);
            })();

            // open-link 事件委托：绑定一次，不依赖 renderTable 重新绑定
            document.addEventListener('click', function(e) {
                const btn = e.target.closest('.open-link');
                if (!btn) return;
                e.preventDefault();
                e.stopPropagation();
                const tr = btn.closest('tr');
                // 从同一行的 address-select 下拉框读取当前选中值（最可靠）
                const sel = tr ? tr.querySelector('.address-select') : null;
                const address = sel ? sel.value : (btn.dataset.address || '');
                if (!address) { setStatus('⚠️ 请先选择地址类型'); return; }
                let ip = btn.dataset.ip || '';
                let domain = btn.dataset.domain || '';
                // 判断是否为 IP 类型：选中值包含 "IP" 或为 "地址"
                const isIP = address.includes('IP') || address === '地址';
                if (isIP) {
                    if (!ip) {
                        const ipInput = tr ? tr.querySelector('input[data-col="ip_address"]') : null;
                        if (ipInput && ipInput.value.trim()) ip = ipInput.value.trim();
                    }
                    if (!ip) { setStatus('⚠️ IP地址为空'); return; }
                    let base = ip;
                    let suffix = state.ipPortSuffix || '';
                    const url = base + suffix;
                    let fullUrl = url;
                    if (!/^https?:\/\//i.test(fullUrl)) fullUrl = 'http://' + fullUrl;
                    window.open(fullUrl, '_blank');
                } else {
                    // 域名类型
                    if (!domain) {
                        const domainInput = tr ? tr.querySelector('input[data-col="domain"]') : null;
                        if (domainInput && domainInput.value.trim()) domain = domainInput.value.trim();
                    }
                    if (!domain) { setStatus('⚠️ 域名为空'); return; }
                    let base = domain;
                    let suffix = state.domainPortSuffix || '';
                    const url = base + suffix;
                    let fullUrl = url;
                    if (!/^https?:\/\//i.test(fullUrl)) fullUrl = 'http://' + fullUrl;
                    window.open(fullUrl, '_blank');
                }
            });

            initHostsModule();
            initMemosModule();
            hideTableLoading();
        } catch (err) { console.error('初始化失败:', err); setStatus('❌ 初始化失败: ' + err.message); hideTableLoading(); }
    }

    // --- 主机管理模块 ---
    let sshConnections = [];
    let activeConnId = null;
    let connIdCounter = 0;
    let hosts = [];
    let commandFolders = [];
    let currentHostTab = 'list';
    let hostContextMenu = null;
    let contextHostId = null;

    async function loadHosts() {
        try {
            const res = await fetch('/api/hosts');
            if (res.ok) hosts = await res.json();
            renderHosts();
        } catch (err) { console.error('加载主机列表失败:', err); }
    }

    function renderHosts() {
        const list = document.getElementById('hostsList');
        const searchInput = document.getElementById('hostSearchInput');
        const keyword = (searchInput?.value || '').trim().toLowerCase();

        let filtered = hosts;
        if (currentHostTab === 'favorite') {
            filtered = hosts.filter(h => h.is_favorite);
        }
        if (keyword) {
            filtered = filtered.filter(h =>
                (h.host || '').toLowerCase().includes(keyword) ||
                (h.name || '').toLowerCase().includes(keyword)
            );
        }

        const emptyMsg = currentHostTab === 'favorite'
            ? (keyword ? '未找到匹配的收藏主机' : '暂无收藏主机')
            : (keyword ? '未找到匹配的主机' : '暂无主机');

        if (!filtered.length) {
            list.innerHTML = '<div style="text-align:center;color:#999;padding:20px 0;">' + emptyMsg + '</div>';
            return;
        }
        list.innerHTML = filtered.map(h => `
            <div class="host-item" data-id="${h.id}">
                <div class="host-item-main">
                    <div class="host-name">${h.is_favorite ? '⭐ ' : ''}${escapeHtml(h.name)}</div>
                    <div class="host-info">${escapeHtml(h.username)}@${escapeHtml(h.host)}:${h.port || 22}</div>
                </div>
                <div class="host-item-actions">
                    <button class="host-connect-btn" data-id="${h.id}" title="连接">🔌</button>
                    <button class="host-edit-btn" data-id="${h.id}" title="编辑">✏️</button>
                    <button class="host-delete-btn" data-id="${h.id}" title="删除">🗑️</button>
                </div>
            </div>
        `).join('');
    }

    async function loadCommandFolders() {
        try {
            const res = await fetch('/api/commands/folders');
            if (res.ok) commandFolders = await res.json();
            renderFolders();
        } catch (err) { console.error('加载命令文件夹失败:', err); }
    }

    function renderFolders() {
        const list = document.getElementById('foldersList');
        if (!commandFolders.length) {
            list.innerHTML = '<div style="text-align:center;color:#999;padding:15px 0;font-size:12px;">暂无文件夹</div>';
            return;
        }
        list.innerHTML = commandFolders.map((f, idx) => `
            <div class="folder-item" data-id="${f.id}">
                <div class="folder-header">
                    <span class="folder-icon">📁</span>
                    <span class="folder-name">${escapeHtml(f.name)}</span>
                    <span class="folder-count">${f.commands?.length || 0}</span>
                    <div class="folder-actions">
                        <button class="folder-move-up-btn" data-id="${f.id}" title="上移" style="opacity:${idx === 0 ? 0.3 : 1};cursor:${idx === 0 ? 'not-allowed' : 'pointer'};">⬆️</button>
                        <button class="folder-move-down-btn" data-id="${f.id}" title="下移" style="opacity:${idx === commandFolders.length - 1 ? 0.3 : 1};cursor:${idx === commandFolders.length - 1 ? 'not-allowed' : 'pointer'};">⬇️</button>
                        <button class="folder-add-cmd-btn" data-id="${f.id}" title="添加命令">➕</button>
                        <button class="folder-edit-btn" data-id="${f.id}" title="重命名">✏️</button>
                        <button class="folder-delete-btn" data-id="${f.id}" title="删除">🗑️</button>
                    </div>
                </div>
                <div class="folder-commands" id="folder-cmds-${f.id}">
                    ${(f.commands || []).map(c => `
                        <div class="cmd-item" data-id="${c.id}">
                            <span class="cmd-name" title="点击执行">${escapeHtml(c.name)}</span>
                            <div class="cmd-actions">
                                <button class="cmd-copy-btn" data-id="${c.id}" title="复制命令">📋</button>
                                <button class="cmd-edit-btn" data-id="${c.id}" title="编辑">✏️</button>
                                <button class="cmd-delete-btn" data-id="${c.id}" title="删除">🗑️</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    function showAddHostModal(host = null) {
        const isEdit = !!host;
        const title = isEdit ? '编辑主机' : '添加主机';
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:480px;">
                <div class="modal-header">
                    <h2>${isEdit ? '✏️' : '➕'} ${title}</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>主机名称</label><input type="text" id="hostNameInput" value="${isEdit ? escapeAttr(host.name) : ''}" placeholder="例如：生产服务器" /></div>
                    <div class="input-group"><label>主机地址</label><input type="text" id="hostAddrInput" value="${isEdit ? escapeAttr(host.host) : ''}" placeholder="例如：192.168.1.1" /></div>
                    <div class="input-group"><label>端口</label><input type="number" id="hostPortInput" value="${isEdit ? (host.port || 22) : 22}" /></div>
                    <div class="input-group"><label>用户名</label><input type="text" id="hostUserInput" value="${isEdit ? escapeAttr(host.username) : ''}" placeholder="例如：root" /></div>
                    <div class="input-group"><label>密码</label><input type="password" id="hostPwdInput" value="" placeholder="请输入密码" /></div>
                    <div class="input-group"><label>备注</label><input type="text" id="hostRemarkInput" value="${isEdit ? escapeAttr(host.remark || '') : ''}" placeholder="可选" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveHostBtn">${isEdit ? '保存' : '添加'}</button>
                        <button class="tool-btn cancel-host-btn">取消</button>
                    </div>
                    <span id="hostStatus" style="color:#67c23a;display:block;margin-top:8px;"></span>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-host-btn').onclick = () => overlay.remove();

        overlay.querySelector('#saveHostBtn').onclick = async () => {
            const name = overlay.querySelector('#hostNameInput').value.trim();
            const hostAddr = overlay.querySelector('#hostAddrInput').value.trim();
            const port = parseInt(overlay.querySelector('#hostPortInput').value) || 22;
            const username = overlay.querySelector('#hostUserInput').value.trim();
            const password = overlay.querySelector('#hostPwdInput').value;
            const remark = overlay.querySelector('#hostRemarkInput').value.trim();
            const statusEl = overlay.querySelector('#hostStatus');

            if (!name) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入主机名称'; return; }
            if (!hostAddr) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入主机地址'; return; }
            if (!username) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入用户名'; return; }

            try {
                let res;
                if (isEdit) {
                    const body = { name, host: hostAddr, port, username, remark };
                    if (password) body.password = password;
                    res = await fetch(`/api/hosts/${host.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                } else {
                    res = await fetch('/api/hosts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, host: hostAddr, port, username, password, remark }) });
                }
                const data = await res.json();
                if (res.ok) {
                    statusEl.style.color = '#67c23a';
                    statusEl.textContent = data.message;
                    await loadHosts();
                    setTimeout(() => overlay.remove(), 600);
                } else {
                    statusEl.style.color = '#f56c6c';
                    statusEl.textContent = data.error || '操作失败';
                }
            } catch (err) {
                statusEl.style.color = '#f56c6c';
                statusEl.textContent = '请求失败: ' + err.message;
            }
        };
    }

    function showAddFolderModal(folder = null) {
        const isEdit = !!folder;
        const title = isEdit ? '重命名文件夹' : '新建文件夹';
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:360px;">
                <div class="modal-header">
                    <h2>${isEdit ? '✏️' : '📁'} ${title}</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>文件夹名称</label><input type="text" id="folderNameInput" value="${isEdit ? escapeAttr(folder.name) : ''}" placeholder="例如：常用命令" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveFolderBtn">${isEdit ? '保存' : '创建'}</button>
                        <button class="tool-btn cancel-folder-btn">取消</button>
                    </div>
                    <span id="folderStatus" style="color:#67c23a;display:block;margin-top:8px;"></span>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-folder-btn').onclick = () => overlay.remove();
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.querySelector('#saveFolderBtn').onclick = async () => {
            const name = overlay.querySelector('#folderNameInput').value.trim();
            const statusEl = overlay.querySelector('#folderStatus');
            if (!name) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入文件夹名称'; return; }

            try {
                let res;
                if (isEdit) {
                    res = await fetch(`/api/commands/folders/${folder.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
                } else {
                    res = await fetch('/api/commands/folders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
                }
                const data = await res.json();
                if (res.ok) {
                    statusEl.style.color = '#67c23a';
                    statusEl.textContent = data.message;
                    await loadCommandFolders();
                    setTimeout(() => overlay.remove(), 600);
                } else {
                    statusEl.style.color = '#f56c6c';
                    statusEl.textContent = data.error || '操作失败';
                }
            } catch (err) {
                statusEl.style.color = '#f56c6c';
                statusEl.textContent = '请求失败: ' + err.message;
            }
        };
    }

    function showAddCmdModal(folderId, cmd = null) {
        const isEdit = !!cmd;
        const title = isEdit ? '编辑命令' : '保存命令';
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:480px;">
                <div class="modal-header">
                    <h2>${isEdit ? '✏️' : '💾'} ${title}</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>命令名称</label><input type="text" id="cmdNameInput" value="${isEdit ? escapeAttr(cmd.name) : ''}" placeholder="例如：查看磁盘空间" /></div>
                    <div class="input-group"><label>命令内容</label><textarea id="cmdContentInput" rows="4" placeholder="例如：df -h">${isEdit ? escapeHtml(cmd.command) : ''}</textarea></div>
                    <div class="input-group"><label>备注</label><input type="text" id="cmdRemarkInput" value="${isEdit ? escapeAttr(cmd.remark || '') : ''}" placeholder="可选" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveCmdBtn">${isEdit ? '保存' : '添加'}</button>
                        <button class="tool-btn cancel-cmd-btn">取消</button>
                    </div>
                    <span id="cmdStatus" style="color:#67c23a;display:block;margin-top:8px;"></span>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-cmd-btn').onclick = () => overlay.remove();
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.querySelector('#saveCmdBtn').onclick = async () => {
            const name = overlay.querySelector('#cmdNameInput').value.trim();
            const command = overlay.querySelector('#cmdContentInput').value.trim();
            const remark = overlay.querySelector('#cmdRemarkInput').value.trim();
            const statusEl = overlay.querySelector('#cmdStatus');

            if (!name) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入命令名称'; return; }
            if (!command) { statusEl.style.color = '#f56c6c'; statusEl.textContent = '请输入命令内容'; return; }

            try {
                let res;
                if (isEdit) {
                    res = await fetch(`/api/commands/commands/${cmd.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, command, remark }) });
                } else {
                    res = await fetch('/api/commands/commands', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ folder_id: folderId, name, command, remark }) });
                }
                const data = await res.json();
                if (res.ok) {
                    statusEl.style.color = '#67c23a';
                    statusEl.textContent = data.message;
                    await loadCommandFolders();
                    setTimeout(() => overlay.remove(), 600);
                } else {
                    statusEl.style.color = '#f56c6c';
                    statusEl.textContent = data.error || '操作失败';
                }
            } catch (err) {
                statusEl.style.color = '#f56c6c';
                statusEl.textContent = '请求失败: ' + err.message;
            }
        };
    }

    function connectSSH(host) {
        const connId = ++connIdCounter;
        const terminal = document.getElementById('terminalContainer');
        const title = document.querySelector('.terminal-title');
        const input = document.getElementById('terminalInput');
        const sendBtn = document.getElementById('sendCmdBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        const fileManagerBtn = document.getElementById('fileManagerBtn');

        const wsProto = location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProto}//${location.host}/ssh`;
        const ws = new WebSocket(wsUrl);

        // 每个连接有自己的 xterm 容器和实例
        const xtermContainer = document.createElement('div');
        xtermContainer.style.cssText = 'width:100%;flex:1;min-height:0;display:none;';
        xtermContainer.dataset.connId = connId;
        terminal.appendChild(xtermContainer);
        const savedBg = localStorage.getItem('sshTerminalBg') || '#1e1e1e';
        const term = new Terminal({
            cursorBlink: true,
            fontSize: 13,
            fontFamily: 'Consolas, "Courier New", monospace',
            letterSpacing: 0,
            lineHeight: 1,
            allowTransparency: false,
            theme: {
                background: savedBg,
                foreground: '#e5e5e5',
                cursor: '#e5e5e5',
                selectionBackground: 'rgba(255,255,255,0.3)',
                black: '#000000', red: '#cd3131', green: '#0dbc79', yellow: '#e5e510',
                blue: '#2472c8', magenta: '#bc3fbc', cyan: '#11a8cd', white: '#e5e5e5',
                brightBlack: '#666666', brightRed: '#f14c4c', brightGreen: '#23d18b', brightYellow: '#f5f543',
                brightBlue: '#3b8eea', brightMagenta: '#d670d6', brightCyan: '#29b8db', brightWhite: '#ffffff'
            },
            scrollback: 5000,
            convertEol: false
        });
        // 注意：term.open 延迟到连接成功后再执行，避免容器 display:none 时 xterm 测量到 0 尺寸
        term._initialized = false;
        term._opened = false;

        // Fit 插件
        let fitAddon = null;
        try {
            if (window.FitAddon) {
                fitAddon = new FitAddon.FitAddon();
                term.loadAddon(fitAddon);
            }
        } catch (e) {}

        // xterm 输入发送到后端
        term.onData((data) => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'input', data: data }));
            }
        });

        // 点击 xterm 时确保获得焦点（全屏程序如 apt dialog 需要焦点在终端上）
        xtermContainer.addEventListener('mousedown', () => {
            setTimeout(() => term.focus(), 10);
        });

        // 窗口大小变化时调整终端
        const handleResize = () => {
            if (fitAddon && term._initialized) {
                try {
                    fitAddon.fit();
                    const cols = term.cols;
                    const rows = term.rows;
                    if (ws && ws.readyState === WebSocket.OPEN) {
                        ws.send(JSON.stringify({ type: 'resize', cols, rows }));
                    }
                } catch (e) {}
            }
        };
        window.addEventListener('resize', handleResize);

        const conn = {
            id: connId,
            host: host,
            ws: ws,
            clientPing: null,
            terminalContent: '',   // 保留用于后台连接时的缓冲
            xterm: term,
            xtermContainer: xtermContainer,
            fitAddon: fitAddon,
            handleResize: handleResize
        };
        sshConnections.push(conn);

        switchToConnection(connId);
        renderSshTabs();

        title.textContent = `正在连接 ${host.name} (${host.host}:${host.port})...`;

        const clientPing = setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'ping' }));
            }
        }, 25000);
        conn.clientPing = clientPing;

        ws.onopen = async () => {
            try {
                const pwdRes = await fetch(`/api/hosts/${host.id}/password`);
                const pwdData = await pwdRes.json();
                const password = pwdData.password || '';

                const savedProxies = localStorage.getItem('sshProxyConfigs');
                const savedActiveProxy = localStorage.getItem('sshActiveProxy');
                let proxy = { type: 'none' };

                if (savedProxies && savedActiveProxy) {
                    const proxies = JSON.parse(savedProxies);
                    const active = proxies.find(p => p.id === savedActiveProxy);
                    if (active) {
                        proxy = active;
                    }
                }

                ws.send(JSON.stringify({ type: 'connect', host: host.host, port: host.port, username: host.username, password, proxy }));
            } catch (err) {
                term.writeln('\r\n\x1b[31m获取密码失败: ' + err.message + '\x1b[0m');
            }
        };

        ws.onmessage = (event) => {
            try {
                const msg = JSON.parse(event.data);
                if (msg.type === 'connected') {
                    fetch(`/api/hosts/${host.id}/touch`, { method: 'POST' }).then(() => loadHosts()).catch(() => {});
                    if (activeConnId === connId) {
                        title.textContent = `${host.name} (${host.host}:${host.port}) - 已连接`;
                        input.disabled = false;
                        sendBtn.disabled = false;
                        disconnectBtn.style.display = 'inline-block';
                        disconnectBtn.textContent = '断开连接';
                        if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
                        // 隐藏占位符，显示 xterm
                        const placeholder = terminal.querySelector('.terminal-placeholder');
                        if (placeholder) placeholder.style.display = 'none';
                        if (!term._opened) {
                            term._opened = true;
                            term.open(xtermContainer);
                        }
                        xtermContainer.style.display = 'flex';
                        if (!term._initialized) {
                            term._initialized = true;
                            // 多次 fit 确保尺寸正确（容器刚显示时尺寸可能不稳定）
                            const fitAndResize = () => {
                                if (fitAddon) {
                                    try {
                                        fitAddon.fit();
                                        const cols = term.cols;
                                        const rows = term.rows;
                                        if (ws && ws.readyState === WebSocket.OPEN && cols > 0 && rows > 0) {
                                            ws.send(JSON.stringify({ type: 'resize', cols, rows }));
                                        }
                                    } catch (e) {}
                                }
                            };
                            requestAnimationFrame(() => {
                                fitAndResize();
                                setTimeout(fitAndResize, 50);
                                setTimeout(fitAndResize, 200);
                                setTimeout(fitAndResize, 500);
                                term.focus();
                            });
                        } else {
                            term.focus();
                        }
                    }
                    updateTabStatus(connId, 'connected');
                    startMonitor(connId);
                } else if (msg.type === 'output') {
                    if (activeConnId === connId && term._initialized) {
                        term.write(msg.data);
                    } else {
                        // 后台连接时缓冲，切换回来时一次性写入
                        conn.terminalContent += msg.data;
                    }
                } else if (msg.type === 'error') {
                    if (activeConnId === connId) {
                        term.writeln('\r\n\x1b[31m[错误] ' + msg.data + '\x1b[0m');
                        title.textContent = `${host.name} - 连接失败`;
                        input.disabled = true;
                        sendBtn.disabled = true;
                        disconnectBtn.style.display = 'inline-block';
                        disconnectBtn.textContent = '发起连接';
                        if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
                    }
                    updateTabStatus(connId, 'error');
                } else if (msg.type === 'disconnected') {
                    if (activeConnId === connId) {
                        title.textContent = `${host.name} - 已断开`;
                        term.writeln('\r\n\x1b[33m' + msg.data + '\x1b[0m');
                        input.disabled = true;
                        sendBtn.disabled = true;
                        disconnectBtn.style.display = 'inline-block';
                        disconnectBtn.textContent = '发起连接';
                        if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
                    }
                    updateTabStatus(connId, 'disconnected');
                    clearInterval(clientPing);
                    stopMonitor(connId);
                } else if (msg.type === 'sftp_list') {
                    handleSftpList(msg.data);
                    const filesTab = document.querySelector('[data-cmd-tab="files"]');
                    if (filesTab && filesTab.classList.contains('active')) {
                        renderFileListPanel(msg.data);
                    }
                } else if (msg.type === 'sftp_read') {
                    handleSftpRead(msg.data);
                } else if (msg.type === 'sftp_write') {
                    handleSftpWrite(msg.data);
                } else if (msg.type === 'sftp_upload') {
                    handleSftpUpload(msg.data);
                } else if (msg.type === 'sftp_delete') {
                    handleSftpDelete(msg.data);
                } else if (msg.type === 'sftp_download') {
                    handleSftpDownload(msg.data);
                } else if (msg.type === 'sftp_error') {
                    handleSftpError(msg.data);
                } else if (msg.type === 'monitor_data') {
                    handleMonitorData(msg.data, connId);
                } else if (msg.type === 'pong') {
                    handlePong(connId);
                }
            } catch (e) { console.error('消息解析失败:', e); }
        };

        ws.onerror = () => {
            if (conn.ws === ws) conn.ws = null;
            if (activeConnId === connId) {
                title.textContent = '连接失败';
                term.writeln('\r\n\x1b[31mWebSocket 连接失败\x1b[0m');
                input.disabled = true;
                sendBtn.disabled = true;
                disconnectBtn.style.display = 'inline-block';
                disconnectBtn.textContent = '发起连接';
                if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
            }
            updateTabStatus(connId, 'error');
            clearInterval(clientPing);
            stopMonitor(connId);
        };

        ws.onclose = () => {
            if (conn.ws === ws) conn.ws = null;
            clearInterval(clientPing);
            stopMonitor(connId);
            window.removeEventListener('resize', handleResize);
            if (activeConnId === connId && title.textContent.indexOf('已断开') === -1 && title.textContent.indexOf('连接失败') === -1) {
                title.textContent = `${host.name} - 连接已关闭`;
                term.writeln('\r\n\x1b[33m[连接已关闭]\x1b[0m');
                input.disabled = true;
                sendBtn.disabled = true;
                disconnectBtn.style.display = 'inline-block';
                disconnectBtn.textContent = '发起连接';
                if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
            }
            updateTabStatus(connId, 'closed');
        };
    }

    function disconnectOnly(connId) {
        const conn = sshConnections.find(c => c.id === connId);
        if (!conn) return;
        if (conn.ws) {
            try { conn.ws.close(); } catch(e) {}
            conn.ws = null;
        }
        if (conn.clientPing) clearInterval(conn.clientPing);
        stopMonitor(connId);
        updateTabStatus(connId, 'disconnected');
        if (activeConnId === connId) {
            const title = document.querySelector('.terminal-title');
            const input = document.getElementById('terminalInput');
            const sendBtn = document.getElementById('sendCmdBtn');
            const disconnectBtn = document.getElementById('disconnectBtn');
            const fileManagerBtn = document.getElementById('fileManagerBtn');
            const terminal = document.getElementById('terminalContainer');
            title.textContent = `${conn.host.name} - 已断开`;
            if (terminal) {
                const out = document.getElementById('terminalOutput');
                if (out) {
                    const span = document.createElement('span');
                    span.style.color = '#e6a23c';
                    span.textContent = '\n[连接已断开]\n';
                    out.appendChild(span);
                    out.scrollTop = out.scrollHeight;
                }
            }
            input.disabled = true;
            sendBtn.disabled = true;
            disconnectBtn.style.display = 'inline-block';
            disconnectBtn.textContent = '发起连接';
            if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
        }
    }

    function getActiveConn() {
        return sshConnections.find(c => c.id === activeConnId);
    }

    function getActiveWs() {
        const conn = getActiveConn();
        return conn ? conn.ws : null;
    }

    function renderSshTabs() {
        const tabsEl = document.getElementById('sshTabs');
        if (!tabsEl) return;
        if (sshConnections.length === 0) {
            tabsEl.style.display = 'none';
            return;
        }
        tabsEl.style.display = 'flex';
        tabsEl.innerHTML = sshConnections.map(c => `
            <div class="ssh-tab ${c.id === activeConnId ? 'active' : ''}" data-id="${c.id}" data-status="${c.status || 'connecting'}">
                <span class="ssh-tab-name">${escapeHtml(c.host.name)}</span>
                <span class="ssh-tab-close" data-id="${c.id}">✕</span>
            </div>
        `).join('');

        tabsEl.querySelectorAll('.ssh-tab').forEach(tab => {
            tab.onclick = (e) => {
                if (e.target.closest('.ssh-tab-close')) return;
                const id = parseInt(tab.dataset.id);
                switchToConnection(id);
            };
        });

        tabsEl.querySelectorAll('.ssh-tab-close').forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                closeConnection(id);
            };
        });
    }

    function switchToConnection(connId) {
        const conn = sshConnections.find(c => c.id === connId);
        if (!conn) return;

        activeConnId = connId;
        renderSshTabs();

        const terminal = document.getElementById('terminalContainer');
        const title = document.querySelector('.terminal-title');
        const input = document.getElementById('terminalInput');
        const sendBtn = document.getElementById('sendCmdBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        const fileManagerBtn = document.getElementById('fileManagerBtn');

        // 先隐藏所有 xterm 容器
        terminal.querySelectorAll('[data-conn-id]').forEach(el => {
            el.style.display = 'none';
        });

        const ws = conn.ws;
        const host = conn.host;
        const isOpen = ws && ws.readyState === WebSocket.OPEN;
        const term = conn.xterm;

        if (isOpen && term) {
            title.textContent = `${host.name} (${host.host}:${host.port}) - 已连接`;
            input.disabled = false;
            sendBtn.disabled = false;
            disconnectBtn.style.display = 'inline-block';
            disconnectBtn.textContent = '断开连接';
            if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
            // 隐藏占位符，显示 xterm
            const placeholder = terminal.querySelector('.terminal-placeholder');
            if (placeholder) placeholder.style.display = 'none';
            // 显示当前连接的 xterm 容器（用 flex 保持布局一致性）
            conn.xtermContainer.style.display = 'flex';
            // 如果 xterm 还没挂载到 DOM（后台连接成功时未 open），现在补 open
            // 否则 term.write / fitAddon.fit 都无效，界面会空白或滚动条位置错乱
            if (!term._opened) {
                term._opened = true;
                term.open(conn.xtermContainer);
            }
            // 如果有后台缓冲的数据，一次性写入
            if (conn.terminalContent && conn.terminalContent.length > 0) {
                term.write(conn.terminalContent);
                conn.terminalContent = '';
            }
            term._initialized = true;
            // 每次切换都重新 fit（容器从 none 变为可见时尺寸可能不准）
            // 多次 fit 确保尺寸正确（容器刚显示时尺寸可能不稳定）
            const fitAndResize = () => {
                if (conn.fitAddon) {
                    try {
                        conn.fitAddon.fit();
                        const cols = term.cols;
                        const rows = term.rows;
                        if (ws.readyState === WebSocket.OPEN && cols > 0 && rows > 0) {
                            ws.send(JSON.stringify({ type: 'resize', cols, rows }));
                        }
                    } catch (e) {}
                }
            };
            fitAndResize();
            setTimeout(fitAndResize, 50);
            setTimeout(fitAndResize, 200);
            setTimeout(fitAndResize, 500);
            term.focus();
            if (conn.monitorData) {
                updateMonitorUI(conn.monitorData);
            }
        } else if (ws && ws.readyState === WebSocket.CONNECTING) {
            title.textContent = `正在连接 ${host.name} (${host.host}:${host.port})...`;
            input.disabled = true;
            sendBtn.disabled = true;
            disconnectBtn.style.display = 'none';
            if (fileManagerBtn) fileManagerBtn.style.display = "none";
        } else {
            title.textContent = `${host.name} - 已断开`;
            input.disabled = true;
            sendBtn.disabled = true;
            disconnectBtn.style.display = 'inline-block';
            disconnectBtn.textContent = '发起连接';
            if (fileManagerBtn) fileManagerBtn.style.display = "inline-block";
            if (term && conn.xtermContainer) {
                conn.xtermContainer.style.display = 'block';
                if (conn.terminalContent && conn.terminalContent.length > 0) {
                    term.write(conn.terminalContent);
                    conn.terminalContent = '';
                }
            }
        }
    }

    function updateTabStatus(connId, status) {
        const conn = sshConnections.find(c => c.id === connId);
        if (conn) {
            conn.status = status;
        }
        renderSshTabs();
    }

    function closeConnection(connId, silent) {
        const idx = sshConnections.findIndex(c => c.id === connId);
        if (idx < 0) return;
        const conn = sshConnections[idx];
        if (conn.ws) {
            try { conn.ws.close(); } catch(e) {}
        }
        if (conn.clientPing) clearInterval(conn.clientPing);
        if (conn.handleResize) window.removeEventListener('resize', conn.handleResize);
        stopMonitor(connId);
        // 销毁 xterm 实例和容器
        if (conn.xterm) {
            try { conn.xterm.dispose(); } catch (e) {}
        }
        if (conn.xtermContainer && conn.xtermContainer.parentNode) {
            conn.xtermContainer.parentNode.removeChild(conn.xtermContainer);
        }
        sshConnections.splice(idx, 1);

        if (silent) return;

        if (activeConnId === connId) {
            if (sshConnections.length > 0) {
                const newIdx = Math.min(idx, sshConnections.length - 1);
                switchToConnection(sshConnections[newIdx].id);
            } else {
                activeConnId = null;
                renderSshTabs();
                const terminal = document.getElementById('terminalContainer');
                const title = document.querySelector('.terminal-title');
                const input = document.getElementById('terminalInput');
                const sendBtn = document.getElementById('sendCmdBtn');
                const disconnectBtn = document.getElementById('disconnectBtn');
                const fileManagerBtn = document.getElementById('fileManagerBtn');
                title.textContent = '请选择主机连接';
                terminal.innerHTML = `
                    <div class="terminal-placeholder">
                        <div style="font-size:48px;margin-bottom:16px;">🖥️</div>
                        <div style="color:#999;font-size:14px;">从左侧选择主机发起 SSH 连接</div>
                    </div>
                `;
                input.disabled = true;
                sendBtn.disabled = true;
                disconnectBtn.style.display = 'none';
                if (fileManagerBtn) fileManagerBtn.style.display = "none";
            }
        } else {
            renderSshTabs();
        }
    }

    let fileManagerState = {
        currentPath: '/root',
        files: [],
        editingFile: null,
        editingContent: '',
        overlay: null,
        contextMenu: null
    };

    function openFileManager() {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) {
            setStatus('⚠️ 请先连接主机');
            return;
        }

        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:720px;max-height:85vh;">
                <div class="modal-header">
                    <h2>📁 文件管理器</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body" style="display:flex;flex-direction:column;gap:12px;padding:16px;">
                    <div style="display:flex;gap:8px;align-items:center;">
                        <button class="tool-btn sm" id="fmBackBtn">⬅️ 上级</button>
                        <input id="fmPath" value="/root" title="输入路径后回车跳转" style="flex:1;font-family:monospace;font-size:13px;background:#f5f7fa;padding:6px 10px;border-radius:4px;border:1px solid #dcdfe6;outline:none;" />
                        <button class="tool-btn sm" id="fmRefreshBtn">🔄 刷新</button>
                        <button class="tool-btn sm" id="fmUploadBtn" style="background:#67c23a;color:#fff;">📤 上传文件</button>
                        <input type="file" id="fmFileInput" style="display:none;" />
                    </div>
                    <div id="fmFileList" style="flex:1;overflow-y:auto;border:1px solid #e4e7ed;border-radius:8px;min-height:300px;max-height:400px;">
                        <div style="text-align:center;color:#999;padding:40px 0;">加载中...</div>
                    </div>
                    <div id="fmEditor" style="display:none;flex-direction:column;gap:8px;">
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <span id="fmEditorTitle" style="font-weight:500;font-size:13px;">编辑文件</span>
                            <div style="display:flex;gap:8px;">
                                <button class="tool-btn sm" id="fmSaveBtn" style="background:#67c23a;color:#fff;">💾 保存</button>
                                <button class="tool-btn sm" id="fmCloseEditorBtn">关闭</button>
                            </div>
                        </div>
                        <textarea id="fmEditorContent" style="width:100%;height:200px;padding:10px;border:1px solid #dcdfe6;border-radius:6px;font-family:monospace;font-size:13px;resize:vertical;outline:none;"></textarea>
                        <span id="fmEditorStatus" style="font-size:12px;color:#67c23a;"></span>
                    </div>
                    <span id="fmStatus" style="font-size:12px;color:#909399;"></span>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        fileManagerState.overlay = overlay;
        fileManagerState.currentPath = '/root';
        fileManagerState.files = [];
        fileManagerState.editingFile = null;

        overlay.querySelector('.modal-close').onclick = () => closeFileManager();
        overlay.onclick = (e) => { if (e.target === overlay) closeFileManager(); };

        overlay.querySelector('#fmBackBtn').onclick = () => {
            const p = fileManagerState.currentPath;
            if (p === '/' || p === '') return;
            const parts = p.split('/').filter(Boolean);
            parts.pop();
            const parentPath = '/' + parts.join('/');
            loadFileList(parentPath || '/');
        };

        overlay.querySelector('#fmRefreshBtn').onclick = () => {
            loadFileList(fileManagerState.currentPath);
        };

        overlay.querySelector('#fmUploadBtn').onclick = () => {
            overlay.querySelector('#fmFileInput').click();
        };

        overlay.querySelector('#fmFileInput').onchange = (e) => {
            const file = e.target.files[0];
            if (file) uploadFile(file);
            e.target.value = '';
        };

        overlay.querySelector('#fmSaveBtn').onclick = () => saveFile();
        overlay.querySelector('#fmCloseEditorBtn').onclick = () => closeEditor();

        loadFileList('/root');
    }

    function closeFileManager() {
        hideFmContextMenu();
        if (fileManagerState.overlay) {
            fileManagerState.overlay.remove();
            fileManagerState.overlay = null;
        }
    }

    function openFileManagerPanel() {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        fileManagerState.currentPath = '/root';
        fileManagerState.files = [];
        loadFileListPanel('/root');
    }

    function loadFileListPanel(path) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        fileManagerState.currentPath = path;
        const fmPath = document.getElementById('fmPath');
        const fmList = document.getElementById('fmList');
        if (fmPath) fmPath.textContent = path;
        if (fmList) fmList.innerHTML = '<div style="text-align:center;color:#999;padding:30px 0;">加载中...</div>';
        getActiveWs().send(JSON.stringify({ type: 'sftp_list', path }));
    }

    function renderFileListPanel(data) {
        const fmPath = document.getElementById('fmPath');
        const fmList = document.getElementById('fmList');
        if (!fmList) return;
        fileManagerState.files = data.files || [];
        fileManagerState.currentPath = data.path;
        if (fmPath) fmPath.textContent = data.path;
        const files = data.files || [];
        if (files.length === 0) {
            fmList.innerHTML = '<div style="text-align:center;color:#999;padding:30px 0;">空目录</div>';
            return;
        }
        files.sort((a, b) => {
            if (a.isDir && !b.isDir) return -1;
            if (!a.isDir && b.isDir) return 1;
            return a.name.localeCompare(b.name);
        });
        fmList.innerHTML = files.map(f => {
            const icon = f.isDir ? '📁' : '📄';
            const sizeStr = f.isDir ? '' : formatFileSize(f.size);
            return `
                <div class="fm-item" data-name="${escapeHtml(f.name)}" data-dir="${f.isDir ? '1' : '0'}">
                    <span class="fm-item-icon">${icon}</span>
                    <span class="fm-item-name">${escapeHtml(f.name)}</span>
                    <span class="fm-item-size">${sizeStr}</span>
                </div>
            `;
        }).join('');
        fmList.querySelectorAll('.fm-item').forEach(item => {
            item.onclick = () => {
                const name = item.dataset.name;
                const isDir = item.dataset.dir === '1';
                if (isDir) {
                    const newPath = fileManagerState.currentPath.endsWith('/')
                        ? fileManagerState.currentPath + name
                        : fileManagerState.currentPath + '/' + name;
                    loadFileListPanel(newPath);
                }
            };
            item.oncontextmenu = (e) => {
                e.preventDefault();
                const name = item.dataset.name;
                const isDir = item.dataset.dir === '1';
                const fullPath = fileManagerState.currentPath.endsWith('/')
                    ? fileManagerState.currentPath + name
                    : fileManagerState.currentPath + '/' + name;
                showPanelContextMenu(e.clientX, e.clientY, fullPath, isDir);
            };
        });
    }

    function setFmPanelStatus(msg, color) {
        const statusEl = document.getElementById('fmStatus');
        if (statusEl) {
            statusEl.style.color = color || '#909399';
            statusEl.textContent = msg;
        }
    }

    function uploadFileToPanel(file) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        setFmPanelStatus(`上传中: ${file.name}...`, '#909399');
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1];
            const filePath = fileManagerState.currentPath.endsWith('/')
                ? fileManagerState.currentPath + file.name
                : fileManagerState.currentPath + '/' + file.name;
            getActiveWs().send(JSON.stringify({
                type: 'sftp_upload',
                path: filePath,
                content: base64
            }));
        };
        reader.readAsDataURL(file);
    }

    function showUploadMenu(anchorBtn) {
        hideUploadMenu();
        const menu = document.createElement('div');
        menu.className = 'fm-context-menu';
        menu.style.position = 'fixed';
        menu.style.zIndex = '10000';
        menu.style.minWidth = '140px';
        const rect = anchorBtn.getBoundingClientRect();
        menu.style.left = rect.left + 'px';
        menu.style.top = (rect.bottom + 2) + 'px';
        menu.innerHTML = `
            <div class="fm-context-item" data-action="local-upload">💻 本地上传</div>
            <div class="fm-context-item" data-action="system-upload">📦 系统上传</div>
        `;
        document.body.appendChild(menu);
        fileManagerState.uploadMenu = menu;

        menu.querySelector('[data-action="local-upload"]').onclick = () => {
            hideUploadMenu();
            document.getElementById('fmFileInput').click();
        };
        menu.querySelector('[data-action="system-upload"]').onclick = () => {
            hideUploadMenu();
            openSystemUploadDialog();
        };

        setTimeout(() => {
            document.addEventListener('click', hideUploadMenu, { once: true });
        }, 0);
    }

    function hideUploadMenu() {
        if (fileManagerState.uploadMenu) {
            fileManagerState.uploadMenu.remove();
            fileManagerState.uploadMenu = null;
        }
    }

    function openSystemUploadDialog() {
        // 先获取系统文件列表（通过后端API），在对话框中展示让用户选择
        fetch('/api/system-files/list')
            .then(res => res.json())
            .then(data => {
                if (!data.files || data.files.length === 0) {
                    showSystemFileUploadPrompt();
                    return;
                }
                showSystemFilePicker(data.files);
            })
            .catch(() => {
                showSystemFileUploadPrompt();
            });
    }

    function showSystemFileUploadPrompt() {
        const html = `
            <div style="padding:16px;">
                <h3 style="margin:0 0 12px;font-size:14px;">📦 系统上传</h3>
                <p style="color:#909399;font-size:12px;margin:0 0 12px;">暂无系统文件。请先将文件放入系统目录。</p>
                <input type="file" id="sysUploadInput" style="margin-bottom:12px;">
                <div style="text-align:right;">
                    <button class="tool-btn" onclick="closeModal('systemUploadModal')">关闭</button>
                </div>
            </div>
        `;
        showModal(html, 'systemUploadModal');
        const input = document.getElementById('sysUploadInput');
        if (input) input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const fd = new FormData();
            fd.append('file', file);
            setFmPanelStatus(`上传到系统: ${file.name}...`, '#909399');
            fetch('/api/system-files/upload', { method: 'POST', body: fd })
                .then(res => res.json())
                .then(data => {
                    if (data.error) {
                        setFmPanelStatus('❌ ' + data.error, '#f56c6c');
                    } else {
                        setFmPanelStatus('✅ 已上传到系统文件区', '#67c23a');
                        closeModal('systemUploadModal');
                        openSystemUploadDialog();
                    }
                })
                .catch(err => setFmPanelStatus('❌ ' + err.message, '#f56c6c'));
        };
    }

    function showSystemFilePicker(files) {
        const listHtml = files.map(f => `
            <div class="fm-item" data-name="${escapeHtml(f.name)}" data-size="${f.size || 0}">
                <span class="fm-item-icon">📄</span>
                <span class="fm-item-name">${escapeHtml(f.name)}</span>
                <span class="fm-item-size">${formatFileSize(f.size || 0)}</span>
            </div>
        `).join('');
        const html = `
            <div style="padding:16px;min-width:360px;">
                <h3 style="margin:0 0 12px;font-size:14px;">📦 选择系统文件上传到主机</h3>
                <div style="max-height:300px;overflow-y:auto;border:1px solid #e4e7ed;border-radius:6px;">
                    ${listHtml || '<div style="text-align:center;color:#999;padding:30px;">暂无文件</div>'}
                </div>
                <div style="margin-top:12px;text-align:right;display:flex;justify-content:space-between;">
                    <button class="tool-btn sm" onclick="document.getElementById('sysAddFileInput').click()">➕ 添加系统文件</button>
                    <div>
                        <button class="tool-btn" onclick="closeModal('systemFilePickerModal')">取消</button>
                    </div>
                </div>
                <input type="file" id="sysAddFileInput" style="display:none;">
            </div>
        `;
        showModal(html, 'systemFilePickerModal');

        document.querySelectorAll('#systemFilePickerModal .fm-item').forEach(item => {
            item.style.cursor = 'pointer';
            item.onclick = () => {
                const name = item.dataset.name;
                uploadSystemFileToHost(name);
                closeModal('systemFilePickerModal');
            };
        });

        const addInput = document.getElementById('sysAddFileInput');
        if (addInput) addInput.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const fd = new FormData();
            fd.append('file', file);
            fetch('/api/system-files/upload', { method: 'POST', body: fd })
                .then(res => res.json())
                .then(data => {
                    if (data.error) setStatus('❌ ' + data.error);
                    else { closeModal('systemFilePickerModal'); openSystemUploadDialog(); }
                })
                .catch(err => setStatus('❌ ' + err.message));
        };
    }

    function uploadSystemFileToHost(filename) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        setFmPanelStatus(`上传中: ${filename}...`, '#909399');
        fetch(`/api/system-files/download/${encodeURIComponent(filename)}`)
            .then(res => res.arrayBuffer())
            .then(buf => {
                let binary = '';
                const bytes = new Uint8Array(buf);
                for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
                const base64 = btoa(binary);
                const filePath = fileManagerState.currentPath.endsWith('/')
                    ? fileManagerState.currentPath + filename
                    : fileManagerState.currentPath + '/' + filename;
                getActiveWs().send(JSON.stringify({
                    type: 'sftp_upload',
                    path: filePath,
                    content: base64
                }));
            })
            .catch(err => setFmPanelStatus('❌ ' + err.message, '#f56c6c'));
    }

    function deleteFilePanel(filePath) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        showConfirm(`确定要删除文件 "${filePath}" 吗？此操作不可撤销。`, '删除文件').then(async (confirmed) => {
            if (!confirmed) return;
            setFmPanelStatus('删除中...', '#909399');
            getActiveWs().send(JSON.stringify({ type: 'sftp_delete', path: filePath }));
        });
    }

    function showPanelContextMenu(x, y, filePath, isDir) {
        hideFmContextMenu();
        const menu = document.createElement('div');
        menu.className = 'fm-context-menu';
        menu.style.left = x + 'px';
        menu.style.top = y + 'px';
        const downloadItem = !isDir ? '<div class="fm-context-item" data-action="download-file">⬇️ 下载文件</div>' : '';
        const editItem = !isDir ? '<div class="fm-context-item" data-action="edit-file">✏️ 在线编辑</div>' : '';
        menu.innerHTML = `
            <div class="fm-context-item" data-action="copy-path">📋 复制路径</div>
            ${editItem}
            ${downloadItem}
            <div class="fm-context-item" data-action="delete-file" style="color:#f56c6c;">🗑️ 删除文件</div>
        `;
        document.body.appendChild(menu);
        fileManagerState.contextMenu = menu;

        menu.querySelector('[data-action="copy-path"]').onclick = () => {
            copyToClipboard(filePath);
            hideFmContextMenu();
            setFmPanelStatus('✅ 路径已复制到剪贴板', '#67c23a');
        };

        if (!isDir) {
            menu.querySelector('[data-action="edit-file"]').onclick = () => {
                hideFmContextMenu();
                openFileEditor(filePath);
            };
            menu.querySelector('[data-action="download-file"]').onclick = () => {
                hideFmContextMenu();
                if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
                setFmPanelStatus('⏳ 正在下载...', '#409eff');
                getActiveWs().send(JSON.stringify({ type: 'sftp_download', path: filePath }));
            };
        }

        menu.querySelector('[data-action="delete-file"]').onclick = () => {
            hideFmContextMenu();
            deleteFilePanel(filePath);
        };

        setTimeout(() => {
            document.addEventListener('click', hideFmContextMenu, { once: true });
        }, 0);
    }

    function loadFileList(path) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        fileManagerState.currentPath = path;
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        overlay.querySelector('#fmPath').textContent = path;
        overlay.querySelector('#fmFileList').innerHTML = '<div style="text-align:center;color:#999;padding:40px 0;">加载中...</div>';
        overlay.querySelector('#fmStatus').textContent = '';
        getActiveWs().send(JSON.stringify({ type: 'sftp_list', path }));
    }

    function handleSftpList(data) {
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        fileManagerState.files = data.files || [];
        fileManagerState.currentPath = data.path;
        overlay.querySelector('#fmPath').textContent = data.path;

        const listEl = overlay.querySelector('#fmFileList');
        const files = data.files || [];
        if (files.length === 0) {
            listEl.innerHTML = '<div style="text-align:center;color:#999;padding:40px 0;">空目录</div>';
            return;
        }

        files.sort((a, b) => {
            if (a.isDir && !b.isDir) return -1;
            if (!a.isDir && b.isDir) return 1;
            return a.name.localeCompare(b.name);
        });

        listEl.innerHTML = files.map(f => {
            const icon = f.isDir ? '📁' : '📄';
            const sizeStr = f.isDir ? '' : formatFileSize(f.size);
            return `
                <div class="fm-file-item" data-name="${escapeHtml(f.name)}" data-dir="${f.isDir ? '1' : '0'}">
                    <span class="fm-file-icon">${icon}</span>
                    <span class="fm-file-name">${escapeHtml(f.name)}</span>
                    <span class="fm-file-size">${sizeStr}</span>
                    <span class="fm-file-actions">
                        ${!f.isDir ? '<button class="fm-edit-btn" title="编辑">✏️</button>' : ''}
                    </span>
                </div>
            `;
        }).join('');

        listEl.querySelectorAll('.fm-file-item').forEach(item => {
            item.onclick = (e) => {
                hideFmContextMenu();
                const name = item.dataset.name;
                const isDir = item.dataset.dir === '1';
                if (e.target.closest('.fm-edit-btn')) {
                    readFile(name);
                } else if (isDir) {
                    const newPath = fileManagerState.currentPath.endsWith('/')
                        ? fileManagerState.currentPath + name
                        : fileManagerState.currentPath + '/' + name;
                    loadFileList(newPath);
                }
            };
            item.oncontextmenu = (e) => {
                e.preventDefault();
                const name = item.dataset.name;
                const isDir = item.dataset.dir === '1';
                const fullPath = fileManagerState.currentPath.endsWith('/')
                    ? fileManagerState.currentPath + name
                    : fileManagerState.currentPath + '/' + name;
                showFmContextMenu(e.clientX, e.clientY, fullPath, isDir);
            };
        });
    }

    function showFmContextMenu(x, y, filePath, isDir) {
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        hideFmContextMenu();
        const menu = document.createElement('div');
        menu.className = 'fm-context-menu';
        menu.style.left = x + 'px';
        menu.style.top = y + 'px';
        const downloadItem = !isDir ? '<div class="fm-context-item" data-action="download-file">⬇️ 下载文件</div>' : '';
        const editItem = !isDir ? '<div class="fm-context-item" data-action="edit-file">✏️ 在线编辑</div>' : '';
        menu.innerHTML = `
            <div class="fm-context-item" data-action="copy-path">📋 复制路径</div>
            ${editItem}
            ${downloadItem}
            <div class="fm-context-item" data-action="delete-file" style="color:#f56c6c;">🗑️ 删除文件</div>
        `;
        document.body.appendChild(menu);
        fileManagerState.contextMenu = menu;

        menu.querySelector('[data-action="copy-path"]').onclick = () => {
            copyToClipboard(filePath);
            hideFmContextMenu();
            const overlay = fileManagerState.overlay;
            if (overlay) {
                const statusEl = overlay.querySelector('#fmStatus');
                statusEl.style.color = '#67c23a';
                statusEl.textContent = '✅ 路径已复制到剪贴板';
                setTimeout(() => { statusEl.textContent = ''; }, 2000);
            }
        };

        if (!isDir) {
            menu.querySelector('[data-action="edit-file"]').onclick = () => {
                hideFmContextMenu();
                openFileEditor(filePath);
            };
            menu.querySelector('[data-action="download-file"]').onclick = () => {
                hideFmContextMenu();
                if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
                const overlay = fileManagerState.overlay;
                if (overlay) {
                    const statusEl = overlay.querySelector('#fmStatus');
                    statusEl.style.color = '#409eff';
                    statusEl.textContent = '⏳ 正在下载...';
                }
                getActiveWs().send(JSON.stringify({ type: 'sftp_download', path: filePath }));
            };
        }

        menu.querySelector('[data-action="delete-file"]').onclick = () => {
            hideFmContextMenu();
            deleteFile(filePath);
        };

        setTimeout(() => {
            document.addEventListener('click', hideFmContextMenu, { once: true });
        }, 0);
    }

    function hideFmContextMenu() {
        if (fileManagerState.contextMenu) {
            fileManagerState.contextMenu.remove();
            fileManagerState.contextMenu = null;
        }
    }

    function copyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).catch(() => {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); } catch(e) {}
                document.body.removeChild(ta);
            });
        } else {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); } catch(e) {}
            document.body.removeChild(ta);
        }
    }

    // 文件在线编辑（模态框）
    const fileEditModal = {
        modal: null,
        pathEl: null,
        contentEl: null,
        statusEl: null,
        saveBtn: null,
        closeBtn: null,
        currentPath: null,
        originalContent: '',
        initialized: false
    };

    function initFileEditModal() {
        if (fileEditModal.initialized) return;
        fileEditModal.modal = document.getElementById('fileEditModal');
        fileEditModal.pathEl = document.getElementById('fileEditPath');
        fileEditModal.contentEl = document.getElementById('fileEditContent');
        fileEditModal.statusEl = document.getElementById('fileEditStatus');
        fileEditModal.saveBtn = document.getElementById('saveFileEditBtn');
        fileEditModal.closeBtn = document.getElementById('closeFileEditModal');

        if (fileEditModal.saveBtn) {
            fileEditModal.saveBtn.addEventListener('click', () => {
                saveFileEdit(true);
            });
        }
        if (fileEditModal.closeBtn) {
            fileEditModal.closeBtn.addEventListener('click', () => {
                tryCloseFileEdit();
            });
        }
        if (fileEditModal.modal) {
            fileEditModal.modal.addEventListener('click', (e) => {
                if (e.target === fileEditModal.modal) tryCloseFileEdit();
            });
        }
        // Ctrl+S 保存
        document.addEventListener('keydown', (e) => {
            if (!fileEditModal.modal || fileEditModal.modal.style.display === 'none') return;
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                saveFileEdit(true);
            }
        });
        fileEditModal.initialized = true;
    }

    function openFileEditor(filePath) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) {
            setStatus('⚠️ 请先连接主机');
            return;
        }
        initFileEditModal();
        if (!fileEditModal.modal) return;

        fileEditModal.currentPath = filePath;
        fileEditModal.originalContent = '';
        fileEditModal.pathEl.textContent = filePath;
        fileEditModal.contentEl.value = '';
        fileEditModal.contentEl.disabled = true;
        fileEditModal.saveBtn.disabled = true;
        fileEditModal.statusEl.style.color = '#909399';
        fileEditModal.statusEl.textContent = '⏳ 读取中...';
        fileEditModal.modal.style.display = 'flex';

        getActiveWs().send(JSON.stringify({ type: 'sftp_read', path: filePath, modal: true }));
    }

    function isFileEditDirty() {
        if (!fileEditModal.contentEl) return false;
        return fileEditModal.contentEl.value !== fileEditModal.originalContent;
    }

    async function tryCloseFileEdit() {
        initFileEditModal();
        if (isFileEditDirty()) {
            const confirmed = await showConfirm('文件已修改，是否保存并退出？（确定=保存，取消=不保存）', '保存确认');
            if (confirmed) {
                await saveFileEdit(true);
            } else {
                closeFileEditModal();
            }
        } else {
            closeFileEditModal();
        }
    }

    function closeFileEditModal() {
        initFileEditModal();
        if (fileEditModal.modal) fileEditModal.modal.style.display = 'none';
        fileEditModal.currentPath = null;
        fileEditModal.originalContent = '';
    }

    async function saveFileEdit(closeAfter) {
        initFileEditModal();
        if (!fileEditModal.currentPath || !fileEditModal.contentEl) return;
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;

        fileEditModal.saveBtn.disabled = true;
        fileEditModal.statusEl.style.color = '#909399';
        fileEditModal.statusEl.textContent = '⏳ 保存中...';

        const content = fileEditModal.contentEl.value;
        fileEditModal._closeAfterSave = closeAfter;
        getActiveWs().send(JSON.stringify({
            type: 'sftp_write',
            path: fileEditModal.currentPath,
            content: content,
            modal: true
        }));
    }

    function readFile(name) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        const filePath = fileManagerState.currentPath.endsWith('/')
            ? fileManagerState.currentPath + name
            : fileManagerState.currentPath + '/' + name;
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        overlay.querySelector('#fmStatus').textContent = '读取中...';
        overlay.querySelector('#fmStatus').style.color = '#909399';
        getActiveWs().send(JSON.stringify({ type: 'sftp_read', path: filePath }));
    }

    function handleSftpRead(data) {
        initFileEditModal();
        // 模态框编辑器
        if (fileEditModal.modal && fileEditModal.modal.style.display === 'flex' && fileEditModal.currentPath === data.path) {
            fileEditModal.originalContent = data.content || '';
            fileEditModal.contentEl.value = data.content || '';
            fileEditModal.contentEl.disabled = false;
            fileEditModal.saveBtn.disabled = false;
            fileEditModal.statusEl.style.color = '#67c23a';
            fileEditModal.statusEl.textContent = '✅ 读取完成';
            setTimeout(() => {
                if (fileEditModal.statusEl.textContent === '✅ 读取完成') {
                    fileEditModal.statusEl.textContent = '';
                }
            }, 1500);
            return;
        }
        // 面板编辑器（兼容旧代码）
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        fileManagerState.editingFile = data.path;
        fileManagerState.editingContent = data.content || '';
        const editorTitle = overlay.querySelector('#fmEditorTitle');
        if (editorTitle) editorTitle.textContent = '编辑: ' + data.path;
        const editorContent = overlay.querySelector('#fmEditorContent');
        if (editorContent) editorContent.value = data.content || '';
        const editorStatus = overlay.querySelector('#fmEditorStatus');
        if (editorStatus) editorStatus.textContent = '';
        const editor = overlay.querySelector('#fmEditor');
        if (editor) editor.style.display = 'flex';
        const fmStatus = overlay.querySelector('#fmStatus');
        if (fmStatus) fmStatus.textContent = '';
    }

    function saveFile() {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        const overlay = fileManagerState.overlay;
        if (!overlay || !fileManagerState.editingFile) return;
        const content = overlay.querySelector('#fmEditorContent').value;
        const statusEl = overlay.querySelector('#fmEditorStatus');
        statusEl.style.color = '#909399';
        statusEl.textContent = '保存中...';
        getActiveWs().send(JSON.stringify({
            type: 'sftp_write',
            path: fileManagerState.editingFile,
            content
        }));
    }

    function handleSftpWrite(data) {
        initFileEditModal();
        // 模态框编辑器
        if (fileEditModal.modal && fileEditModal.modal.style.display === 'flex' && fileEditModal.currentPath === data.path) {
            fileEditModal.saveBtn.disabled = false;
            fileEditModal.statusEl.style.color = '#67c23a';
            fileEditModal.statusEl.textContent = '✅ 保存成功';
            fileEditModal.originalContent = fileEditModal.contentEl.value;
            if (fileEditModal._closeAfterSave) {
                setTimeout(() => {
                    closeFileEditModal();
                    fileEditModal._closeAfterSave = false;
                }, 500);
            } else {
                setTimeout(() => { fileEditModal.statusEl.textContent = ''; }, 2000);
            }
            return;
        }
        // 面板编辑器（兼容旧代码）
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        const statusEl = overlay.querySelector('#fmEditorStatus');
        if (statusEl) {
            statusEl.style.color = '#67c23a';
            statusEl.textContent = '✅ 保存成功';
            setTimeout(() => { statusEl.textContent = ''; }, 2000);
        }
    }

    function closeEditor() {
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        overlay.querySelector('#fmEditor').style.display = 'none';
        fileManagerState.editingFile = null;
    }

    function uploadFile(file) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        overlay.querySelector('#fmStatus').style.color = '#909399';
        overlay.querySelector('#fmStatus').textContent = `上传中: ${file.name}...`;

        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1];
            const filePath = fileManagerState.currentPath.endsWith('/')
                ? fileManagerState.currentPath + file.name
                : fileManagerState.currentPath + '/' + file.name;
            getActiveWs().send(JSON.stringify({
                type: 'sftp_upload',
                path: filePath,
                content: base64
            }));
        };
        reader.readAsDataURL(file);
    }

    function handleSftpUpload(data) {
        const overlay = fileManagerState.overlay;
        if (overlay) {
            overlay.querySelector('#fmStatus').style.color = '#67c23a';
            overlay.querySelector('#fmStatus').textContent = '✅ 上传成功';
            loadFileList(fileManagerState.currentPath);
        }
        const filesTab = document.querySelector('[data-cmd-tab="files"]');
        if (filesTab && filesTab.classList.contains('active')) {
            setFmPanelStatus('✅ 上传成功', '#67c23a');
            loadFileListPanel(fileManagerState.currentPath);
        }
    }

    function handleSftpError(msg) {
        initFileEditModal();
        if (fileEditModal.modal && fileEditModal.modal.style.display === 'flex') {
            fileEditModal.saveBtn.disabled = false;
            fileEditModal.statusEl.style.color = '#f56c6c';
            fileEditModal.statusEl.textContent = '❌ ' + msg;
            return;
        }
        const overlay = fileManagerState.overlay;
        if (overlay) {
            overlay.querySelector('#fmStatus').style.color = '#f56c6c';
            overlay.querySelector('#fmStatus').textContent = '❌ ' + msg;
        }
        const filesTab = document.querySelector('[data-cmd-tab="files"]');
        if (filesTab && filesTab.classList.contains('active')) {
            setFmPanelStatus('❌ ' + msg, '#f56c6c');
        }
    }

    let monitorTimers = {};
    let monitorPingStart = {};
    let wsPingStart = {};

    function startMonitor(connId) {
        stopMonitor(connId);
        const conn = sshConnections.find(c => c.id === connId);
        if (!conn || !conn.ws || conn.ws.readyState !== WebSocket.OPEN) return;

        const doMonitor = () => {
            const c = sshConnections.find(x => x.id === connId);
            if (!c || !c.ws || c.ws.readyState !== WebSocket.OPEN) return;
            c.ws.send(JSON.stringify({ type: 'monitor' }));
        };

        const doPing = () => {
            const c = sshConnections.find(x => x.id === connId);
            if (!c || !c.ws || c.ws.readyState !== WebSocket.OPEN) return;
            wsPingStart[connId] = Date.now();
            c.ws.send(JSON.stringify({ type: 'ping' }));
        };

        doMonitor();
        doPing();
        monitorTimers[connId] = setInterval(() => {
            doMonitor();
            doPing();
        }, 1000);

        const status = document.getElementById('monitorStatus');
        if (status) status.classList.remove('offline');
    }

    function stopMonitor(connId) {
        if (monitorTimers[connId]) {
            clearInterval(monitorTimers[connId]);
            delete monitorTimers[connId];
        }
        delete monitorPingStart[connId];
        delete wsPingStart[connId];
        const status = document.getElementById('monitorStatus');
        if (status) status.classList.add('offline');
    }

    function handleMonitorData(data, connId) {
        if (!data || data.error) {
            console.log('监控数据错误:', data?.error || '无数据');
            return;
        }
        const conn = sshConnections.find(c => c.id === connId);
        if (!conn) return;

        const uptimeSec = parseInt(data.uptime) || 0;
        const days = Math.floor(uptimeSec / 86400);
        const hours = Math.floor((uptimeSec % 86400) / 3600);
        const mins = Math.floor((uptimeSec % 3600) / 60);
        let uptimeStr = '';
        if (days > 0) {
            uptimeStr = `${days}天${hours}小时`;
        } else if (hours > 0) {
            uptimeStr = `${hours}小时${mins}分`;
        } else {
            uptimeStr = `${mins}分钟`;
        }

        const load = data.load || '-';

        const memUsed = parseInt(data.mem_used) || 0;
        const memTotal = parseInt(data.mem_total) || 1;
        const memPercent = Math.round(memUsed * 100 / memTotal);
        const memStr = `${memUsed}M/${memTotal}M`;

        const swapUsed = parseInt(data.swap_used) || 0;
        const swapTotal = parseInt(data.swap_total) || 1;
        const swapPercent = swapTotal > 0 ? Math.round(swapUsed * 100 / swapTotal) : 0;
        const swapStr = swapTotal > 0 ? `${swapUsed}M/${swapTotal}M` : '0M/0M';

        const cpu = parseInt(data.cpu) || 0;
        const displayCpu = cpu > 0 || conn.lastCpu !== undefined ? (cpu > 0 ? cpu : conn.lastCpu || 0) : 0;
        if (cpu > 0) conn.lastCpu = cpu;
        const cpuCores = parseInt(data.cpu_cores) || (conn.monitorData?.cpu_cores ?? 0);

        const tcpRtt = data.tcp_rtt !== undefined ? data.tcp_rtt : (conn.monitorData?.tcp_rtt ?? null);
        const wsRtt = conn.monitorData?.ws_rtt ?? null;

        conn.monitorData = {
            uptime: uptimeStr,
            load,
            memPercent,
            memStr,
            swapPercent,
            swapStr,
            cpu: displayCpu,
            cpu_cores: cpuCores,
            tcp_rtt: tcpRtt,
            ws_rtt: wsRtt
        };

        if (activeConnId === connId) {
            updateMonitorUI(conn.monitorData);
        }
    }

    function handlePong(connId) {
        const pingMs = wsPingStart[connId] ? Date.now() - wsPingStart[connId] : null;
        const conn = sshConnections.find(c => c.id === connId);
        if (!conn) return;
        if (conn.monitorData) {
            conn.monitorData.ws_rtt = pingMs;
            if (activeConnId === connId) {
                const wsPingEl = document.getElementById('monitorWsPing');
                if (wsPingEl) wsPingEl.textContent = pingMs ? pingMs + 'ms' : '-';
            }
        }
    }

    function updateMonitorUI(d) {
        if (!d) return;
        const uptimeEl = document.getElementById('monitorUptime');
        const loadEl = document.getElementById('monitorLoad');
        const cpuBar = document.getElementById('monitorCpuBar');
        const cpuText = document.getElementById('monitorCpuText');
        const memBar = document.getElementById('monitorMemBar');
        const memText = document.getElementById('monitorMemText');
        const swapBar = document.getElementById('monitorSwapBar');
        const swapText = document.getElementById('monitorSwapText');
        const tcpPingEl = document.getElementById('monitorTcpPing');
        const wsPingEl = document.getElementById('monitorWsPing');

        if (uptimeEl) uptimeEl.textContent = d.uptime || '-';
        if (loadEl) loadEl.textContent = d.load || '-';

        if (cpuBar) {
            cpuBar.style.setProperty('--bar-width', (d.cpu || 0) + '%');
            cpuBar.className = 'monitor-bar' + (d.cpu > 80 ? ' danger' : d.cpu > 60 ? ' warning' : '');
        }
        if (cpuText) {
            const cores = d.cpu_cores ? d.cpu_cores + 'C/' : '';
            cpuText.textContent = cores + (d.cpu || 0) + '%';
        }

        if (memBar) {
            memBar.style.setProperty('--bar-width', (d.memPercent || 0) + '%');
            memBar.className = 'monitor-bar' + (d.memPercent > 80 ? ' danger' : d.memPercent > 60 ? ' warning' : '');
        }
        if (memText) memText.textContent = (d.memPercent || 0) + '% ' + (d.memStr || '');

        if (swapBar) {
            swapBar.style.setProperty('--bar-width', (d.swapPercent || 0) + '%');
            swapBar.className = 'monitor-bar' + (d.swapPercent > 80 ? ' danger' : d.swapPercent > 60 ? ' warning' : '');
        }
        if (swapText) swapText.textContent = (d.swapPercent || 0) + '% ' + (d.swapStr || '');

        if (tcpPingEl) tcpPingEl.textContent = (d.tcp_rtt !== null && d.tcp_rtt !== undefined) ? d.tcp_rtt + 'ms' : '-';
        if (wsPingEl) wsPingEl.textContent = (d.ws_rtt !== null && d.ws_rtt !== undefined) ? d.ws_rtt + 'ms' : '-';
    }

    function deleteFile(filePath) {
        if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) return;
        const overlay = fileManagerState.overlay;
        if (!overlay) return;
        showConfirm(`确定要删除文件 "${filePath}" 吗？此操作不可撤销。`, '删除文件').then(async (confirmed) => {
            if (!confirmed) return;
            overlay.querySelector('#fmStatus').style.color = '#909399';
            overlay.querySelector('#fmStatus').textContent = '删除中...';
            getActiveWs().send(JSON.stringify({ type: 'sftp_delete', path: filePath }));
        });
    }

    function handleSftpDelete(data) {
        const overlay = fileManagerState.overlay;
        if (overlay) {
            overlay.querySelector('#fmStatus').style.color = '#67c23a';
            overlay.querySelector('#fmStatus').textContent = '✅ 删除成功';
            loadFileList(fileManagerState.currentPath);
        }
        const filesTab = document.querySelector('[data-cmd-tab="files"]');
        if (filesTab && filesTab.classList.contains('active')) {
            setFmPanelStatus('✅ 删除成功', '#67c23a');
            loadFileListPanel(fileManagerState.currentPath);
        }
    }

    function handleSftpDownload(data) {
        const overlay = fileManagerState.overlay;
        const filesTab = document.querySelector('[data-cmd-tab="files"]');
        const isPanelActive = filesTab && filesTab.classList.contains('active');
        if (!data || !data.content) {
            if (overlay) {
                overlay.querySelector('#fmStatus').style.color = '#f56c6c';
                overlay.querySelector('#fmStatus').textContent = '❌ 下载失败';
            }
            if (isPanelActive) setFmPanelStatus('❌ 下载失败', '#f56c6c');
            return;
        }
        try {
            const binary = atob(data.content);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            const blob = new Blob([bytes]);
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = data.name || 'download';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            if (overlay) {
                overlay.querySelector('#fmStatus').style.color = '#67c23a';
                overlay.querySelector('#fmStatus').textContent = '✅ 下载成功';
                setTimeout(() => { overlay.querySelector('#fmStatus').textContent = ''; }, 2000);
            }
            if (isPanelActive) {
                setFmPanelStatus('✅ 下载成功', '#67c23a');
                setTimeout(() => setFmPanelStatus('', ''), 2000);
            }
        } catch (e) {
            if (overlay) {
                overlay.querySelector('#fmStatus').style.color = '#f56c6c';
                overlay.querySelector('#fmStatus').textContent = '❌ 下载失败: ' + e.message;
            }
            if (isPanelActive) setFmPanelStatus('❌ 下载失败: ' + e.message, '#f56c6c');
        }
    }

    function formatFileSize(bytes) {
        if (!bytes) return '0 B';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    }

    function ansiToHtml(text) {
        // ANSI SGR 颜色映射
        const colorMap = {
            30: '#000000', 31: '#cd3131', 32: '#0dbc79', 33: '#e5e510',
            34: '#2472c8', 35: '#bc3fbc', 36: '#11a8cd', 37: '#e5e5e5',
            90: '#666666', 91: '#f14c4c', 92: '#23d18b', 93: '#f5f543',
            94: '#3b8eea', 95: '#d670d6', 96: '#29b8db', 97: '#e5e5e5'
        };
        const bgColorMap = {
            40: '#000000', 41: '#cd3131', 42: '#0dbc79', 43: '#e5e510',
            44: '#2472c8', 45: '#bc3fbc', 46: '#11a8cd', 47: '#e5e5e5',
            100:'#666666', 101:'#f14c4c', 102:'#23d18b', 103:'#f5f543',
            104:'#3b8eea', 105:'#d670d6', 106:'#29b8db', 107:'#e5e5e5'
        };

        let result = '';
        let i = 0;
        let currentFg = '';
        let currentBg = '';
        let currentBold = false;
        let spanOpen = false;

        function closeSpan() {
            if (spanOpen) { result += '</span>'; spanOpen = false; }
        }
        function openSpan() {
            closeSpan();
            let style = '';
            if (currentFg) style += 'color:' + currentFg + ';';
            if (currentBg) style += 'background-color:' + currentBg + ';';
            if (currentBold) style += 'font-weight:bold;';
            if (style) { result += '<span style="' + style + '">'; spanOpen = true; }
        }

        while (i < text.length) {
            const code = text.charCodeAt(i);

            // ==== C0 控制字符的过滤（避免乱码显示原始字节）====
            if (code === 27 /* ESC */) {
                // 处理 ESC 开头的序列：CSI (ESC [)、SS2/SS3、OSC 等
                const next = text.charAt(i + 1);
                if (next === '[') {
                    // CSI 序列：ESC [ ... 终止字节 (0x40 - 0x7E)
                    let j = i + 2;
                    let params = '';
                    let hasPrivate = false;
                    // 跳过可选 private 前缀字符 (? / > 等 0x3C-0x3F)
                    while (j < text.length) {
                        const c = text.charCodeAt(j);
                        if (c >= 0x3C && c <= 0x3F && params.length === 0) {
                            hasPrivate = true;
                            params += text.charAt(j);
                            j++;
                            continue;
                        }
                        break;
                    }
                    while (j < text.length) {
                        const c = text.charCodeAt(j);
                        // 参数字节 0x30-0x39 ; 0x30-0x3F (包含分号/问号/<>=等)
                        if ((c >= 0x30 && c <= 0x3F) || c === 0x3A) {
                            params += text.charAt(j);
                            j++;
                        } else if (c >= 0x20 && c <= 0x2F) {
                            // 中间字节
                            j++;
                        } else if (c >= 0x40 && c <= 0x7E) {
                            // 终止符：命令字节
                            const cmd = text.charAt(j);
                            if (cmd === 'm') {
                                // SGR 颜色/样式
                                const sgrParams = params.replace(/^[?<>]/, '');
                                const codes = sgrParams === '' ? [0] : sgrParams.split(';').map(x => {
                                    const n = parseInt(x, 10);
                                    return isNaN(n) ? 0 : n;
                                });
                                if (codes.length === 0 || (codes.length === 1 && codes[0] === 0)) {
                                    currentFg = ''; currentBg = ''; currentBold = false;
                                    closeSpan();
                                } else {
                                    for (let k = 0; k < codes.length; k++) {
                                        const cd = codes[k];
                                        if (cd === 0) { currentFg = ''; currentBg = ''; currentBold = false; closeSpan(); }
                                        else if (cd === 1) { currentBold = true; }
                                        else if (cd === 22) { currentBold = false; }
                                        else if (cd >= 30 && cd <= 37) { currentFg = colorMap[cd]; }
                                        else if (cd >= 40 && cd <= 47) { currentBg = bgColorMap[cd]; }
                                        else if (cd >= 90 && cd <= 97) { currentFg = colorMap[cd]; }
                                        else if (cd >= 100 && cd <= 107) { currentBg = bgColorMap[cd]; }
                                        else if (cd === 38 && codes[k + 1] === 5 && k + 2 < codes.length) {
                                            const idx = codes[k + 2];
                                            if (idx >= 0 && idx <= 15) {
                                                const map256 = {0:'#000000',1:'#800000',2:'#008000',3:'#808000',4:'#000080',5:'#800080',6:'#008080',7:'#c0c0c0',8:'#808080',9:'#ff0000',10:'#00ff00',11:'#ffff00',12:'#0000ff',13:'#ff00ff',14:'#00ffff',15:'#ffffff'};
                                                currentFg = map256[idx] || '#e5e5e5';
                                            } else if (idx >= 16 && idx <= 231) {
                                                const r = Math.floor((idx - 16) / 36); const g = Math.floor(((idx - 16) % 36) / 6); const b = (idx - 16) % 6;
                                                const rv = r === 0 ? 0 : 55 + r * 40; const gv = g === 0 ? 0 : 55 + g * 40; const bv = b === 0 ? 0 : 55 + b * 40;
                                                currentFg = 'rgb(' + rv + ',' + gv + ',' + bv + ')';
                                            } else if (idx >= 232 && idx <= 255) {
                                                const gray = 8 + (idx - 232) * 10;
                                                currentFg = 'rgb(' + gray + ',' + gray + ',' + gray + ')';
                                            }
                                            k += 2;
                                        } else if (cd === 38 && codes[k + 1] === 2 && k + 4 < codes.length) {
                                            currentFg = 'rgb(' + codes[k + 2] + ',' + codes[k + 3] + ',' + codes[k + 4] + ')';
                                            k += 4;
                                        } else if (cd === 48 && codes[k + 1] === 5 && k + 2 < codes.length) {
                                            const idx = codes[k + 2];
                                            if (idx >= 0 && idx <= 15) {
                                                const map256 = {0:'#000000',1:'#800000',2:'#008000',3:'#808000',4:'#000080',5:'#800080',6:'#008080',7:'#c0c0c0',8:'#808080',9:'#ff0000',10:'#00ff00',11:'#ffff00',12:'#0000ff',13:'#ff00ff',14:'#00ffff',15:'#ffffff'};
                                                currentBg = map256[idx] || '#000000';
                                            } else if (idx >= 16 && idx <= 231) {
                                                const r = Math.floor((idx - 16) / 36); const g = Math.floor(((idx - 16) % 36) / 6); const b = (idx - 16) % 6;
                                                const rv = r === 0 ? 0 : 55 + r * 40; const gv = g === 0 ? 0 : 55 + g * 40; const bv = b === 0 ? 0 : 55 + b * 40;
                                                currentBg = 'rgb(' + rv + ',' + gv + ',' + bv + ')';
                                            } else if (idx >= 232 && idx <= 255) {
                                                const gray = 8 + (idx - 232) * 10;
                                                currentBg = 'rgb(' + gray + ',' + gray + ',' + gray + ')';
                                            }
                                            k += 2;
                                        } else if (cd === 48 && codes[k + 1] === 2 && k + 4 < codes.length) {
                                            currentBg = 'rgb(' + codes[k + 2] + ',' + codes[k + 3] + ',' + codes[k + 4] + ')';
                                            k += 4;
                                        }
                                    }
                                    openSpan();
                                }
                            }
                            // 其他 CSI 命令（光标移动、清屏、滚动区、保存/恢复光标等）统一忽略，不再渲染为可见字符
                            j++;
                            break;
                        } else {
                            j++;
                        }
                    }
                    i = j;
                    continue;
                } else if (next === ']') {
                    // OSC 序列：ESC ] ... BEL (0x07) 或 ESC \ (ST)
                    let j = i + 2;
                    while (j < text.length) {
                        if (text.charCodeAt(j) === 0x07) { j++; break; }
                        if (text.charCodeAt(j) === 27 && text.charAt(j + 1) === '\\') { j += 2; break; }
                        j++;
                    }
                    i = j;
                    continue;
                } else {
                    // 单字节 ESC 后非 [/] 控制：直接跳过 ESC + 下一字符（避免乱码）
                    i += 2;
                    continue;
                }
            }

            // 过滤掉除 \n \t 之外的其他 C0 控制字节（BEL/BS/DC1-4/SI/SO 等），避免显示成方块乱码
            if (code < 0x20 && code !== 0x0A /* \n */ && code !== 0x09 /* \t */) {
                i++;
                continue;
            }
            // DEL (0x7F) 也跳过
            if (code === 0x7F) {
                i++;
                continue;
            }

            const ch = text.charAt(i);
            if (ch === '\r' && text.charAt(i + 1) !== '\n') {
                // 单独的回车符（后面不是换行）：将 result 截断到当前行最后一个 \n 之后
                const lastNl = result.lastIndexOf('\n');
                if (lastNl >= 0) {
                    result = result.substring(0, lastNl + 1);
                } else {
                    result = '';
                    closeSpan();
                }
                i++;
            } else if (ch === '\r') {
                // \r\n 的 \r，跳过，后面的 \n 会正常处理换行
                i++;
            } else if (ch === '<') { result += '&lt;'; i++; }
            else if (ch === '>') { result += '&gt;'; i++; }
            else if (ch === '&') { result += '&amp;'; i++; }
            else { result += ch; i++; }
        }
        closeSpan();
        return result;
    }

    function appendTerminalOutput(text, type = '') {
        let output = document.getElementById('terminalOutput');
        if (!output) {
            const terminal = document.getElementById('terminalContainer');
            terminal.innerHTML = '<div class="terminal-output" id="terminalOutput"></div>';
            output = document.getElementById('terminalOutput');
        }
        
        const conn = getActiveConn();
        if (!conn) return;

        if (type) {
            conn.terminalContent += text;
            const span = document.createElement('span');
            if (type === 'error') span.style.color = '#f56c6c';
            else if (type === 'warning') span.style.color = '#e6a23c';
            else if (type === 'info') span.style.color = '#909399';
            span.textContent = text;
            output.appendChild(span);
            output.scrollTop = output.scrollHeight;
            return;
        }

        conn.terminalContent += text;

        // 处理清屏序列（全屏程序如 mtr/nano/top 会发送这些）
        // \x1b[2J = 清全屏，\x1b[H = 光标回原点，\x0c = Ctrl+L 清屏
        // 策略：找到最后一个清屏序列，只保留其后的内容
        let buffer = conn.terminalContent;
        const clearPatterns = [
            /\x1b\[2J/g,        // 清全屏
            /\x1b\[H\x1b\[2J/g, // 光标回原点+清屏（mtr常用）
            /\x0c/g              // Ctrl+L / 换页符
        ];
        let lastClearPos = -1;
        for (const pat of clearPatterns) {
            let m;
            while ((m = pat.exec(buffer)) !== null) {
                const endPos = m.index + m[0].length;
                if (endPos > lastClearPos) lastClearPos = endPos;
            }
        }
        if (lastClearPos > 0) {
            buffer = buffer.substring(lastClearPos);
            conn.terminalContent = buffer;
        }

        // 处理单独回车符 \r（apt 进度条、mtr 行内刷新用）
        let hasStandaloneCr = true;
        while (hasStandaloneCr) {
            hasStandaloneCr = false;
            for (let i = 0; i < buffer.length; i++) {
                if (buffer[i] === '\r' && buffer[i + 1] !== '\n') {
                    const before = buffer.substring(0, i);
                    const after = buffer.substring(i + 1);
                    const lastNl = before.lastIndexOf('\n');
                    const lineStart = lastNl >= 0 ? lastNl + 1 : 0;
                    buffer = before.substring(0, lineStart) + after;
                    hasStandaloneCr = true;
                    break;
                }
            }
        }

        output.innerHTML = ansiToHtml(buffer);
        output.scrollTop = output.scrollHeight;
    }

    function sendCommand(cmd) {
        if (!getActiveWs() || !cmd) return;
        getActiveWs().send(JSON.stringify({ type: 'input', data: cmd + '\n' }));
    }

    function initHostsModule() {
        document.getElementById('addHostBtn').onclick = () => showAddHostModal();
        document.getElementById('addCmdFolderBtn').onclick = () => showAddFolderModal();

        // 标签页切换
        document.querySelectorAll('.cmd-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.cmdTab;
                document.querySelectorAll('.cmd-tab').forEach(t => t.classList.toggle('active', t === tab));
                document.querySelectorAll('[data-cmd-tab-content]').forEach(content => {
                    content.style.display = content.dataset.cmdTabContent === tabName ? '' : 'none';
                });
                if (tabName === 'files' && getActiveWs() && getActiveWs().readyState === WebSocket.OPEN) {
                    if (!fileManagerState.currentPath || fileManagerState.currentPath === '/') {
                        openFileManagerPanel();
                    }
                }
            });
        });

        // 文件管理面板按钮
        const fmUpBtn = document.getElementById('fmUpBtn');
        const fmRefreshBtn = document.getElementById('fmRefreshBtn');
        if (fmUpBtn) fmUpBtn.onclick = () => {
            const p = fileManagerState.currentPath;
            if (p === '/' || p === '' || !p) return;
            const parts = p.split('/').filter(Boolean);
            parts.pop();
            const parentPath = '/' + parts.join('/');
            loadFileListPanel(parentPath || '/');
        };
        if (fmRefreshBtn) fmRefreshBtn.onclick = () => {
            if (fileManagerState.currentPath) loadFileListPanel(fileManagerState.currentPath);
        };

        const fmUploadBtn = document.getElementById('fmUploadBtn');
        const fmFileInput = document.getElementById('fmFileInput');
        if (fmUploadBtn) fmUploadBtn.onclick = () => {
            if (!getActiveWs() || getActiveWs().readyState !== WebSocket.OPEN) {
                setStatus('⚠️ 请先连接主机');
                return;
            }
            showUploadMenu(fmUploadBtn);
        };
        if (fmFileInput) fmFileInput.onchange = (e) => {
            const file = e.target.files[0];
            if (file) uploadFileToPanel(file);
            fmFileInput.value = '';
        };

        const searchInput = document.getElementById('hostSearchInput');
        const searchClear = document.getElementById('hostSearchClear');
        if (searchInput) {
            searchInput.addEventListener('input', () => {
                renderHosts();
                if (searchClear) searchClear.style.display = searchInput.value ? 'flex' : 'none';
            });
        }
        if (searchClear) {
            searchClear.addEventListener('click', () => {
                if (searchInput) {
                    searchInput.value = '';
                    searchInput.focus();
                    renderHosts();
                }
                searchClear.style.display = 'none';
            });
        }

        // 主机列表标签切换
        document.querySelectorAll('.hosts-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.hosts-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                currentHostTab = tab.dataset.hostTab;
                renderHosts();
            });
        });

        // 主机右键菜单
        function showHostContextMenu(clientX, clientY, hostId) {
            hideHostContextMenu();
            const host = hosts.find(h => h.id === hostId);
            if (!host) return;
            contextHostId = hostId;
            const menu = document.createElement('div');
            menu.className = 'host-context-menu';
            menu.style.position = 'fixed';
            menu.style.left = clientX + 'px';
            menu.style.top = clientY + 'px';
            menu.style.zIndex = '10000';
            const isFav = !!host.is_favorite;
            menu.innerHTML = `
                <div class="host-ctx-item" data-action="favorite">${isFav ? '💔 取消收藏' : '⭐ 添加收藏'}</div>
                <div class="host-ctx-item" data-action="connect">🔌 连接</div>
                <div class="host-ctx-item" data-action="edit">✏️ 编辑</div>
                <div class="host-ctx-item" data-action="delete" style="color:#f56c6c;">🗑️ 删除</div>
            `;
            document.body.appendChild(menu);
            hostContextMenu = menu;

            menu.querySelectorAll('.host-ctx-item').forEach(item => {
                item.addEventListener('click', async () => {
                    const action = item.dataset.action;
                    hideHostContextMenu();
                    if (action === 'favorite') {
                        try {
                            await fetch(`/api/hosts/${hostId}/favorite`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ is_favorite: !isFav })
                            });
                            await loadHosts();
                        } catch (err) { setStatus('❌ 操作失败: ' + err.message); }
                    } else if (action === 'connect') {
                        if (host) connectSSH(host);
                    } else if (action === 'edit') {
                        showAddHostModal(host);
                    } else if (action === 'delete') {
                        if (!confirm('确定要删除这个主机吗？')) return;
                        try {
                            const res = await fetch(`/api/hosts/${hostId}`, { method: 'DELETE' });
                            const data = await res.json();
                            if (res.ok) { setStatus(data.message); await loadHosts(); }
                            else setStatus('❌ ' + (data.error || '删除失败'));
                        } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
                    }
                });
            });

            setTimeout(() => {
                document.addEventListener('click', hideHostContextMenu, { once: true });
            }, 0);
        }

        function hideHostContextMenu() {
            if (hostContextMenu) {
                hostContextMenu.remove();
                hostContextMenu = null;
                contextHostId = null;
            }
        }

        const hostsList = document.getElementById('hostsList');
        hostsList.addEventListener('contextmenu', (e) => {
            const hostItem = e.target.closest('.host-item');
            if (!hostItem) return;
            e.preventDefault();
            const hostId = parseInt(hostItem.dataset.id);
            showHostContextMenu(e.clientX, e.clientY, hostId);
        });

        hostsList.addEventListener('click', async (e) => {
            const connectBtn = e.target.closest('.host-connect-btn');
            const editBtn = e.target.closest('.host-edit-btn');
            const deleteBtn = e.target.closest('.host-delete-btn');

            if (connectBtn) {
                const id = parseInt(connectBtn.dataset.id);
                const host = hosts.find(h => h.id === id);
                if (host) connectSSH(host);
            } else if (editBtn) {
                const id = parseInt(editBtn.dataset.id);
                const host = hosts.find(h => h.id === id);
                if (host) showAddHostModal(host);
            } else if (deleteBtn) {
                const id = parseInt(deleteBtn.dataset.id);
                if (!confirm('确定要删除这个主机吗？')) return;
                try {
                    const res = await fetch(`/api/hosts/${id}`, { method: 'DELETE' });
                    const data = await res.json();
                    if (res.ok) { setStatus(data.message); await loadHosts(); }
                    else setStatus('❌ ' + (data.error || '删除失败'));
                } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
            }
        });

        const foldersList = document.getElementById('foldersList');
        foldersList.addEventListener('click', async (e) => {
            const folderItem = e.target.closest('.folder-item');
            const addCmdBtn = e.target.closest('.folder-add-cmd-btn');
            const editFolderBtn = e.target.closest('.folder-edit-btn');
            const delFolderBtn = e.target.closest('.folder-delete-btn');
            const moveUpBtn = e.target.closest('.folder-move-up-btn');
            const moveDownBtn = e.target.closest('.folder-move-down-btn');
            const cmdName = e.target.closest('.cmd-name');
            const editCmdBtn = e.target.closest('.cmd-edit-btn');
            const delCmdBtn = e.target.closest('.cmd-delete-btn');
            const copyCmdBtn = e.target.closest('.cmd-copy-btn');

            if (e.target.closest('.folder-header') && !addCmdBtn && !editFolderBtn && !delFolderBtn && !moveUpBtn && !moveDownBtn && folderItem) {
                const cmds = folderItem.querySelector('.folder-commands');
                if (cmds) cmds.classList.toggle('open');
            }

            if (moveUpBtn) {
                const id = parseInt(moveUpBtn.dataset.id);
                try {
                    const res = await fetch(`/api/commands/folders/${id}/move`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ direction: 'up' })
                    });
                    const data = await res.json();
                    if (res.ok) { await loadCommandFolders(); }
                    else setStatus('❌ ' + (data.error || '移动失败'));
                } catch (err) { setStatus('❌ 移动失败: ' + err.message); }
            } else if (moveDownBtn) {
                const id = parseInt(moveDownBtn.dataset.id);
                try {
                    const res = await fetch(`/api/commands/folders/${id}/move`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ direction: 'down' })
                    });
                    const data = await res.json();
                    if (res.ok) { await loadCommandFolders(); }
                    else setStatus('❌ ' + (data.error || '移动失败'));
                } catch (err) { setStatus('❌ 移动失败: ' + err.message); }
            } else if (addCmdBtn) {
                const id = parseInt(addCmdBtn.dataset.id);
                showAddCmdModal(id);
            } else if (editFolderBtn) {
                const id = parseInt(editFolderBtn.dataset.id);
                const folder = commandFolders.find(f => f.id === id);
                if (folder) showAddFolderModal(folder);
            } else if (delFolderBtn) {
                const id = parseInt(delFolderBtn.dataset.id);
                if (!confirm('确定要删除这个文件夹吗？里面的命令也会被删除。')) return;
                try {
                    const res = await fetch(`/api/commands/folders/${id}`, { method: 'DELETE' });
                    const data = await res.json();
                    if (res.ok) { setStatus(data.message); await loadCommandFolders(); }
                    else setStatus('❌ ' + (data.error || '删除失败'));
                } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
            } else if (cmdName) {
                const cmdItem = cmdName.closest('.cmd-item');
                const id = cmdItem ? parseInt(cmdItem.dataset.id) : NaN;
                let cmd = null;
                for (const f of commandFolders) {
                    cmd = (f.commands || []).find(c => c.id === id);
                    if (cmd) break;
                }
                if (cmd && getActiveWs()) {
                    sendCommand(cmd.command);
                } else if (!getActiveWs()) {
                    setStatus('⚠️ 请先连接主机');
                }
            } else if (copyCmdBtn) {
                const id = parseInt(copyCmdBtn.dataset.id);
                let cmd = null;
                for (const f of commandFolders) {
                    cmd = (f.commands || []).find(c => c.id === id);
                    if (cmd) break;
                }
                if (cmd) {
                    try {
                        await navigator.clipboard.writeText(cmd.command || '');
                        setStatus('✅ 命令已复制');
                    } catch (err) {
                        const ta = document.createElement('textarea');
                        ta.value = cmd.command || '';
                        document.body.appendChild(ta);
                        ta.select();
                        try { document.execCommand('copy'); setStatus('✅ 命令已复制'); } catch(e) {}
                        document.body.removeChild(ta);
                    }
                }
            } else if (editCmdBtn) {
                const id = parseInt(editCmdBtn.dataset.id);
                let cmd = null, folderId = null;
                for (const f of commandFolders) {
                    cmd = (f.commands || []).find(c => c.id === id);
                    if (cmd) { folderId = f.id; break; }
                }
                if (cmd) showAddCmdModal(folderId, cmd);
            } else if (delCmdBtn) {
                const id = parseInt(delCmdBtn.dataset.id);
                if (!confirm('确定要删除这条命令吗？')) return;
                try {
                    const res = await fetch(`/api/commands/commands/${id}`, { method: 'DELETE' });
                    const data = await res.json();
                    if (res.ok) { setStatus(data.message); await loadCommandFolders(); }
                    else setStatus('❌ ' + (data.error || '删除失败'));
                } catch (err) { setStatus('❌ 删除失败: ' + err.message); }
            }
        });

        const terminalInput = document.getElementById('terminalInput');
        const sendCmdBtn = document.getElementById('sendCmdBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        const fileManagerBtn = document.getElementById('fileManagerBtn');

        terminalInput.addEventListener('keydown', (e) => {
            const conn = getActiveConn();
            const ws = conn ? conn.ws : null;
            const isOpen = ws && ws.readyState === WebSocket.OPEN;
            // Ctrl+C 发送中断
            if (e.ctrlKey && e.key === 'c') {
                e.preventDefault();
                if (isOpen) ws.send(JSON.stringify({ type: 'input', data: '\x03' }));
                // 聚焦到 xterm
                if (conn && conn.xterm) conn.xterm.focus();
                return;
            }
            // Ctrl+D 发送EOF
            if (e.ctrlKey && e.key === 'd') {
                e.preventDefault();
                if (isOpen) ws.send(JSON.stringify({ type: 'input', data: '\x04' }));
                return;
            }
            // Ctrl+Z 发送暂停信号
            if (e.ctrlKey && e.key === 'z') {
                e.preventDefault();
                if (isOpen) ws.send(JSON.stringify({ type: 'input', data: '\x1a' }));
                return;
            }
            // Ctrl+L 清屏
            if (e.ctrlKey && e.key === 'l') {
                e.preventDefault();
                if (conn && conn.xterm) conn.xterm.clear();
                return;
            }
            if (e.key === 'Enter') {
                e.preventDefault();
                const cmd = terminalInput.value;
                if (isOpen) {
                    ws.send(JSON.stringify({ type: 'input', data: cmd + '\n' }));
                }
                terminalInput.value = '';
            }
        });
        sendCmdBtn.onclick = () => {
            const cmd = terminalInput.value.trim();
            if (cmd) {
                sendCommand(cmd);
                terminalInput.value = '';
            }
        };
        disconnectBtn.onclick = () => {
            if (!activeConnId) return;
            const conn = getActiveConn();
            if (!conn) return;
            const ws = conn.ws;
            const isOpen = ws && ws.readyState === WebSocket.OPEN;
            if (isOpen) {
                disconnectOnly(activeConnId);
            } else {
                const host = conn.host;
                closeConnection(activeConnId, true);
                connectSSH(host);
            }
        };
        if (fileManagerBtn) fileManagerBtn.onclick = async () => {
            if (!activeConnId) return;
            const conn = getActiveConn();
            if (!conn) return;
            const ws = conn.ws;
            const isOpen = ws && ws.readyState === WebSocket.OPEN;
            if (!isOpen) {
                const host = conn.host;
                closeConnection(activeConnId, true);
                const newConnId = await new Promise((resolve) => {
                    const origLen = sshConnections.length;
                    connectSSH(host);
                    const checkInterval = setInterval(() => {
                        if (sshConnections.length > origLen) {
                            clearInterval(checkInterval);
                            resolve(sshConnections[sshConnections.length - 1].id);
                        }
                    }, 100);
                    setTimeout(() => { clearInterval(checkInterval); resolve(null); }, 10000);
                });
                if (newConnId) {
                    const waitConnected = setInterval(() => {
                        const nc = sshConnections.find(c => c.id === newConnId);
                        if (nc && nc.ws && nc.ws.readyState === WebSocket.OPEN) {
                            clearInterval(waitConnected);
                            openFileManager();
                        }
                    }, 200);
                    setTimeout(() => clearInterval(waitConnected), 15000);
                }
            } else {
                openFileManager();
            }
        };

        // SSH 终端右键菜单：清屏 + 粘贴并运行
        const terminalCtxMenu = document.createElement('div');
        terminalCtxMenu.className = 'context-menu';
        terminalCtxMenu.style.display = 'none';
        terminalCtxMenu.style.minWidth = '140px';
        terminalCtxMenu.innerHTML = `
            <div class="context-menu-item" data-action="copy">📋 复制选中</div>
            <div class="context-menu-item" data-action="clear">🗑️ 清屏</div>
            <div class="context-menu-item" data-action="paste">📋 粘贴并运行</div>
        `;
        document.body.appendChild(terminalCtxMenu);

        const terminalContainer = document.getElementById('terminalContainer');
        terminalContainer.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            terminalCtxMenu.style.display = 'block';
            terminalCtxMenu.style.left = e.clientX + 'px';
            terminalCtxMenu.style.top = e.clientY + 'px';
            // 根据是否有选中文本控制"复制选中"的可用性
            const conn = getActiveConn();
            const hasSelection = conn && conn.xterm && conn.xterm.getSelection && conn.xterm.getSelection();
            const copyItem = terminalCtxMenu.querySelector('[data-action="copy"]');
            if (copyItem) {
                if (hasSelection) {
                    copyItem.style.opacity = '1';
                    copyItem.style.pointerEvents = 'auto';
                    copyItem.style.color = '';
                } else {
                    copyItem.style.opacity = '0.4';
                    copyItem.style.pointerEvents = 'none';
                    copyItem.style.color = '#999';
                }
            }
            // 防止超出视口
            setTimeout(() => {
                const rect = terminalCtxMenu.getBoundingClientRect();
                const vh = window.innerHeight || 800;
                const vw = window.innerWidth || 1200;
                if (rect.bottom > vh - 8) {
                    terminalCtxMenu.style.top = Math.max(8, e.clientY - rect.height) + 'px';
                }
                if (rect.right > vw - 8) {
                    terminalCtxMenu.style.left = Math.max(8, vw - rect.width - 8) + 'px';
                }
            }, 0);
        });

        terminalCtxMenu.querySelectorAll('.context-menu-item').forEach(item => {
            item.addEventListener('click', async () => {
                const action = item.dataset.action;
                terminalCtxMenu.style.display = 'none';
                const conn = getActiveConn();
                if (action === 'copy') {
                    // 复制选中内容
                    if (conn && conn.xterm) {
                        const selection = conn.xterm.getSelection();
                        if (selection) {
                            try {
                                await navigator.clipboard.writeText(selection);
                                setStatus('已复制选中内容');
                            } catch (err) {
                                const ta = document.createElement('textarea');
                                ta.value = selection;
                                document.body.appendChild(ta);
                                ta.select();
                                try { document.execCommand('copy'); setStatus('已复制选中内容'); } catch(e) {}
                                document.body.removeChild(ta);
                            }
                        }
                    }
                } else if (action === 'clear') {
                    if (conn && conn.xterm) conn.xterm.clear();
                    if (conn) conn.terminalContent = '';
                } else if (action === 'paste') {
                    // 粘贴并运行：读取剪贴板，发送到 SSH
                    let text = '';
                    try {
                        if (navigator.clipboard && navigator.clipboard.readText) {
                            text = await navigator.clipboard.readText();
                        }
                    } catch (e) {}
                    if (!text) {
                        setStatus('无法读取剪贴板，请使用 Ctrl+V');
                        return;
                    }
                    const ws = getActiveWs();
                    if (ws && ws.readyState === WebSocket.OPEN) {
                        const lines = text.split(/\r?\n/);
                        for (let i = 0; i < lines.length; i++) {
                            const line = lines[i];
                            if (line.trim() !== '' || i < lines.length - 1) {
                                ws.send(JSON.stringify({ type: 'input', data: line + '\n' }));
                            }
                        }
                    } else {
                        setStatus('SSH 未连接，无法发送命令');
                    }
                }
            });
        });

        document.addEventListener('click', () => { terminalCtxMenu.style.display = 'none'; });

        // 点击终端区域聚焦 xterm
        const tc = document.getElementById('terminalContainer');
        if (tc) {
            tc.addEventListener('click', (e) => {
                if (e.target.closest('.context-menu')) return;
                if (e.target.closest('input')) return;
                const conn = getActiveConn();
                if (conn && conn.xterm) conn.xterm.focus();
            });
            // 强制滚动条可用：显式转发 wheel 事件给当前可滚动区域
            // 避免某些浏览器/布局下滚轮无法滚动终端输出
            tc.addEventListener('wheel', (e) => {
                const output = document.getElementById('terminalOutput');
                if (output && output.contains(e.target)) {
                    // terminal-output 自身的 overflow 会处理；这里只在默认被阻止的兜底
                    if (e.defaultPrevented) return;
                    return; // 让原生 overflow-y:auto 正常生效
                }
                // 如果当前是 xterm 连接（xterm 内部有自己的滚轮缓冲）
                // 这里不拦截，xterm 库自己会处理滚轮
            }, { passive: true });
        }

        const terminalBgColor = document.getElementById('terminalBgColor');
        const terminalBgColorText = document.getElementById('terminalBgColorText');
        const proxyType = document.getElementById('proxyType');
        const proxyHost = document.getElementById('proxyHost');
        const proxyPort = document.getElementById('proxyPort');
        const proxyUser = document.getElementById('proxyUser');
        const proxyPass = document.getElementById('proxyPass');
        const proxyVlessUuid = document.getElementById('proxyVlessUuid');
        const proxyVlessSni = document.getElementById('proxyVlessSni');
        const vlessSettings = document.getElementById('vlessSettings');

        // 加载保存的设置
        function loadSshSettings() {
            const savedBg = localStorage.getItem('sshTerminalBg');
            if (savedBg) {
                terminalBgColor.value = savedBg;
                terminalBgColorText.value = savedBg;
                document.getElementById('terminalContainer').style.background = savedBg;
                document.getElementById('terminalInput').style.background = savedBg;
            }

            const savedProxy = localStorage.getItem('sshProxySettings');
            if (savedProxy) {
                try {
                    const proxy = JSON.parse(savedProxy);
                    proxyType.value = proxy.type || 'none';
                    proxyHost.value = proxy.host || '';
                    proxyPort.value = proxy.port || '';
                    proxyUser.value = proxy.user || '';
                    proxyPass.value = proxy.password || '';
                    proxyVlessUuid.value = proxy.vlessUuid || '';
                    proxyVlessSni.value = proxy.vlessSni || '';
                    toggleVlessSettings();
                } catch(e) {}
            }
        }

        function toggleVlessSettings() {
            vlessSettings.style.display = proxyType.value === 'vless' ? 'flex' : 'none';
        }

        // SSH设置弹窗
        const sshSettingsModal = document.getElementById('sshSettingsModal');
        const sshSettingsBtn = document.getElementById('sshSettingsBtn');
        const closeSshSettings = document.getElementById('closeSshSettings');
        const saveSshSettingsBtn = document.getElementById('saveSshSettingsBtn');
        const sshSettingsStatus = document.getElementById('sshSettingsStatus');

        // 代理列表相关
        const proxyList = document.getElementById('proxyList');
        const addProxyBtn = document.getElementById('addProxyBtn');
        const proxyEditor = document.getElementById('proxyEditor');
        const proxyEditId = document.getElementById('proxyEditId');
        const proxyNameInput = document.getElementById('proxyName');
        const saveProxyBtn = document.getElementById('saveProxyBtn');
        const cancelProxyBtn = document.getElementById('cancelProxyBtn');

        let proxyConfigs = [];
        let activeProxyId = null;

        function loadSshSettings() {
            const savedBg = localStorage.getItem('sshTerminalBg');
            if (savedBg) {
                terminalBgColor.value = savedBg;
                terminalBgColorText.value = savedBg;
                document.getElementById('terminalContainer').style.background = savedBg;
                document.getElementById('terminalInput').style.background = savedBg;
            }

            const savedProxies = localStorage.getItem('sshProxyConfigs');
            if (savedProxies) {
                proxyConfigs = JSON.parse(savedProxies);
            } else {
                proxyConfigs = [];
            }

            const savedActiveProxy = localStorage.getItem('sshActiveProxy');
            activeProxyId = savedActiveProxy || null;

            renderProxyList();
            proxyEditor.style.display = 'none';
        }

        function renderProxyList() {
            if (proxyConfigs.length === 0) {
                proxyList.innerHTML = '<div style="text-align:center;color:#999;padding:10px;font-size:12px;">暂无代理配置，点击下方"添加代理"按钮添加</div>';
                return;
            }

            proxyList.innerHTML = proxyConfigs.map(p => `
                <div class="proxy-item ${p.id === activeProxyId ? 'checked' : ''}" data-id="${p.id}">
                    <input type="checkbox" class="proxy-checkbox" data-id="${p.id}" ${p.id === activeProxyId ? 'checked' : ''} />
                    <span class="proxy-name">${escapeHtml(p.name)}</span>
                    <span class="proxy-type">${p.type === 'socks' ? 'SOCKS5' : p.type === 'http' ? 'HTTP' : p.type === 'vless' ? 'VLESS' : '无代理'}</span>
                    <span class="proxy-edit" data-id="${p.id}" title="编辑">✏️</span>
                    <span class="proxy-delete" data-id="${p.id}" title="删除">✕</span>
                </div>
            `).join('');

            proxyList.querySelectorAll('.proxy-item').forEach(item => {
                item.addEventListener('click', (e) => {
                    if (e.target.classList.contains('proxy-delete')) {
                        e.stopPropagation();
                        const id = e.target.dataset.id;
                        const proxy = proxyConfigs.find(p => p.id === id);
                        showConfirm(`确定要删除代理 "${proxy ? proxy.name : ''}" 吗？`, '删除代理').then((confirmed) => {
                            if (confirmed) deleteProxy(id);
                        });
                    } else if (e.target.classList.contains('proxy-edit')) {
                        e.stopPropagation();
                        editProxy(e.target.dataset.id);
                    } else if (e.target.classList.contains('proxy-checkbox')) {
                        e.stopPropagation();
                        const id = e.target.dataset.id;
                        if (e.target.checked) {
                            activeProxyId = id;
                        } else {
                            activeProxyId = null;
                        }
                        localStorage.setItem('sshActiveProxy', activeProxyId || '');
                        renderProxyList();
                    }
                });
            });
        }

        function editProxy(id) {
            const proxy = proxyConfigs.find(p => p.id === id);
            if (!proxy) return;
            proxyEditId.value = proxy.id;
            proxyNameInput.value = proxy.name;
            proxyType.value = proxy.type || 'none';
            proxyHost.value = proxy.host || '';
            proxyPort.value = proxy.port || '';
            proxyUser.value = proxy.user || '';
            proxyPass.value = proxy.password || '';
            proxyVlessUuid.value = proxy.vlessUuid || '';
            proxyVlessSni.value = proxy.vlessSni || '';
            toggleVlessSettings();
            proxyEditor.style.display = 'block';
            proxyNameInput.focus();
        }

        function deleteProxy(id) {
            proxyConfigs = proxyConfigs.filter(p => p.id !== id);
            if (activeProxyId === id) {
                activeProxyId = null;
            }
            localStorage.setItem('sshProxyConfigs', JSON.stringify(proxyConfigs));
            localStorage.setItem('sshActiveProxy', activeProxyId || '');
            renderProxyList();
        }

        addProxyBtn.onclick = () => {
            proxyEditId.value = '';
            proxyNameInput.value = '';
            proxyType.value = 'none';
            proxyHost.value = '';
            proxyPort.value = '';
            proxyUser.value = '';
            proxyPass.value = '';
            proxyVlessUuid.value = '';
            proxyVlessSni.value = '';
            toggleVlessSettings();
            proxyEditor.style.display = 'block';
            proxyNameInput.focus();
        };

        cancelProxyBtn.onclick = () => {
            proxyEditor.style.display = 'none';
        };

        saveProxyBtn.onclick = () => {
            const name = proxyNameInput.value.trim();
            if (!name) {
                sshSettingsStatus.textContent = '❌ 请输入代理名称';
                return;
            }

            const proxy = {
                id: proxyEditId.value || Date.now().toString(),
                name,
                type: proxyType.value,
                host: proxyHost.value.trim(),
                port: proxyPort.value.trim(),
                user: proxyUser.value.trim(),
                password: proxyPass.value.trim(),
                vlessUuid: proxyVlessUuid.value.trim(),
                vlessSni: proxyVlessSni.value.trim()
            };

            const idx = proxyConfigs.findIndex(p => p.id === proxy.id);
            if (idx >= 0) {
                proxyConfigs[idx] = proxy;
            } else {
                proxyConfigs.push(proxy);
            }

            localStorage.setItem('sshProxyConfigs', JSON.stringify(proxyConfigs));

            proxyEditor.style.display = 'none';
            renderProxyList();
            sshSettingsStatus.textContent = '✅ 代理已保存';
            setTimeout(() => { sshSettingsStatus.textContent = ''; }, 1500);
        };

        sshSettingsBtn.onclick = () => {
            loadSshSettings();
            sshSettingsModal.classList.add('show');
        };

        closeSshSettings.onclick = () => {
            sshSettingsModal.classList.remove('show');
        };

        

        terminalBgColor.addEventListener('input', (e) => {
            terminalBgColorText.value = e.target.value;
        });

        terminalBgColorText.addEventListener('input', (e) => {
            const val = e.target.value;
            if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
                terminalBgColor.value = val;
            }
        });

        proxyType.addEventListener('change', toggleVlessSettings);

        saveSshSettingsBtn.onclick = () => {
            const color = terminalBgColor.value;
            document.getElementById('terminalContainer').style.background = color;
            document.getElementById('terminalInput').style.background = color;
            localStorage.setItem('sshTerminalBg', color);
            // 同步更新所有 xterm 实例的背景色
            sshConnections.forEach(conn => {
                if (conn.xterm) {
                    conn.xterm.options.theme = { ...conn.xterm.options.theme, background: color };
                }
            });

            localStorage.setItem('sshActiveProxy', activeProxyId || '');

            sshSettingsStatus.textContent = '✅ 设置已保存';
            setTimeout(() => {
                sshSettingsStatus.textContent = '';
                sshSettingsModal.classList.remove('show');
            }, 1500);
        };

        loadSshSettings();
    }

    // --- 备忘记录模块 ---
    let memoTags = [];
    let memoItems = [];
    let currentMemoTagId = null;
    let memoTagManageMode = false;
    let selectedMemoTags = new Set();
    let memoItemManageMode = false;
    let selectedMemoItems = new Set();
    let memoDragSrcId = null;

    async function loadMemoTags() {
        try {
            const res = await fetch('/api/memos/tags');
            if (res.ok) {
                memoTags = await res.json();
                renderMemoTags();
                if (memoTags.length > 0 && !memoTags.find(t => t.id === currentMemoTagId)) {
                    selectMemoTag(memoTags[0].id);
                }
            }
        } catch (err) { console.error('加载备忘标签失败:', err); }
    }

    function renderMemoTags() {
        const bar = document.getElementById('memoTabBar');
        if (!bar) return;
        const manageBtn = document.getElementById('manageMemoTagsBtn');
        const deleteBtn = document.getElementById('deleteMemoTagsBtn');
        if (manageBtn) {
            manageBtn.textContent = memoTagManageMode ? '完成' : '管理';
            manageBtn.classList.toggle('active', memoTagManageMode);
        }
        if (deleteBtn) {
            deleteBtn.disabled = !memoTagManageMode || selectedMemoTags.size === 0;
        }
        bar.classList.toggle('drag-active', memoTagManageMode);

        if (!memoTags.length) {
            bar.innerHTML = '<div style="color:#909399;font-size:13px;padding:8px 12px;">暂无标签，点击右侧"添加"创建</div>';
            return;
        }
        bar.innerHTML = memoTags.map(t => {
            const active = t.id === currentMemoTagId ? 'active' : '';
            const checked = selectedMemoTags.has(t.id) ? 'checked' : '';
            const checkbox = memoTagManageMode
                ? `<input type="checkbox" class="memo-tab-checkbox" data-id="${t.id}" ${checked} />`
                : '';
            const draggable = memoTagManageMode ? 'draggable="true"' : '';
            return `<div class="memo-tab-item ${active}" data-id="${t.id}" ${draggable}>
                ${checkbox}
                <span class="memo-tab-name" data-id="${t.id}">${escapeHtml(t.name)}</span>
            </div>`;
        }).join('');

        bar.querySelectorAll('.memo-tab-checkbox').forEach(el => {
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(el.dataset.id);
                if (el.checked) selectedMemoTags.add(id);
                else selectedMemoTags.delete(id);
                if (deleteBtn) deleteBtn.disabled = selectedMemoTags.size === 0;
            });
        });

        bar.querySelectorAll('.memo-tab-name').forEach(el => {
            el.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                const id = parseInt(el.dataset.id);
                showRenameMemoTagModal(id);
            });
        });

        bar.querySelectorAll('.memo-tab-item').forEach(el => {
            el.addEventListener('click', (e) => {
                if (e.target.classList.contains('memo-tab-checkbox')) return;
                if (memoTagManageMode) return;
                selectMemoTag(parseInt(el.dataset.id));
            });
        });

        if (memoTagManageMode) initMemoTagDragDrop();
    }

    function initMemoTagDragDrop() {
        const bar = document.getElementById('memoTabBar');
        if (!bar) return;
        let draggedId = null;
        bar.addEventListener('dragstart', (e) => {
            const item = e.target.closest('.memo-tab-item');
            if (item) { draggedId = parseInt(item.dataset.id); e.dataTransfer.effectAllowed = 'move'; }
        });
        bar.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
        bar.addEventListener('drop', async (e) => {
            e.preventDefault();
            const target = e.target.closest('.memo-tab-item');
            if (!target || draggedId === null) return;
            const targetId = parseInt(target.dataset.id);
            if (targetId === draggedId) return;
            const newOrder = memoTags.map(t => t.id);
            const fromIdx = newOrder.indexOf(draggedId);
            const toIdx = newOrder.indexOf(targetId);
            if (fromIdx < 0 || toIdx < 0) return;
            newOrder.splice(fromIdx, 1);
            newOrder.splice(toIdx, 0, draggedId);
            try {
                await fetch('/api/memos/tags/reorder', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tagIds: newOrder })
                });
                loadMemoTags();
            } catch (err) { console.error('排序失败:', err); }
        });
    }

    function showAddMemoTagModal() {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:400px;">
                <div class="modal-header">
                    <h2>➕ 添加备忘标签</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>标签名称</label><input type="text" id="newMemoTagName" placeholder="请输入标签名称" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveNewMemoTagBtn">添加</button>
                        <button class="tool-btn cancel-add-memo-tag">取消</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#newMemoTagName');
        setTimeout(() => input.focus(), 50);
        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-add-memo-tag').onclick = () => overlay.remove();
        const save = async () => {
            const name = input.value.trim();
            if (!name) return;
            try {
                const res = await fetch('/api/memos/tags', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name })
                });
                if (res.ok) {
                    const data = await res.json();
                    overlay.remove();
                    await loadMemoTags();
                    selectMemoTag(data.id);
                }
            } catch (err) { console.error('添加标签失败:', err); }
        };
        overlay.querySelector('#saveNewMemoTagBtn').onclick = save;
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); });
    }

    function showRenameMemoTagModal(tagId) {
        const tag = memoTags.find(t => t.id === tagId);
        if (!tag) return;
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:400px;">
                <div class="modal-header">
                    <h2>✏️ 重命名标签</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>标签名称</label><input type="text" id="renameMemoTagName" value="${escapeAttr(tag.name)}" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveRenameMemoTagBtn">保存</button>
                        <button class="tool-btn cancel-rename-memo-tag">取消</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#renameMemoTagName');
        setTimeout(() => { input.focus(); input.select(); }, 50);
        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-rename-memo-tag').onclick = () => overlay.remove();
        const save = async () => {
            const name = input.value.trim();
            if (!name) return;
            try {
                const res = await fetch(`/api/memos/tags/${tagId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name })
                });
                if (res.ok) {
                    overlay.remove();
                    await loadMemoTags();
                    if (currentMemoTagId === tagId) {
                        const nameEl = document.getElementById('memoCurrentTagName');
                        if (nameEl) nameEl.textContent = name;
                    }
                }
            } catch (err) { console.error('重命名标签失败:', err); }
        };
        overlay.querySelector('#saveRenameMemoTagBtn').onclick = save;
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); });
    }

    async function selectMemoTag(tagId) {
        currentMemoTagId = tagId;
        const tag = memoTags.find(t => t.id === tagId);
        const nameEl = document.getElementById('memoCurrentTagName');
        const addBtn = document.getElementById('addMemoItemBtn');
        if (nameEl && tag) nameEl.textContent = tag.name;
        if (addBtn) addBtn.disabled = false;
        renderMemoTags();
        await loadMemoItems(tagId);
    }

    async function loadMemoItems(tagId) {
        try {
            const res = await fetch(`/api/memos/tags/${tagId}/items`);
            if (res.ok) {
                memoItems = await res.json();
                renderMemoItems();
            }
        } catch (err) { console.error('加载备忘记录失败:', err); }
    }

    function renderMemoItems() {
        const list = document.getElementById('memosList');
        if (!list) return;
        list.classList.toggle('manage-mode', memoItemManageMode);

        if (!memoItems.length) {
            list.innerHTML = '<div style="text-align:center;color:#999;padding:60px 0;font-size:14px;">暂无备忘记录，点击右上角"添加备忘"创建</div>';
            return;
        }
        list.innerHTML = memoItems.map(m => {
            const w = Math.min(3, Math.max(1, parseInt(m.width_units) || 1));
            const h = Math.min(3, Math.max(1, parseInt(m.height_units) || 1));
            const sizeCls = `w-${w} h-${h}`;
            const checked = selectedMemoItems.has(m.id) ? 'checked' : '';
            const checkbox = memoItemManageMode
                ? `<input type="checkbox" class="memo-card-checkbox" data-id="${m.id}" ${checked} />`
                : '';
            const draggable = memoItemManageMode ? 'draggable="true"' : '';
            return `
            <div class="memo-card ${m.is_visible ? '' : 'memo-hidden'} ${sizeCls}" data-id="${m.id}" ${draggable}>
                ${checkbox}
                <div class="memo-card-header">
                    <div class="memo-card-title">${escapeHtml(m.title || '（无标题）')}</div>
                    <div class="memo-card-actions">
                        <button class="memo-action-btn" data-action="copy" data-id="${m.id}" title="复制">📋</button>
                        <button class="memo-action-btn" data-action="edit" data-id="${m.id}" title="编辑">✏️</button>
                    </div>
                </div>
                <div class="memo-card-body">${escapeHtml(m.content || '').replace(/\n/g, '<br>') || '<span style="color:#c0c4cc;">（无内容）</span>'}</div>
                <div class="memo-card-footer">
                    <span>更新: ${formatDateTime(m.updated_at || m.created_at)}</span>
                    ${m.is_visible ? '<span style="color:#67c23a;">● 显示中</span>' : '<span style="color:#909399;">○ 已隐藏</span>'}
                </div>
            </div>
        `}).join('');

        if (memoItemManageMode) {
            initMemoItemDragDrop();
        }

        list.querySelectorAll('.memo-card-checkbox').forEach(cb => {
            cb.addEventListener('change', () => {
                const id = parseInt(cb.dataset.id);
                if (cb.checked) selectedMemoItems.add(id);
                else selectedMemoItems.delete(id);
                updateManageMemoBtn();
            });
        });
    }

    function updateManageMemoBtn() {
        const btn = document.getElementById('manageMemoItemsBtn');
        if (!btn) return;
        if (!memoItemManageMode) {
            btn.textContent = '⚙️ 管理备忘';
            btn.classList.remove('danger');
        } else if (selectedMemoItems.size > 0) {
            btn.textContent = `🗑️ 删除信息 (${selectedMemoItems.size})`;
            btn.classList.add('danger');
        } else {
            btn.textContent = '✅ 完成管理';
            btn.classList.remove('danger');
        }
    }

    function initMemoItemDragDrop() {
        const list = document.getElementById('memosList');
        if (!list) return;

        list.querySelectorAll('.memo-card').forEach(card => {
            card.addEventListener('dragstart', (e) => {
                memoDragSrcId = parseInt(card.dataset.id);
                card.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            });
            card.addEventListener('dragend', () => {
                card.classList.remove('dragging');
                list.querySelectorAll('.memo-card').forEach(c => c.classList.remove('drag-over'));
            });
            card.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
            });
            card.addEventListener('dragenter', (e) => {
                e.preventDefault();
                const id = parseInt(card.dataset.id);
                if (id !== memoDragSrcId) card.classList.add('drag-over');
            });
            card.addEventListener('dragleave', () => {
                card.classList.remove('drag-over');
            });
            card.addEventListener('drop', async (e) => {
                e.preventDefault();
                const targetId = parseInt(card.dataset.id);
                card.classList.remove('drag-over');
                if (!memoDragSrcId || memoDragSrcId === targetId) return;

                const srcIdx = memoItems.findIndex(m => m.id === memoDragSrcId);
                const tgtIdx = memoItems.findIndex(m => m.id === targetId);
                if (srcIdx < 0 || tgtIdx < 0) return;

                const [removed] = memoItems.splice(srcIdx, 1);
                memoItems.splice(tgtIdx, 0, removed);

                const itemIds = memoItems.map(m => m.id);
                try {
                    await fetch('/api/memos/items/reorder', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ itemIds })
                    });
                } catch (err) { console.error('排序失败:', err); }
                renderMemoItems();
                memoDragSrcId = null;
            });
        });
    }

    function formatDateTime(str) {
        if (!str) return '-';
        const d = new Date(str);
        if (isNaN(d.getTime())) return str;
        return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
    }

    function showMemoItemModal(item = null) {
        const isEdit = !!item;
        const w = Math.min(3, Math.max(1, parseInt(item?.width_units) || 1));
        const h = Math.min(3, Math.max(1, parseInt(item?.height_units) || 1));
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:560px;">
                <div class="modal-header">
                    <h2>${isEdit ? '✏️ 编辑备忘' : '➕ 添加备忘'}</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>标题</label><input type="text" id="memoTitleInput" value="${isEdit ? escapeAttr(item.title || '') : ''}" placeholder="请输入标题" /></div>
                    <div class="input-group"><label>内容</label><textarea id="memoContentInput" rows="8" placeholder="请输入内容...">${isEdit ? escapeHtml(item.content || '') : ''}</textarea></div>
                    <div class="input-group" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
                        <div class="memo-size-select">
                            <label>水平大小:</label>
                            <select id="memoWidthSelect">
                                <option value="1" ${w === 1 ? 'selected' : ''}>1 格</option>
                                <option value="2" ${w === 2 ? 'selected' : ''}>2 格</option>
                                <option value="3" ${w === 3 ? 'selected' : ''}>3 格</option>
                            </select>
                        </div>
                        <div class="memo-size-select">
                            <label>垂直大小:</label>
                            <select id="memoHeightSelect">
                                <option value="1" ${h === 1 ? 'selected' : ''}>1 格</option>
                                <option value="2" ${h === 2 ? 'selected' : ''}>2 格</option>
                                <option value="3" ${h === 3 ? 'selected' : ''}>3 格</option>
                            </select>
                        </div>
                    </div>
                    <div class="input-group" style="display:flex;align-items:center;gap:8px;">
                        <label style="margin:0;">是否显示</label>
                        <input type="checkbox" id="memoVisibleInput" ${isEdit ? (item.is_visible ? 'checked' : '') : 'checked'} />
                    </div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveMemoItemBtn">${isEdit ? '保存' : '添加'}</button>
                        <button class="tool-btn cancel-memo-btn">取消</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-memo-btn').onclick = () => overlay.remove();
        overlay.querySelector('#saveMemoItemBtn').onclick = async () => {
            const title = overlay.querySelector('#memoTitleInput').value.trim();
            const content = overlay.querySelector('#memoContentInput').value;
            const is_visible = overlay.querySelector('#memoVisibleInput').checked;
            const width_units = parseInt(overlay.querySelector('#memoWidthSelect').value) || 1;
            const height_units = parseInt(overlay.querySelector('#memoHeightSelect').value) || 1;
            try {
                let res;
                if (isEdit) {
                    res = await fetch(`/api/memos/items/${item.id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ title, content, is_visible, width_units, height_units })
                    });
                } else {
                    res = await fetch(`/api/memos/tags/${currentMemoTagId}/items`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ title, content, is_visible, width_units, height_units })
                    });
                }
                if (res.ok) {
                    overlay.remove();
                    loadMemoItems(currentMemoTagId);
                }
            } catch (err) { console.error('保存备忘失败:', err); }
        };
    }

    function initMemosModule() {
        const addTagBtn = document.getElementById('addMemoTagBtn');
        if (addTagBtn) addTagBtn.onclick = () => showAddMemoTagModal();

        const manageBtn = document.getElementById('manageMemoTagsBtn');
        if (manageBtn) {
            manageBtn.onclick = () => {
                memoTagManageMode = !memoTagManageMode;
                if (!memoTagManageMode) selectedMemoTags.clear();
                renderMemoTags();
            };
        }

        const deleteBtn = document.getElementById('deleteMemoTagsBtn');
        if (deleteBtn) {
            deleteBtn.onclick = async () => {
                if (selectedMemoTags.size === 0) return;
                if (!await showConfirm(`确定删除选中的 ${selectedMemoTags.size} 个标签及其所有备忘记录吗？`, '删除标签')) return;
                try {
                    const ids = Array.from(selectedMemoTags);
                    await Promise.all(ids.map(id => fetch(`/api/memos/tags/${id}`, { method: 'DELETE' })));
                    ids.forEach(id => {
                        if (currentMemoTagId === id) currentMemoTagId = null;
                        selectedMemoTags.delete(id);
                    });
                    memoTagManageMode = false;
                    await loadMemoTags();
                    const addItemBtn = document.getElementById('addMemoItemBtn');
                    if (memoTags.length > 0) {
                        if (!currentMemoTagId) selectMemoTag(memoTags[0].id);
                    } else {
                        document.getElementById('memosList').innerHTML = '<div style="text-align:center;color:#999;padding:60px 0;font-size:14px;">请从上方选择一个标签开始使用备忘记录</div>';
                        const nameEl2 = document.getElementById('memoCurrentTagName');
                        if (nameEl2) nameEl2.textContent = '请选择标签';
                        if (addItemBtn) addItemBtn.disabled = true;
                    }
                } catch (err) { console.error('删除标签失败:', err); }
            };
        }

        const addItemBtn = document.getElementById('addMemoItemBtn');
        if (addItemBtn) {
            addItemBtn.onclick = () => {
                if (!currentMemoTagId) return;
                showMemoItemModal();
            };
        }

        const manageItemsBtn = document.getElementById('manageMemoItemsBtn');
        if (manageItemsBtn) {
            manageItemsBtn.onclick = async () => {
                if (!memoItemManageMode) {
                    memoItemManageMode = true;
                    selectedMemoItems.clear();
                    updateManageMemoBtn();
                    renderMemoItems();
                } else if (selectedMemoItems.size > 0) {
                    if (!await showConfirm(`确定删除选中的 ${selectedMemoItems.size} 条备忘记录吗？`, '删除备忘')) return;
                    try {
                        const ids = Array.from(selectedMemoItems);
                        const res = await fetch('/api/memos/items/batch', {
                            method: 'DELETE',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ ids })
                        });
                        if (res.ok) {
                            memoItemManageMode = false;
                            selectedMemoItems.clear();
                            updateManageMemoBtn();
                            loadMemoItems(currentMemoTagId);
                        }
                    } catch (err) { console.error('删除备忘失败:', err); }
                } else {
                    memoItemManageMode = false;
                    selectedMemoItems.clear();
                    updateManageMemoBtn();
                    renderMemoItems();
                }
            };
        }

        const memosList = document.getElementById('memosList');
        if (memosList) {
            memosList.addEventListener('click', async (e) => {
                const actionBtn = e.target.closest('.memo-action-btn');
                if (!actionBtn) return;
                const action = actionBtn.dataset.action;
                const id = parseInt(actionBtn.dataset.id);
                const item = memoItems.find(m => m.id === id);
                if (!item) return;
                if (action === 'edit') {
                    showMemoItemModal(item);
                } else if (action === 'copy') {
                    const text = item.content || '';
                    try {
                        await navigator.clipboard.writeText(text);
                        setStatus('✅ 已复制到剪贴板');
                        setTimeout(() => setStatus(''), 1500);
                    } catch (err) {
                        const ta = document.createElement('textarea');
                        ta.value = text;
                        document.body.appendChild(ta);
                        ta.select();
                        document.execCommand('copy');
                        document.body.removeChild(ta);
                        setStatus('✅ 已复制到剪贴板');
                        setTimeout(() => setStatus(''), 1500);
                    }
                }
            });
        }
    }

    // ===== 辅助工具子导航切换 =====
    document.querySelectorAll('.memo-sub-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.memo-sub-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const subview = tab.dataset.subview;
            document.querySelectorAll('.memo-sub-panel').forEach(p => p.classList.remove('active'));
            const panel = document.getElementById('subview-' + subview);
            if (panel) panel.classList.add('active');
            if (subview === 'network-quote') loadQuoteTags();
            if (subview === 'memos') loadMemoTags();
        });
    });

    // ===== 网络报价（多标签 + 增强表格） =====
    let quoteTags = [];
    let currentQuoteTagId = null;
    let quoteTagManageMode = false;
    let selectedQuoteTags = new Set();
    let quoteGrid = null; // 当前标签的网格数据
    let quoteSaveTimer = null;

    // ---------- 标签管理（完全照抄备忘记录） ----------
    async function loadQuoteTags() {
        try {
            const res = await fetch('/api/network-quote/tags');
            if (!res.ok) throw new Error(await res.text());
            quoteTags = await res.json();
            renderQuoteTags();
            if (quoteTags.length > 0 && !currentQuoteTagId) {
                selectQuoteTag(quoteTags[0].id);
            } else if (quoteTags.length === 0) {
                // 没有标签，清空状态
                currentQuoteTagId = null;
                quoteGrid = null;
                renderQuoteGrid();
            }
        } catch (err) { console.error('加载网络报价标签失败:', err); }
    }

    function renderQuoteTags() {
        const bar = document.getElementById('quoteTabBar');
        if (!bar) return;
        const manageBtn = document.getElementById('manageQuoteTagsBtn');
        const deleteBtn = document.getElementById('deleteQuoteTagsBtn');
        if (manageBtn) {
            manageBtn.textContent = quoteTagManageMode ? '完成' : '管理';
            manageBtn.classList.toggle('active', quoteTagManageMode);
        }
        if (deleteBtn) {
            deleteBtn.disabled = !quoteTagManageMode || selectedQuoteTags.size === 0;
        }
        bar.classList.toggle('drag-active', quoteTagManageMode);

        if (!quoteTags.length) {
            bar.innerHTML = '<div style="color:#909399;font-size:13px;padding:8px 12px;">暂无标签，点击右侧"添加"创建</div>';
            return;
        }
        bar.innerHTML = quoteTags.map(t => {
            const active = t.id === currentQuoteTagId ? 'active' : '';
            const checked = selectedQuoteTags.has(t.id) ? 'checked' : '';
            const checkbox = quoteTagManageMode
                ? `<input type="checkbox" class="memo-tab-checkbox" data-id="${t.id}" ${checked} />`
                : '';
            const draggable = quoteTagManageMode ? 'draggable="true"' : '';
            return `<div class="memo-tab-item ${active}" data-id="${t.id}" ${draggable}>
                ${checkbox}
                <span class="memo-tab-name" data-id="${t.id}">${escapeHtml(t.name)}</span>
            </div>`;
        }).join('');

        bar.querySelectorAll('.memo-tab-checkbox').forEach(el => {
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(el.dataset.id);
                if (el.checked) selectedQuoteTags.add(id);
                else selectedQuoteTags.delete(id);
                if (deleteBtn) deleteBtn.disabled = selectedQuoteTags.size === 0;
            });
        });

        bar.querySelectorAll('.memo-tab-name').forEach(el => {
            el.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                const id = parseInt(el.dataset.id);
                showRenameQuoteTagModal(id);
            });
        });

        bar.querySelectorAll('.memo-tab-item').forEach(el => {
            el.addEventListener('click', (e) => {
                if (e.target.classList.contains('memo-tab-checkbox')) return;
                if (quoteTagManageMode) return;
                selectQuoteTag(parseInt(el.dataset.id));
            });
        });

        if (quoteTagManageMode) initQuoteTagDragDrop();
    }

    function initQuoteTagDragDrop() {
        const bar = document.getElementById('quoteTabBar');
        if (!bar) return;
        let draggedId = null;
        bar.addEventListener('dragstart', (e) => {
            const item = e.target.closest('.memo-tab-item');
            if (item) { draggedId = parseInt(item.dataset.id); e.dataTransfer.effectAllowed = 'move'; }
        });
        bar.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
        bar.addEventListener('drop', async (e) => {
            e.preventDefault();
            const target = e.target.closest('.memo-tab-item');
            if (!target || draggedId === null) return;
            const targetId = parseInt(target.dataset.id);
            if (targetId === draggedId) return;
            const newOrder = quoteTags.map(t => t.id);
            const fromIdx = newOrder.indexOf(draggedId);
            const toIdx = newOrder.indexOf(targetId);
            if (fromIdx < 0 || toIdx < 0) return;
            newOrder.splice(fromIdx, 1);
            newOrder.splice(toIdx, 0, draggedId);
            try {
                await fetch('/api/network-quote/tags/reorder', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tagIds: newOrder })
                });
                loadQuoteTags();
            } catch (err) { console.error('排序失败:', err); }
        });
    }

    async function selectQuoteTag(tagId) {
        currentQuoteTagId = tagId;
        const tag = quoteTags.find(t => t.id === tagId);
        const nameEl = document.getElementById('quoteCurrentTagName');
        if (nameEl && tag) nameEl.textContent = tag.name;
        renderQuoteTags();
        try {
            const res = await fetch(`/api/network-quote/tags/${tagId}/grid`);
            if (!res.ok) throw new Error(await res.text());
            const data = await res.json();
            quoteGrid = normalizeQuoteGrid(data);
            renderQuoteGrid();
        } catch (err) {
            quoteGrid = createEmptyQuoteGrid();
            renderQuoteGrid();
        }
    }

    function createEmptyQuoteGrid() {
        return {
            columns: [],
            rows: [],
            nextColId: 1,
            nextRowId: 1,
            colWidths: {},   // colId -> px
            rowHeights: {},  // rowId -> px
            styles: {},      // "rowId_colId" -> { align, bold, fontSize, fg, bg }
            merges: [],      // [{ row, col, rowspan, colspan }]
            hiddenRows: [],  // [rowId]  不显示在生成图片中
            hiddenCols: []   // [colId]  不显示在生成图片中
        };
    }

    function normalizeQuoteGrid(data) {
        if (!data || typeof data !== 'object') return createEmptyQuoteGrid();
        return {
            columns: Array.isArray(data.columns) ? data.columns : [],
            rows: Array.isArray(data.rows) ? data.rows : [],
            nextColId: data.nextColId || 1,
            nextRowId: data.nextRowId || 1,
            colWidths: data.colWidths || {},
            rowHeights: data.rowHeights || {},
            styles: data.styles || {},
            merges: Array.isArray(data.merges) ? data.merges : [],
            hiddenRows: Array.isArray(data.hiddenRows) ? data.hiddenRows : [],
            hiddenCols: Array.isArray(data.hiddenCols) ? data.hiddenCols : []
        };
    }

    function saveQuoteGridDebounced() {
        if (!currentQuoteTagId) return;
        if (quoteSaveTimer) clearTimeout(quoteSaveTimer);
        quoteSaveTimer = setTimeout(async () => {
            try {
                await fetch(`/api/network-quote/tags/${currentQuoteTagId}/grid`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(quoteGrid)
                });
                const status = document.getElementById('quoteStatus');
                if (status) { status.textContent = '✓ 已保存'; setTimeout(() => status.textContent = '', 1000); }
            } catch (e) {}
        }, 500);
    }

    function showAddQuoteTagModal() {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:400px;">
                <div class="modal-header">
                    <h2>➕ 添加网络报价标签</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>标签名称</label><input type="text" id="newQuoteTagName" placeholder="请输入标签名称" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveNewQuoteTagBtn">添加</button>
                        <button class="tool-btn cancel-add-quote-tag">取消</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#newQuoteTagName');
        setTimeout(() => input.focus(), 50);
        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-add-quote-tag').onclick = () => overlay.remove();
        overlay.querySelector('#saveNewQuoteTagBtn').onclick = async () => {
            const name = input.value.trim();
            if (!name) { input.focus(); return; }
            try {
                const res = await fetch('/api/network-quote/tags', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name })
                });
                if (!res.ok) throw new Error(await res.text());
                overlay.remove();
                await loadQuoteTags();
            } catch (err) { alert('添加失败: ' + err.message); }
        };
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') overlay.querySelector('#saveNewQuoteTagBtn').click(); });
    }

    function showRenameQuoteTagModal(tagId) {
        const tag = quoteTags.find(t => t.id === tagId);
        if (!tag) return;
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay show';
        overlay.innerHTML = `
            <div class="modal" style="width:400px;">
                <div class="modal-header">
                    <h2>✏️ 重命名标签</h2>
                    <button class="modal-close">✕</button>
                </div>
                <div class="modal-body">
                    <div class="input-group"><label>标签名称</label><input type="text" id="renameQuoteTagName" value="${escapeAttr(tag.name)}" /></div>
                    <div class="modal-actions">
                        <button class="tool-btn primary" id="saveRenameQuoteTagBtn">保存</button>
                        <button class="tool-btn cancel-rename-quote-tag">取消</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#renameQuoteTagName');
        setTimeout(() => { input.focus(); input.select(); }, 50);
        overlay.querySelector('.modal-close').onclick = () => overlay.remove();
        overlay.querySelector('.cancel-rename-quote-tag').onclick = () => overlay.remove();
        overlay.querySelector('#saveRenameQuoteTagBtn').onclick = async () => {
            const name = input.value.trim();
            if (!name) { input.focus(); return; }
            try {
                const res = await fetch(`/api/network-quote/tags/${tagId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name })
                });
                if (!res.ok) throw new Error(await res.text());
                overlay.remove();
                await loadQuoteTags();
            } catch (err) { alert('重命名失败: ' + err.message); }
        };
    }

    // 标签按钮
    const addQuoteTagBtn = document.getElementById('addQuoteTagBtn');
    if (addQuoteTagBtn) addQuoteTagBtn.addEventListener('click', showAddQuoteTagModal);
    const manageQuoteTagsBtn = document.getElementById('manageQuoteTagsBtn');
    if (manageQuoteTagsBtn) manageQuoteTagsBtn.addEventListener('click', () => {
        quoteTagManageMode = !quoteTagManageMode;
        if (!quoteTagManageMode) selectedQuoteTags.clear();
        renderQuoteTags();
    });
    const deleteQuoteTagsBtn = document.getElementById('deleteQuoteTagsBtn');
    if (deleteQuoteTagsBtn) deleteQuoteTagsBtn.addEventListener('click', async () => {
        if (selectedQuoteTags.size === 0) return;
        if (!confirm(`确定删除选中的 ${selectedQuoteTags.size} 个标签吗？（关联数据将一并删除）`)) return;
        try {
            for (const id of selectedQuoteTags) {
                await fetch(`/api/network-quote/tags/${id}`, { method: 'DELETE' });
            }
            selectedQuoteTags.clear();
            quoteTagManageMode = false;
            if (currentQuoteTagId && !quoteTags.find(t => t.id === currentQuoteTagId && selectedQuoteTags.has(t.id) === false)) {
                currentQuoteTagId = null;
            }
            await loadQuoteTags();
        } catch (err) { alert('删除失败: ' + err.message); }
    });

    // ---------- 增强表格 ----------
    let quoteSelection = { startRow: null, startCol: null, endRow: null, endCol: null, selecting: false };
    let quoteResizing = null;
    let quoteGridEventsBound = false; // 防止 document 事件重复绑定

    function renderQuoteGrid() {
        const container = document.getElementById('quoteGridContainer');
        if (!container) return;
        const toolbar = document.getElementById('quoteToolbar');
        // 有标签选中时显示工具栏
        if (toolbar) {
            if (currentQuoteTagId) toolbar.style.display = '';
            else toolbar.style.display = 'none';
        }
        if (!quoteGrid || (quoteGrid.columns.length === 0 && quoteGrid.rows.length === 0)) {
            container.innerHTML = '<div style="text-align:center;color:#999;padding:60px 0;font-size:14px;">请先添加行和列开始编辑</div>';
            return;
        }

        const g = quoteGrid;
        // 隐藏态辅助
        const isRowHidden = (id) => Array.isArray(g.hiddenRows) && g.hiddenRows.indexOf(id) >= 0;
        const isColHidden = (id) => Array.isArray(g.hiddenCols) && g.hiddenCols.indexOf(id) >= 0;

        let html = '<table class="quote-grid" id="quoteGridTable"><thead><tr>';
        html += '<th class="corner-cell" style="width:50px;min-width:50px;position:relative;" data-quote-context="corner"></th>';
        g.columns.forEach(col => {
            const w = g.colWidths[col.id] || 120;
            const colHidden = isColHidden(col.id);
            const title = colHidden ? '（该列不显示在生成的图片中）' : '';
            html += `<th data-col-id="${col.id}" data-quote-context="col-header" style="width:${w}px;min-width:${w}px;position:relative;${colHidden ? 'opacity:0.55;' : ''}" title="${title}">
                <div class="col-header" data-col-id="${col.id}">
                    <span class="col-name" data-col-id="${col.id}">${colHidden ? '👁‍🗨 ' : ''}${escapeHtml(col.name)}</span>
                </div>
                <div class="col-resize-handle" data-col-id="${col.id}" style="position:absolute;right:0;top:0;width:5px;height:100%;cursor:col-resize;"></div>
            </th>`;
        });
        html += '</tr></thead><tbody>';

        g.rows.forEach((row, rowIdx) => {
            const h = g.rowHeights[row.id] || 32;
            const rowHidden = isRowHidden(row.id);
            const title = rowHidden ? '（该行不显示在生成的图片中）' : '';
            html += `<tr data-row-id="${row.id}" style="height:${h}px;${rowHidden ? 'opacity:0.55;' : ''}" title="${title}">`;
            html += `<td class="row-header" data-row-id="${row.id}" data-quote-context="row-header" style="height:${h}px;position:relative;">${rowHidden ? '👁‍🗨 ' : ''}${rowIdx + 1}
                <div class="row-resize-handle" data-row-id="${row.id}" style="position:absolute;left:0;bottom:0;width:100%;height:5px;cursor:row-resize;"></div>
            </td>`;
            g.columns.forEach(col => {
                const key = `${row.id}_${col.id}`;
                const style = g.styles[key] || {};
                const val = row.cells[col.id] || '';
                const align = style.align || 'left';
                const valign = style.valign || (getMergeForCell(row.id, col.id) ? 'middle' : 'top');
                const bold = style.bold ? 'font-weight:bold;' : '';
                const fontSize = style.fontSize ? `font-size:${style.fontSize}px;` : '';
                const fontFamily = style.fontFamily ? `font-family:${style.fontFamily};` : '';
                const fg = style.fg ? `color:${style.fg};` : '';
                const bg = style.bg ? `background-color:${style.bg};` : '';
                const selected = isCellSelected(row.id, col.id) ? 'box-shadow:inset 0 0 0 2px #409eff;' : '';
                // 检查是否被合并的单元格（非主单元格）
                const hiddenByMerge = isHiddenByMerge(row.id, col.id);
                if (hiddenByMerge) {
                    html += `<td data-row-id="${row.id}" data-col-id="${col.id}" class="merge-covered-cell" style="display:none;"></td>`;
                } else {
                    const merge = getMergeForCell(row.id, col.id);
                    const rs = merge ? `rowspan="${merge.rowspan}"` : '';
                    const cs = merge ? `colspan="${merge.colspan}"` : '';
                    // 计算合并后的总高度
                    let totalHeight = h;
                    if (merge && merge.rowspan > 1) {
                        totalHeight = 0;
                        for (let ri = 0; ri < merge.rowspan; ri++) {
                            const targetRow = g.rows[rowIdx + ri];
                            if (targetRow) totalHeight += g.rowHeights[targetRow.id] || 32;
                        }
                    }
                    const tdHeight = merge ? `height:${totalHeight}px;min-height:${totalHeight}px;` : `height:${h}px;min-height:${h}px;`;
                    // 单元格内容 div（展示模式）：用 flex 控制对齐
                    // flex-direction:row（默认）：align-items控制垂直，justify-content控制水平
                    const displayVal = val !== '' ? escapeHtml(val).replace(/\n/g, '<br>') : '&nbsp;';
                    const hAlignFlex = align === 'center' ? 'justify-content:center;' : (align === 'right' ? 'justify-content:flex-end;' : 'justify-content:flex-start;');
                    const vAlignFlex = valign === 'middle' ? 'align-items:center;' : (valign === 'bottom' ? 'align-items:flex-end;' : 'align-items:flex-start;');
                    html += `<td data-row-id="${row.id}" data-col-id="${col.id}" ${rs} ${cs}
                        style="padding:0;position:relative;vertical-align:top;${tdHeight}${bg}${selected}">
                        <div class="cell-display" data-row-id="${row.id}" data-col-id="${col.id}"
                            style="width:100%;height:100%;min-height:${merge ? totalHeight : h}px;display:flex;flex-direction:row;flex-wrap:wrap;${vAlignFlex}${hAlignFlex}${fontFamily}${bold}${fontSize}${fg}padding:6px 10px;box-sizing:border-box;cursor:cell;line-height:1.5;white-space:pre-wrap;word-break:break-word;text-align:${align};">
                            <span style="width:100%;text-align:${align};">${displayVal}</span>
                        </div>
                    </td>`;
                }
            });
            html += '</tr>';
        });

        html += '</tbody></table>';
        container.innerHTML = html;
        bindQuoteGridEvents();
    }

    // === 辅助：将 rowId/colId 转成 index，供所有范围/合并运算使用 ===
    function rowIdToIdx(rowId) {
        if (!quoteGrid) return -1;
        return quoteGrid.rows.findIndex(r => r.id === rowId);
    }
    function colIdToIdx(colId) {
        if (!quoteGrid) return -1;
        return quoteGrid.columns.findIndex(c => c.id === colId);
    }

    // 将 quoteSelection（rowId/colId 格式）统一展开为「索引矩形 + 自动扩展到合并边界」
    function getSelectionRect() {
        if (!quoteSelection || quoteSelection.startRow === null) return null;
        let r1i = rowIdToIdx(Math.min(quoteSelection.startRow, quoteSelection.endRow));
        let r2i = rowIdToIdx(Math.max(quoteSelection.startRow, quoteSelection.endRow));
        let c1i = colIdToIdx(Math.min(quoteSelection.startCol, quoteSelection.endCol));
        let c2i = colIdToIdx(Math.max(quoteSelection.startCol, quoteSelection.endCol));
        if (r1i < 0 || r2i < 0 || c1i < 0 || c2i < 0) return null;
        // 将矩形向外扩展，直到完全包含所有与当前矩形相交的合并块
        // （避免用户选到合并块的一部分，造成合并/拆分混乱）
        const merges = quoteGrid.merges || [];
        let expanded = true;
        let guard = 0;
        while (expanded && guard < 100) {
            expanded = false;
            guard++;
            for (const m of merges) {
                const mRi = rowIdToIdx(m.row);
                const mCi = colIdToIdx(m.col);
                if (mRi < 0 || mCi < 0) continue;
                const mR2i = mRi + m.rowspan - 1;
                const mC2i = mCi + m.colspan - 1;
                // 相交：不是 (m 完全在当前左边 或 右边 或 上边 或 下边)
                const intersect = !(mR2i < r1i || mRi > r2i || mC2i < c1i || mCi > c2i);
                if (intersect) {
                    const nr1 = Math.min(r1i, mRi);
                    const nr2 = Math.max(r2i, mR2i);
                    const nc1 = Math.min(c1i, mCi);
                    const nc2 = Math.max(c2i, mC2i);
                    if (nr1 !== r1i || nr2 !== r2i || nc1 !== c1i || nc2 !== c2i) {
                        r1i = nr1; r2i = nr2; c1i = nc1; c2i = nc2;
                        expanded = true;
                    }
                }
            }
        }
        return { r1i, r2i, c1i, c2i };
    }

    function isCellSelected(rowId, colId) {
        const rect = getSelectionRect();
        if (!rect) return false;
        const ri = rowIdToIdx(rowId);
        const ci = colIdToIdx(colId);
        if (ri < 0 || ci < 0) return false;
        return ri >= rect.r1i && ri <= rect.r2i && ci >= rect.c1i && ci <= rect.c2i;
    }

    // 找到包含 (rowId, colId) 的合并块（无论是主单元格还是被覆盖单元格）
    function findMergeContaining(rowId, colId) {
        if (!quoteGrid.merges) return null;
        const ri = rowIdToIdx(rowId);
        const ci = colIdToIdx(colId);
        if (ri < 0 || ci < 0) return null;
        for (const m of quoteGrid.merges) {
            const mRi = rowIdToIdx(m.row);
            const mCi = colIdToIdx(m.col);
            if (mRi < 0 || mCi < 0) continue;
            if (ri >= mRi && ri < mRi + m.rowspan &&
                ci >= mCi && ci < mCi + m.colspan) {
                return m;
            }
        }
        return null;
    }

    function getMergeForCell(rowId, colId) {
        if (!quoteGrid.merges) return null;
        return quoteGrid.merges.find(m => m.row === rowId && m.col === colId);
    }

    function isHiddenByMerge(rowId, colId) {
        if (!quoteGrid.merges) return false;
        // 如果是合并块的主单元格，不隐藏
        if (getMergeForCell(rowId, colId)) return false;
        // 其他被合并块覆盖的单元格才隐藏
        return findMergeContaining(rowId, colId) !== null;
    }

    // 判断某一行是否完全被合并覆盖（非主行，用于隐藏该行的边框）
    function isRowCoveredByMerge(rowId) {
        if (!quoteGrid.merges) return false;
        const ri = rowIdToIdx(rowId);
        if (ri < 0) return false;
        return quoteGrid.merges.some(m => {
            const mRi = rowIdToIdx(m.row);
            if (mRi < 0) return false;
            // 主行 ri 在 合并主行 mRi 之后，且在合并范围之内（但不是合并主行）
            return ri > mRi && ri < mRi + m.rowspan;
        });
    }

    function bindQuoteGridEvents() {
        const container = document.getElementById('quoteGridContainer');
        if (!container) return;
        const table = container.querySelector('#quoteGridTable');
        if (!table) return;

        // 当前编辑状态
        let editingCell = null; // {rowId, colId, textarea, originalValue}

        // 更新选中视觉
        function updateQuoteSelectionVisual() {
            table.querySelectorAll('td[data-row-id][data-col-id]').forEach(cell => {
                const r = parseInt(cell.dataset.rowId);
                const c = parseInt(cell.dataset.colId);
                if (isCellSelected(r, c)) {
                    cell.style.boxShadow = 'inset 0 0 0 2px #409eff';
                } else {
                    cell.style.boxShadow = '';
                }
            });
            // 同步更新工具栏状态（显示当前字号等）
            if (typeof updateQuoteToolbarState === 'function') updateQuoteToolbarState();
        }

        // 进入编辑模式
        function startEditing(rowId, colId, initialValue) {
            // 先退出当前编辑
            finishEditing(true);
            const td = table.querySelector(`td[data-row-id="${rowId}"][data-col-id="${colId}"]`);
            if (!td) return;
            const displayDiv = td.querySelector('.cell-display');
            if (!displayDiv) return;

            const row = quoteGrid.rows.find(r => r.id === rowId);
            if (!row) return;
            const currentValue = initialValue !== undefined ? initialValue : (row.cells[colId] || '');
            const key = `${rowId}_${colId}`;
            const style = quoteGrid.styles[key] || {};
            const align = style.align || 'left';
            const valign = style.valign || (getMergeForCell(rowId, colId) ? 'middle' : 'top');
            const bold = style.bold ? 'font-weight:bold;' : '';
            const fontSize = style.fontSize ? `font-size:${style.fontSize}px;` : '';
            const fontFamily = style.fontFamily ? `font-family:${style.fontFamily};` : '';
            const fg = style.fg ? `color:${style.fg};` : '';

            // 计算合并后的高度
            const merge = getMergeForCell(rowId, colId);
            let h = quoteGrid.rowHeights[rowId] || 32;
            if (merge && merge.rowspan > 1) {
                h = 0;
                const rowIdx = quoteGrid.rows.findIndex(r => r.id === rowId);
                for (let ri = 0; ri < merge.rowspan; ri++) {
                    const tr = quoteGrid.rows[rowIdx + ri];
                    if (tr) h += quoteGrid.rowHeights[tr.id] || 32;
                }
            }

            // 不隐藏 displayDiv，而是用带背景色的 editWrapper 绝对定位覆盖在上面
            // 这样 displayDiv 的 flex 布局状态完全不受影响，退出编辑后不会错位
            const hAlignFlex = align === 'center' ? 'justify-content:center;' : (align === 'right' ? 'justify-content:flex-end;' : 'justify-content:flex-start;');
            const vAlignFlex = valign === 'middle' ? 'align-items:center;' : (valign === 'bottom' ? 'align-items:flex-end;' : 'align-items:flex-start;');
            const editWrapper = document.createElement('div');
            editWrapper.className = 'cell-edit-wrapper';
            // 背景色从 style.bg 取，没有则用白色覆盖，确保看不到下面的 displayDiv
            const bgColor = style.bg || '#ffffff';
            editWrapper.style.cssText = `position:absolute;top:0;left:0;right:0;bottom:0;display:flex;flex-direction:row;${vAlignFlex}${hAlignFlex};padding:0;z-index:10;background:${bgColor};`;
            const textarea = document.createElement('textarea');
            textarea.value = currentValue;
            // min-height 用单元格实际高度（含合并），确保内容少时与非编辑模式位置一致
            textarea.style.cssText = `width:100%;min-height:${h}px;border:0;outline:2px solid #409eff;box-shadow:none;padding:6px 10px;background:transparent;${fontFamily}${bold}${fontSize}${fg}text-align:${align};resize:none;overflow:auto;line-height:1.5;white-space:pre-wrap;word-break:break-word;box-sizing:border-box;-webkit-appearance:none;appearance:none;`;
            textarea.dataset.rowId = rowId;
            textarea.dataset.colId = colId;
            editWrapper.appendChild(textarea);
            td.appendChild(editWrapper);
            textarea.focus();
            // 初始化时自适应高度 + 光标定位
            requestAnimationFrame(() => {
                // 内容多时可以扩展，少时保持单元格高度
                const needed = textarea.scrollHeight;
                textarea.style.height = Math.max(h, needed) + 'px';
                // 如果是直接输入字符进入编辑，光标放到末尾；否则全选
                if (initialValue === undefined) {
                    textarea.select();
                } else {
                    const len = textarea.value.length;
                    textarea.setSelectionRange(len, len);
                }
            });

            editingCell = {
                rowId, colId, textarea,
                originalValue: row.cells[colId] || ''
            };

            // 保存编辑
            function saveEdit() {
                if (!editingCell) return;
                const r = quoteGrid.rows.find(rr => rr.id === editingCell.rowId);
                if (r) {
                    r.cells[editingCell.colId] = editingCell.textarea.value;
                    saveQuoteGridDebounced();
                }
            }

            textarea.addEventListener('input', () => {
                // 实时保存
                const r = quoteGrid.rows.find(rr => rr.id === rowId);
                if (r) r.cells[colId] = textarea.value;
                saveQuoteGridDebounced();
                // 自动调整高度（保持最小单元格高度，内容多时扩展）
                textarea.style.height = 'auto';
                textarea.style.height = Math.max(h, textarea.scrollHeight) + 'px';
            });

            textarea.addEventListener('keydown', (e) => {
                // Esc：取消编辑
                if (e.key === 'Escape') {
                    e.preventDefault();
                    // 恢复原值
                    const r = quoteGrid.rows.find(rr => rr.id === rowId);
                    if (r) r.cells[colId] = editingCell.originalValue;
                    finishEditing(false);
                    return;
                }
                // Alt+Enter：换行
                if (e.key === 'Enter' && e.altKey) {
                    e.preventDefault();
                    const start = textarea.selectionStart;
                    const end = textarea.selectionEnd;
                    const val = textarea.value;
                    textarea.value = val.substring(0, start) + '\n' + val.substring(end);
                    textarea.selectionStart = textarea.selectionEnd = start + 1;
                    // 触发 input 事件保存并调整高度
                    textarea.dispatchEvent(new Event('input'));
                    return;
                }
                // Enter：保存并跳到下一行
                if (e.key === 'Enter') {
                    e.preventDefault();
                    saveEdit();
                    finishEditing(true);
                    moveSelection(1, 0);
                    return;
                }
                // Tab：保存并跳到下一列
                if (e.key === 'Tab') {
                    e.preventDefault();
                    saveEdit();
                    finishEditing(true);
                    moveSelection(0, e.shiftKey ? -1 : 1);
                    return;
                }
            });

            textarea.addEventListener('blur', () => {
                // 失焦时保存
                if (editingCell) {
                    saveEdit();
                    finishEditing(true);
                }
            });
        }

        // 退出编辑模式
        function finishEditing(commit) {
            if (!editingCell) return;
            const { rowId, colId, textarea } = editingCell;
            const td = table.querySelector(`td[data-row-id="${rowId}"][data-col-id="${colId}"]`);
            // 移除 wrapper（包含 textarea）
            const wrapper = td ? td.querySelector('.cell-edit-wrapper') : null;
            if (wrapper && wrapper.parentNode === td) {
                td.removeChild(wrapper);
            } else if (td && textarea.parentNode === td) {
                td.removeChild(textarea);
            }
            // displayDiv 从未被隐藏，只需要更新内容（保持与渲染时一致的结构：带 span）
            const displayDiv = td ? td.querySelector('.cell-display') : null;
            if (displayDiv) {
                const row = quoteGrid.rows.find(r => r.id === rowId);
                const val = row ? (row.cells[colId] || '') : '';
                const key = `${rowId}_${colId}`;
                const style = quoteGrid.styles[key] || {};
                const align = style.align || 'left';
                const displayVal = val !== '' ? escapeHtml(val).replace(/\n/g, '<br>') : '&nbsp;';
                displayDiv.innerHTML = `<span style="width:100%;text-align:${align};">${displayVal}</span>`;
            }
            editingCell = null;
        }

        // 移动选中
        function moveSelection(dRow, dCol) {
            if (!quoteSelection || quoteSelection.startRow === null) return;
            const rowIdx = quoteGrid.rows.findIndex(r => r.id === quoteSelection.endRow);
            const colIdx = quoteGrid.columns.findIndex(c => c.id === quoteSelection.endCol);
            const newRowIdx = Math.max(0, Math.min(quoteGrid.rows.length - 1, rowIdx + dRow));
            const newColIdx = Math.max(0, Math.min(quoteGrid.columns.length - 1, colIdx + dCol));
            const newRowId = quoteGrid.rows[newRowIdx].id;
            const newColId = quoteGrid.columns[newColIdx].id;
            // 如果被合并覆盖，找到主单元格（用 index 比较，而不是 ID）
            let finalRowId = newRowId, finalColId = newColId;
            for (const m of (quoteGrid.merges || [])) {
                const mRi = rowIdToIdx(m.row);
                const mCi = colIdToIdx(m.col);
                if (mRi < 0 || mCi < 0) continue;
                if (newRowIdx >= mRi && newRowIdx < mRi + m.rowspan &&
                    newColIdx >= mCi && newColIdx < mCi + m.colspan) {
                    finalRowId = m.row;
                    finalColId = m.col;
                    break;
                }
            }
            quoteSelection = {
                ...quoteSelection,
                startRow: finalRowId, startCol: finalColId,
                endRow: finalRowId, endCol: finalColId,
                selecting: false
            };
            updateQuoteSelectionVisual();
        }

        // 单击：选中单元格
        table.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            if (e.target.classList && (e.target.classList.contains('col-resize-handle') || e.target.classList.contains('row-resize-handle'))) return;
            if (e.target.tagName === 'TEXTAREA') return; // 编辑中不处理

            const td = e.target.closest('td[data-row-id][data-col-id]');
            if (!td) return;
            const rowId = parseInt(td.dataset.rowId);
            const colId = parseInt(td.dataset.colId);
            if (isHiddenByMerge(rowId, colId)) return;

            // 如果正在编辑别的单元格，先保存
            if (editingCell && (editingCell.rowId !== rowId || editingCell.colId !== colId)) {
                finishEditing(true);
            }

            // 聚焦容器，确保键盘事件（Del/方向键）能响应
            const container = document.getElementById('quoteGridContainer');
            if (container) container.focus({ preventScroll: true });

            quoteSelection._startX = e.clientX;
            quoteSelection._startY = e.clientY;
            quoteSelection._startRow = rowId;
            quoteSelection._startCol = colId;
            quoteSelection = {
                ...quoteSelection,
                startRow: rowId, startCol: colId,
                endRow: rowId, endCol: colId,
                selecting: true
            };
            updateQuoteSelectionVisual();
            e.preventDefault();
        });

        // 双击：进入编辑
        table.addEventListener('dblclick', (e) => {
            const td = e.target.closest('td[data-row-id][data-col-id]');
            if (!td) return;
            const rowId = parseInt(td.dataset.rowId);
            const colId = parseInt(td.dataset.colId);
            if (isHiddenByMerge(rowId, colId)) return;
            startEditing(rowId, colId);
        });

        // 列双击重命名
        table.querySelectorAll('.col-header').forEach(header => {
            header.addEventListener('dblclick', () => {
                const colId = parseInt(header.dataset.colId);
                const col = quoteGrid.columns.find(c => c.id === colId);
                if (!col) return;
                const nameSpan = header.querySelector('.col-name');
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'col-rename-input';
                input.value = col.name;
                nameSpan.replaceWith(input);
                input.focus();
                input.select();
                const finish = () => {
                    col.name = input.value.trim() || col.name;
                    saveQuoteGridDebounced();
                    renderQuoteGrid();
                };
                input.addEventListener('blur', finish);
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
                    if (e.key === 'Escape') { input.value = col.name; input.blur(); }
                });
            });
        });

        // 列宽调整
        table.querySelectorAll('.col-resize-handle').forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                const colId = parseInt(handle.dataset.colId);
                const startX = e.clientX;
                const startW = quoteGrid.colWidths[colId] || 120;
                const onMove = (ev) => {
                    const newW = Math.max(50, startW + (ev.clientX - startX));
                    quoteGrid.colWidths[colId] = newW;
                    const ths = table.querySelectorAll(`th[data-col-id="${colId}"]`);
                    ths.forEach(th => { th.style.width = newW + 'px'; th.style.minWidth = newW + 'px'; });
                };
                const onUp = () => {
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    saveQuoteGridDebounced();
                    renderQuoteGrid();
                };
                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            });
        });

        // 行高调整
        table.querySelectorAll('.row-resize-handle').forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                const rowId = parseInt(handle.dataset.rowId);
                const startY = e.clientY;
                const startH = quoteGrid.rowHeights[rowId] || 32;
                const onMove = (ev) => {
                    const newH = Math.max(24, startH + (ev.clientY - startY));
                    quoteGrid.rowHeights[rowId] = newH;
                    const tr = table.querySelector(`tr[data-row-id="${rowId}"]`);
                    if (tr) tr.style.height = newH + 'px';
                };
                const onUp = () => {
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    saveQuoteGridDebounced();
                    renderQuoteGrid();
                };
                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            });
        });

        // 右键菜单
        table.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            showQuoteContextMenu(e);
        });
    }

    // 在选中范围的基础行/列插入多行/多列（before: true -> 在前面插入）
    function insertQuoteRows(baseRowIdx, n, before) {
        if (!quoteGrid) return;
        n = Math.max(1, Math.min(100, parseInt(n) || 1));
        // 先准备新行对象，再 splice 到 rows 数组中
        const newRows = [];
        for (let i = 0; i < n; i++) {
            const row = { id: quoteGrid.nextRowId++, cells: {} };
            quoteGrid.columns.forEach(col => { row.cells[col.id] = ''; });
            newRows.push(row);
        }
        // insert at baseRowIdx (before) 或 baseRowIdx+1 (after)
        const insertAt = before ? baseRowIdx : baseRowIdx + 1;

        // ★ 关键修复：在 splice 之前先处理合并
        const isInsertAtEnd = insertAt >= quoteGrid.rows.length;
        if (isInsertAtEnd) {
            // 插入在表格末尾：仅扩展确实跨越插入点的合并（数据异常时）
            // 正常情况下合并在插入点之前结束，不应扩展，新行保持独立
            for (const m of (quoteGrid.merges || [])) {
                const mainIdx = quoteGrid.rows.findIndex(r => r.id === m.row);
                if (mainIdx >= 0 && mainIdx + m.rowspan > insertAt) {
                    m.rowspan += n;
                }
            }
        } else {
            // 插入在表格中间：拆分跨越插入点的合并，使新行保持独立
            const mergesToSplit = [];
            for (const m of (quoteGrid.merges || [])) {
                const mainIdx = quoteGrid.rows.findIndex(r => r.id === m.row);
                if (mainIdx >= 0 && mainIdx < insertAt && mainIdx + m.rowspan > insertAt) {
                    mergesToSplit.push({ m, mainIdx });
                }
            }
            for (const { m, mainIdx } of mergesToSplit) {
                const origRowspan = m.rowspan;
                // 原合并：只保留插入点之前的部分
                m.rowspan = insertAt - mainIdx;
                // 如果插入点之后还有行被原合并覆盖，创建新合并
                const remainingSpan = origRowspan - (insertAt - mainIdx);
                if (remainingSpan > 0) {
                    const newMainRowId = quoteGrid.rows[insertAt].id;
                    quoteGrid.merges.push({
                        row: newMainRowId,
                        col: m.col,
                        rowspan: remainingSpan,
                        colspan: m.colspan
                    });
                }
            }
        }

        quoteGrid.rows.splice(insertAt, 0, ...newRows);

        saveQuoteGridDebounced();
        renderQuoteGrid();
    }
    function insertQuoteCols(baseColIdx, n, before) {
        if (!quoteGrid) return;
        n = Math.max(1, Math.min(100, parseInt(n) || 1));
        const newCols = [];
        for (let i = 0; i < n; i++) {
            const col = { id: quoteGrid.nextColId++, name: '列' + (quoteGrid.columns.length + newCols.length + 1) };
            newCols.push(col);
            quoteGrid.colWidths[col.id] = 120;
        }
        const insertAt = before ? baseColIdx : baseColIdx + 1;

        // ★ 关键修复：在 splice 之前先处理合并
        const isInsertAtEnd = insertAt >= quoteGrid.columns.length;
        if (isInsertAtEnd) {
            // 插入在最后：仅扩展确实跨越插入点的列合并（数据异常时）
            for (const m of (quoteGrid.merges || [])) {
                const mainIdx = quoteGrid.columns.findIndex(c => c.id === m.col);
                if (mainIdx >= 0 && mainIdx + m.colspan > insertAt) {
                    m.colspan += n;
                }
            }
        } else {
            // 插入在中间：拆分跨越插入点的列合并
            const mergesToSplit = [];
            for (const m of (quoteGrid.merges || [])) {
                const mainIdx = quoteGrid.columns.findIndex(c => c.id === m.col);
                if (mainIdx >= 0 && mainIdx < insertAt && mainIdx + m.colspan > insertAt) {
                    mergesToSplit.push({ m, mainIdx });
                }
            }
            for (const { m, mainIdx } of mergesToSplit) {
                const origColspan = m.colspan;
                // 原合并：只保留插入点之前的部分
                m.colspan = insertAt - mainIdx;
                // 如果插入点之后还有列被原合并覆盖，创建新合并
                const remainingSpan = origColspan - (insertAt - mainIdx);
                if (remainingSpan > 0) {
                    const newMainColId = quoteGrid.columns[insertAt].id;
                    quoteGrid.merges.push({
                        row: m.row,
                        col: newMainColId,
                        rowspan: m.rowspan,
                        colspan: remainingSpan
                    });
                }
            }
        }

        quoteGrid.columns.splice(insertAt, 0, ...newCols);
        // 现有每行给新列补空值
        quoteGrid.rows.forEach(row => {
            newCols.forEach(col => { row.cells[col.id] = ''; });
        });

        saveQuoteGridDebounced();
        renderQuoteGrid();
    }
    // 切换行/列的隐藏（不显示在图片中）
    function toggleQuoteRowHidden(rowId) {
        if (!quoteGrid) return;
        if (!Array.isArray(quoteGrid.hiddenRows)) quoteGrid.hiddenRows = [];
        const idx = quoteGrid.hiddenRows.indexOf(rowId);
        if (idx >= 0) quoteGrid.hiddenRows.splice(idx, 1);
        else quoteGrid.hiddenRows.push(rowId);
        saveQuoteGridDebounced();
        renderQuoteGrid();
    }
    function toggleQuoteColHidden(colId) {
        if (!quoteGrid) return;
        if (!Array.isArray(quoteGrid.hiddenCols)) quoteGrid.hiddenCols = [];
        const idx = quoteGrid.hiddenCols.indexOf(colId);
        if (idx >= 0) quoteGrid.hiddenCols.splice(idx, 1);
        else quoteGrid.hiddenCols.push(colId);
        saveQuoteGridDebounced();
        renderQuoteGrid();
    }

    let quoteCtxMenuEl = null;
    function closeQuoteContextMenu() {
        if (quoteCtxMenuEl && quoteCtxMenuEl.parentNode) quoteCtxMenuEl.parentNode.removeChild(quoteCtxMenuEl);
        quoteCtxMenuEl = null;
    }
    function showQuoteContextMenu(e) {
        closeQuoteContextMenu();
        if (!quoteGrid) return;
        const target = e.target;
        // 判断上下文：行头 / 列头 / 单元格
        let ctx = null; // {type:'row', rowIdx, rowId?} | {type:'col', colIdx, colId?} | {type:'cell', rowIdx, colIdx}
        const rowHeaderEl = target.closest ? target.closest('td.row-header[data-row-id]') : null;
        const colHeaderEl = target.closest ? target.closest('th[data-col-id]') : null;
        const cellEl = target.closest ? target.closest('td[data-row-id][data-col-id]') : null;
        if (rowHeaderEl) {
            const rowId = parseInt(rowHeaderEl.dataset.rowId);
            const rowIdx = quoteGrid.rows.findIndex(r => r.id === rowId);
            if (rowIdx >= 0) ctx = { type: 'row', rowIdx, rowId };
        } else if (colHeaderEl && !colHeaderEl.classList.contains('corner-cell')) {
            const colId = parseInt(colHeaderEl.dataset.colId);
            const colIdx = quoteGrid.columns.findIndex(c => c.id === colId);
            if (colIdx >= 0) ctx = { type: 'col', colIdx, colId };
        } else if (cellEl) {
            const rowId = parseInt(cellEl.dataset.rowId);
            const colId = parseInt(cellEl.dataset.colId);
            const rowIdx = quoteGrid.rows.findIndex(r => r.id === rowId);
            const colIdx = quoteGrid.columns.findIndex(c => c.id === colId);
            if (rowIdx >= 0 && colIdx >= 0) ctx = { type: 'cell', rowIdx, colIdx, rowId, colId };
        } else {
            return;
        }
        const askN = (labelText, cb) => {
            const n = prompt(labelText, '1');
            if (n === null) return;
            let num = parseInt(n);
            if (isNaN(num) || num < 1) num = 1;
            if (num > 100) num = 100;
            cb(num);
        };
        const items = [];
        if (ctx.type === 'row' || ctx.type === 'cell') {
            const idx = ctx.rowIdx;
            items.push({ label: '⬆ 上方插入 1 行', action: () => insertQuoteRows(idx, 1, true) });
            items.push({ label: '⬆ 上方插入 N 行...', action: () => askN('请输入要插入的行数（1-100）：', (n) => insertQuoteRows(idx, n, true)) });
            items.push({ label: '⬇ 下方插入 1 行', action: () => insertQuoteRows(idx, 1, false) });
            items.push({ label: '⬇ 下方插入 N 行...', action: () => askN('请输入要插入的行数（1-100）：', (n) => insertQuoteRows(idx, n, false)) });
            if (ctx.type === 'row') {
                const hidden = (quoteGrid.hiddenRows || []).indexOf(ctx.rowId) >= 0;
                items.push({ separator: true });
                items.push({ label: hidden ? '显示该行（生成图片中显示）' : '隐藏该行（生成图片中不显示）', action: () => toggleQuoteRowHidden(ctx.rowId) });
            }
        }
        if (ctx.type === 'col' || ctx.type === 'cell') {
            if (items.length > 0) items.push({ separator: true });
            const idx = ctx.colIdx;
            items.push({ label: '⬅ 左侧插入 1 列', action: () => insertQuoteCols(idx, 1, true) });
            items.push({ label: '⬅ 左侧插入 N 列...', action: () => askN('请输入要插入的列数（1-100）：', (n) => insertQuoteCols(idx, n, true)) });
            items.push({ label: '➡ 右侧插入 1 列', action: () => insertQuoteCols(idx, 1, false) });
            items.push({ label: '➡ 右侧插入 N 列...', action: () => askN('请输入要插入的列数（1-100）：', (n) => insertQuoteCols(idx, n, false)) });
            if (ctx.type === 'col') {
                const hidden = (quoteGrid.hiddenCols || []).indexOf(ctx.colId) >= 0;
                items.push({ separator: true });
                items.push({ label: hidden ? '显示该列（生成图片中显示）' : '隐藏该列（生成图片中不显示）', action: () => toggleQuoteColHidden(ctx.colId) });
            }
        }
        // 生成菜单 DOM
        const menu = document.createElement('div');
        menu.className = 'ctx-menu';
        menu.style.cssText = `position:fixed;z-index:99999;left:${e.clientX}px;top:${e.clientY}px;min-width:200px;background:#fff;border:1px solid #dcdfe6;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.12);padding:6px 0;font-size:13px;color:#303133;`;
        items.forEach((it) => {
            if (it.separator) {
                const hr = document.createElement('div');
                hr.style.cssText = 'height:1px;background:#ebeef5;margin:6px 0;';
                menu.appendChild(hr);
                return;
            }
            const div = document.createElement('div');
            div.textContent = it.label;
            div.style.cssText = 'padding:7px 14px;cursor:pointer;white-space:nowrap;';
            div.onmouseenter = () => { div.style.background = '#f0f7ff'; div.style.color = '#409eff'; };
            div.onmouseleave = () => { div.style.background = ''; div.style.color = ''; };
            div.onclick = () => {
                closeQuoteContextMenu();
                try { it.action(); } catch (err) { console.error(err); }
            };
            menu.appendChild(div);
        });
        document.body.appendChild(menu);
        quoteCtxMenuEl = menu;
        // 位置修正
        requestAnimationFrame(() => {
            const rect = menu.getBoundingClientRect();
            let left = e.clientX, top = e.clientY;
            const vw = window.innerWidth, vh = window.innerHeight;
            if (left + rect.width > vw - 4) left = vw - rect.width - 4;
            if (top + rect.height > vh - 4) top = vh - rect.height - 4;
            menu.style.left = left + 'px';
            menu.style.top = top + 'px';
        });
        // 关闭逻辑
        const onDocDown = (ev) => {
            if (quoteCtxMenuEl && quoteCtxMenuEl.contains && !quoteCtxMenuEl.contains(ev.target)) {
                closeQuoteContextMenu();
                document.removeEventListener('mousedown', onDocDown, true);
                document.removeEventListener('keydown', onKeyEsc, true);
            }
        };
        const onKeyEsc = (ev) => {
            if (ev.key === 'Escape') {
                closeQuoteContextMenu();
                document.removeEventListener('mousedown', onDocDown, true);
                document.removeEventListener('keydown', onKeyEsc, true);
            }
        };
        document.addEventListener('mousedown', onDocDown, true);
        document.addEventListener('keydown', onKeyEsc, true);
    }

    // 报价网格全局键盘事件 — 只绑定一次
    if (!quoteGridEventsBound) {
        document.addEventListener('keydown', (e) => {
            if (!quoteGrid) return;
            const container = document.getElementById('quoteGridContainer');
            const toolbar = document.getElementById('quoteToolbar');
            if (!container) return;
            // 焦点在报价网格或工具栏内时才响应
            const inQuote = e.target.closest('#quoteGridContainer') !== null
                || e.target.closest('#quoteToolbar') !== null;
            if (!inQuote) return;

            // 如果正在编辑（有 textarea），大部分键不拦截（交给编辑逻辑）
            const activeTextarea = container.querySelector('textarea[data-row-id]');
            if (activeTextarea) return;

            // F2：进入编辑
            if (e.key === 'F2') {
                if (!quoteSelection || quoteSelection.startRow === null) return;
                e.preventDefault();
                // 手动启动编辑（需要找到 bindQuoteGridEvents 内部的 startEditing）
                // 通过触发双击事件来间接调用
                const td = container.querySelector(`td[data-row-id="${quoteSelection.startRow}"][data-col-id="${quoteSelection.startCol}"]`);
                if (td) {
                    const displayDiv = td.querySelector('.cell-display');
                    if (displayDiv) {
                        const event = new MouseEvent('dblclick', { bubbles: true });
                        displayDiv.dispatchEvent(event);
                    }
                }
                return;
            }

            // 方向键：移动选中
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
                if (!quoteSelection || quoteSelection.startRow === null) return;
                e.preventDefault();
                const dRow = e.key === 'ArrowDown' ? 1 : (e.key === 'ArrowUp' ? -1 : 0);
                const dCol = e.key === 'ArrowRight' ? 1 : (e.key === 'ArrowLeft' ? -1 : 0);
                // 模拟移动 - 直接操作 quoteSelection
                const rowIdx = quoteGrid.rows.findIndex(r => r.id === quoteSelection.endRow);
                const colIdx = quoteGrid.columns.findIndex(c => c.id === quoteSelection.endCol);
                const newRowIdx = Math.max(0, Math.min(quoteGrid.rows.length - 1, rowIdx + dRow));
                const newColIdx = Math.max(0, Math.min(quoteGrid.columns.length - 1, colIdx + dCol));
                let newRowId = quoteGrid.rows[newRowIdx].id;
                let newColId = quoteGrid.columns[newColIdx].id;
                // 如果被合并覆盖，找到主单元格（用 index 比较，而不是 ID）
                for (const m of (quoteGrid.merges || [])) {
                    const mRi = rowIdToIdx(m.row);
                    const mCi = colIdToIdx(m.col);
                    if (mRi < 0 || mCi < 0) continue;
                    if (newRowIdx >= mRi && newRowIdx < mRi + m.rowspan &&
                        newColIdx >= mCi && newColIdx < mCi + m.colspan) {
                        newRowId = m.row;
                        newColId = m.col;
                        break;
                    }
                }
                quoteSelection = {
                    ...quoteSelection,
                    startRow: newRowId, startCol: newColId,
                    endRow: newRowId, endCol: newColId,
                    selecting: false
                };
                // 更新视觉
                const table = container.querySelector('#quoteGridTable');
                if (table) {
                    table.querySelectorAll('td[data-row-id][data-col-id]').forEach(cell => {
                        const r = parseInt(cell.dataset.rowId);
                        const c = parseInt(cell.dataset.colId);
                        if (r === newRowId && c === newColId) {
                            cell.style.boxShadow = 'inset 0 0 0 2px #409eff';
                        } else {
                            cell.style.boxShadow = '';
                        }
                    });
                }
                return;
            }

            // Enter：进入编辑（或跳到下一行）
            if (e.key === 'Enter' && !e.shiftKey && !e.altKey) {
                if (!quoteSelection || quoteSelection.startRow === null) return;
                e.preventDefault();
                // 先下移动一行，然后进入编辑
                const rowIdx = quoteGrid.rows.findIndex(r => r.id === quoteSelection.endRow);
                if (rowIdx < quoteGrid.rows.length - 1) {
                    const nextRow = quoteGrid.rows[rowIdx + 1];
                    quoteSelection = {
                        ...quoteSelection,
                        startRow: nextRow.id, startCol: quoteSelection.endCol,
                        endRow: nextRow.id, endCol: quoteSelection.endCol
                    };
                }
                // 触发编辑
                const td = container.querySelector(`td[data-row-id="${quoteSelection.startRow}"][data-col-id="${quoteSelection.startCol}"]`);
                if (td) {
                    const displayDiv = td.querySelector('.cell-display');
                    if (displayDiv) {
                        const event = new MouseEvent('dblclick', { bubbles: true });
                        displayDiv.dispatchEvent(event);
                    }
                }
                return;
            }

            // Tab：跳到下一列
            if (e.key === 'Tab') {
                if (!quoteSelection || quoteSelection.startRow === null) return;
                e.preventDefault();
                const colIdx = quoteGrid.columns.findIndex(c => c.id === quoteSelection.endCol);
                const delta = e.shiftKey ? -1 : 1;
                const newIdx = Math.max(0, Math.min(quoteGrid.columns.length - 1, colIdx + delta));
                const targetCol = quoteGrid.columns[newIdx];
                quoteSelection = {
                    ...quoteSelection,
                    startRow: quoteSelection.endRow, startCol: targetCol.id,
                    endRow: quoteSelection.endRow, endCol: targetCol.id
                };
                // 更新视觉
                const table = container.querySelector('#quoteGridTable');
                if (table) {
                    table.querySelectorAll('td[data-row-id][data-col-id]').forEach(cell => {
                        const r = parseInt(cell.dataset.rowId);
                        const c = parseInt(cell.dataset.colId);
                        if (r === quoteSelection.endRow && c === quoteSelection.endCol) {
                            cell.style.boxShadow = 'inset 0 0 0 2px #409eff';
                        } else {
                            cell.style.boxShadow = '';
                        }
                    });
                }
                return;
            }

            // Ctrl+C：复制选中区域（TSV格式，支持粘贴到Excel）
            if (e.ctrlKey && (e.key === 'c' || e.key === 'C')) {
                const rect = getSelectionRect();
                if (!rect) return;
                e.preventDefault();
                const { r1i, r2i, c1i, c2i } = rect;
                const lines = [];
                for (let ri = r1i; ri <= r2i; ri++) {
                    const row = quoteGrid.rows[ri];
                    if (!row) continue;
                    const rowId = row.id;
                    const cells = [];
                    for (let ci = c1i; ci <= c2i; ci++) {
                        const col = quoteGrid.columns[ci];
                        if (!col) continue;
                        const colId = col.id;
                        if (isHiddenByMerge(rowId, colId)) continue;
                        cells.push(row.cells[colId] || '');
                    }
                    lines.push(cells.join('\t'));
                }
                const text = lines.join('\n');
                try {
                    navigator.clipboard.writeText(text).then(() => setStatus('已复制 ' + lines.length + ' 行'));
                } catch (err) {
                    const ta = document.createElement('textarea');
                    ta.value = text;
                    document.body.appendChild(ta);
                    ta.select();
                    try { document.execCommand('copy'); setStatus('已复制 ' + lines.length + ' 行'); } catch(e) {}
                    document.body.removeChild(ta);
                }
                return;
            }

            // Ctrl+V：粘贴（支持 TSV/CSV 格式）
            if (e.ctrlKey && (e.key === 'v' || e.key === 'V')) {
                const rect = getSelectionRect();
                if (!rect) return;
                e.preventDefault();
                const startRi = rect.r1i;
                const startCi = rect.c1i;
                const applyPaste = (text) => {
                    const lines = text.replace(/\r\n/g, '\n').split('\n');
                    let changed = false;
                    lines.forEach((line, i) => {
                        const targetRi = startRi + i;
                        if (targetRi >= quoteGrid.rows.length) return;
                        const row = quoteGrid.rows[targetRi];
                        if (!row) return;
                        let cells = line.split('\t');
                        if (cells.length === 1 && line.indexOf(',') >= 0) cells = line.split(','); // 兼容 CSV
                        cells.forEach((val, j) => {
                            const targetCi = startCi + j;
                            if (targetCi >= quoteGrid.columns.length) return;
                            const colId = quoteGrid.columns[targetCi].id;
                            if (isHiddenByMerge(row.id, colId)) return;
                            if (row.cells[colId] !== val) {
                                row.cells[colId] = val;
                                changed = true;
                            }
                        });
                    });
                    if (changed) {
                        saveQuoteGridDebounced();
                        renderQuoteGrid();
                    }
                };
                try {
                    navigator.clipboard.readText().then(applyPaste).catch(() => setStatus('粘贴失败，请授权剪贴板权限'));
                } catch (err) { setStatus('粘贴失败：' + err.message); }
                return;
            }

            // Delete/Backspace：清空选中单元格
            if (e.key === 'Delete' || e.key === 'Backspace') {
                const rect = getSelectionRect();
                if (!rect) return;
                e.preventDefault();
                const { r1i, r2i, c1i, c2i } = rect;
                let changed = false;
                for (let ri = r1i; ri <= r2i; ri++) {
                    const row = quoteGrid.rows[ri];
                    if (!row) continue;
                    for (let ci = c1i; ci <= c2i; ci++) {
                        const col = quoteGrid.columns[ci];
                        if (!col) continue;
                        if (isHiddenByMerge(row.id, col.id)) continue;
                        if (row.cells[col.id] !== '') {
                            row.cells[col.id] = '';
                            changed = true;
                        }
                    }
                }
                if (changed) {
                    saveQuoteGridDebounced();
                    renderQuoteGrid();
                }
                return;
            }

            // 直接输入字符：进入编辑，用该字符作为起始内容
            if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
                if (!quoteSelection || quoteSelection.startRow === null) return;
                e.preventDefault();
                const td = container.querySelector(`td[data-row-id="${quoteSelection.startRow}"][data-col-id="${quoteSelection.startCol}"]`);
                if (td) {
                    const displayDiv = td.querySelector('.cell-display');
                    if (displayDiv) {
                        // 先设置初始值
                        const row = quoteGrid.rows.find(r => r.id === quoteSelection.startRow);
                        if (row) row.cells[quoteSelection.startCol] = e.key;
                        saveQuoteGridDebounced();
                        // 触发编辑
                        const event = new MouseEvent('dblclick', { bubbles: true });
                        displayDiv.dispatchEvent(event);
                        // 编辑启动后把光标放到末尾
                        setTimeout(() => {
                            const ta = td.querySelector('textarea');
                            if (ta) {
                                const len = ta.value.length;
                                ta.setSelectionRange(len, len);
                            }
                        }, 10);
                    }
                }
                return;
            }
        });
    }

    // document 上的 mousemove/mouseup（只绑定一次）
    if (!quoteGridEventsBound) {
        quoteGridEventsBound = true;
        document.addEventListener('mousemove', (e) => {
            if (!quoteSelection || !quoteSelection.selecting) return;
            // 使用 elementFromPoint 确保即使鼠标移出 table 也能定位 td
            const el = document.elementFromPoint(e.clientX, e.clientY);
            const td = el && el.closest ? el.closest('td[data-row-id][data-col-id]') : null;
            if (!td) return;
            const rowId = parseInt(td.dataset.rowId);
            const colId = parseInt(td.dataset.colId);
            if (isNaN(rowId) || isNaN(colId)) return;
            if (isHiddenByMerge(rowId, colId)) return;
            if (quoteSelection.endRow !== rowId || quoteSelection.endCol !== colId) {
                quoteSelection.endRow = rowId;
                quoteSelection.endCol = colId;
                // 更新视觉
                const table = document.querySelector('#quoteGridTable');
                if (table) {
                    table.querySelectorAll('td[data-row-id][data-col-id]').forEach(cell => {
                        const r = parseInt(cell.dataset.rowId);
                        const c = parseInt(cell.dataset.colId);
                        if (isCellSelected(r, c)) {
                            cell.style.boxShadow = 'inset 0 0 0 2px #409eff';
                        } else {
                            cell.style.boxShadow = '';
                        }
                    });
                }
            }
        });
        document.addEventListener('mouseup', (e) => {
            if (quoteSelection && quoteSelection.selecting) {
                quoteSelection.selecting = false;
            }
        });
        // 防止拖拽时选中文本
        document.addEventListener('selectstart', (e) => {
            if (quoteSelection && quoteSelection.selecting) e.preventDefault();
        });
    }

    // 对选中区域应用样式
    function applyQuoteStyle(key, value) {
        const rect = getSelectionRect();
        if (!rect) return;
        const { r1i, r2i, c1i, c2i } = rect;
        for (let ri = r1i; ri <= r2i; ri++) {
            const rid = quoteGrid.rows[ri].id;
            for (let ci = c1i; ci <= c2i; ci++) {
                const cid = quoteGrid.columns[ci].id;
                const skey = `${rid}_${cid}`;
                if (!quoteGrid.styles[skey]) quoteGrid.styles[skey] = {};
                // 空值或 null/undefined 表示清除该样式
                if (value === null || value === undefined || value === '') delete quoteGrid.styles[skey][key];
                else quoteGrid.styles[skey][key] = value;
            }
        }
        saveQuoteGridDebounced();
        renderQuoteGrid();
        updateQuoteToolbarState();
    }

    // 工具栏按钮
    const quoteAddRowBtn = document.getElementById('quoteAddRowBtn');
    if (quoteAddRowBtn) quoteAddRowBtn.addEventListener('click', () => {
        if (!quoteGrid) quoteGrid = createEmptyQuoteGrid();
        const row = { id: quoteGrid.nextRowId++, cells: {} };
        quoteGrid.columns.forEach(col => { row.cells[col.id] = ''; });
        quoteGrid.rows.push(row);
        saveQuoteGridDebounced();
        renderQuoteGrid();
    });

    const quoteAddColBtn = document.getElementById('quoteAddColBtn');
    if (quoteAddColBtn) quoteAddColBtn.addEventListener('click', () => {
        if (!quoteGrid) quoteGrid = createEmptyQuoteGrid();
        const colName = prompt('请输入列名：', '列' + (quoteGrid.columns.length + 1));
        if (colName === null) return;
        const col = { id: quoteGrid.nextColId++, name: colName.trim() || ('列' + quoteGrid.columns.length) };
        quoteGrid.columns.push(col);
        quoteGrid.colWidths[col.id] = 120;
        quoteGrid.rows.forEach(row => { row.cells[col.id] = ''; });
        saveQuoteGridDebounced();
        renderQuoteGrid();
    });

    const quoteDelRowBtn = document.getElementById('quoteDelRowBtn');
    if (quoteDelRowBtn) quoteDelRowBtn.addEventListener('click', () => {
        if (!quoteGrid) return;
        const rect = getSelectionRect();
        if (!rect) { setStatus('请先选中要删除的行'); return; }
        const { r1i, r2i } = rect;
        if (r2i - r1i + 1 >= quoteGrid.rows.length) { setStatus('至少需要保留1行'); return; }
        // 收集要删除的行 id
        const removedIds = new Set();
        for (let i = r1i; i <= r2i; i++) removedIds.add(quoteGrid.rows[i].id);
        // 调整 merges：
        //   1) 合并主行在删除范围内 → 整条合并删除
        //   2) 合并主行在删除范围之上，但合并范围跨入删除范围 → 缩短 rowspan
        //   3) 合并主行在删除范围之下 → 合并主行 row idx 不变（但因为我们 splice 上方，rowId 不变 => 无需调整 row/col id）
        quoteGrid.merges = (quoteGrid.merges || []).filter(m => {
            const mRi = rowIdToIdx(m.row);
            if (mRi < 0) return false;
            const mR2i = mRi + m.rowspan - 1;
            if (mRi >= r1i && mRi <= r2i) return false; // 主行被删
            if (mR2i < r1i || mRi > r2i) {
                // 完全在删除范围之上或之下；需要检查跨删除区的情况
                if (mRi < r1i && mR2i > r2i) {
                    // 完全跨越删除区：缩短 rowspan
                    m.rowspan -= (r2i - r1i + 1);
                    return true;
                }
                if (mRi < r1i && mR2i >= r1i) {
                    // 尾部被切：rowspan = 删除起始点前的剩余
                    m.rowspan = r1i - mRi;
                    return true;
                }
                return true; // 完全不相交（上面/下面）
            }
            // 剩下的情况：合并主行在删除区上方，但合并块部分进入删除区
            if (mRi < r1i) {
                m.rowspan = r1i - mRi;
                return true;
            }
            return false;
        });
        quoteGrid.rows = quoteGrid.rows.filter(r => !removedIds.has(r.id));
        // hiddenRows 同步清理
        if (Array.isArray(quoteGrid.hiddenRows)) {
            quoteGrid.hiddenRows = quoteGrid.hiddenRows.filter(id => !removedIds.has(id));
        }
        // rowHeights 清理
        if (quoteGrid.rowHeights) {
            removedIds.forEach(id => delete quoteGrid.rowHeights[id]);
        }
        // styles 清理
        if (quoteGrid.styles) {
            Object.keys(quoteGrid.styles).forEach(k => {
                const [ridStr] = k.split('_');
                const rid = parseInt(ridStr);
                if (removedIds.has(rid)) delete quoteGrid.styles[k];
            });
        }
        quoteSelection = { startRow: null, startCol: null, endRow: null, endCol: null, selecting: false };
        saveQuoteGridDebounced();
        renderQuoteGrid();
    });

    const quoteDelColBtn = document.getElementById('quoteDelColBtn');
    if (quoteDelColBtn) quoteDelColBtn.addEventListener('click', () => {
        if (!quoteGrid) return;
        const rect = getSelectionRect();
        if (!rect) { setStatus('请先选中要删除的列'); return; }
        const { c1i, c2i } = rect;
        if (c2i - c1i + 1 >= quoteGrid.columns.length) { setStatus('至少需要保留1列'); return; }
        const removedIds = new Set();
        for (let i = c1i; i <= c2i; i++) removedIds.add(quoteGrid.columns[i].id);
        quoteGrid.merges = (quoteGrid.merges || []).filter(m => {
            const mCi = colIdToIdx(m.col);
            if (mCi < 0) return false;
            const mC2i = mCi + m.colspan - 1;
            if (mCi >= c1i && mCi <= c2i) return false; // 主列被删
            if (mC2i < c1i || mCi > c2i) {
                if (mCi < c1i && mC2i > c2i) {
                    m.colspan -= (c2i - c1i + 1);
                    return true;
                }
                if (mCi < c1i && mC2i >= c1i) {
                    m.colspan = c1i - mCi;
                    return true;
                }
                return true;
            }
            if (mCi < c1i) {
                m.colspan = c1i - mCi;
                return true;
            }
            return false;
        });
        quoteGrid.columns = quoteGrid.columns.filter(c => !removedIds.has(c.id));
        quoteGrid.rows.forEach(row => {
            removedIds.forEach(cid => delete row.cells[cid]);
        });
        // hiddenCols / colWidths / styles 清理
        if (Array.isArray(quoteGrid.hiddenCols)) {
            quoteGrid.hiddenCols = quoteGrid.hiddenCols.filter(id => !removedIds.has(id));
        }
        if (quoteGrid.colWidths) {
            removedIds.forEach(id => delete quoteGrid.colWidths[id]);
        }
        if (quoteGrid.styles) {
            Object.keys(quoteGrid.styles).forEach(k => {
                const [, cidStr] = k.split('_');
                const cid = parseInt(cidStr);
                if (removedIds.has(cid)) delete quoteGrid.styles[k];
            });
        }
        quoteSelection = { startRow: null, startCol: null, endRow: null, endCol: null, selecting: false };
        saveQuoteGridDebounced();
        renderQuoteGrid();
    });

    // 格式按钮
    const quoteAlignSelect = document.getElementById('quoteAlignSelect');
    if (quoteAlignSelect) quoteAlignSelect.addEventListener('change', () => {
        if (quoteAlignSelect.value) applyQuoteStyle('align', quoteAlignSelect.value);
        quoteAlignSelect.value = '';
    });

    const quoteVAlignSelect = document.getElementById('quoteVAlignSelect');
    if (quoteVAlignSelect) quoteVAlignSelect.addEventListener('change', () => {
        if (quoteVAlignSelect.value) applyQuoteStyle('valign', quoteVAlignSelect.value);
        quoteVAlignSelect.value = '';
    });

    const quoteFontSizeSel = document.getElementById('quoteFontSize');
    if (quoteFontSizeSel) quoteFontSizeSel.addEventListener('change', () => {
        if (quoteFontSizeSel.value) applyQuoteStyle('fontSize', parseInt(quoteFontSizeSel.value));
        quoteFontSizeSel.value = '';
    });

    // 字号调整（A- / A+）及快捷键
    const availableFontSizes = [12, 14, 16, 18, 20, 24, 28, 32, 36, 40];
    function adjustFontSize(delta) {
        if (!quoteSelection || quoteSelection.startRow === null) return;
        const key = `${quoteSelection.startRow}_${quoteSelection.startCol}`;
        let curSize = (quoteGrid.styles[key] && quoteGrid.styles[key].fontSize) || 13;
        // 找到最接近的档位
        let idx = availableFontSizes.findIndex(s => s >= curSize);
        if (idx < 0) idx = delta > 0 ? availableFontSizes.length - 1 : 0;
        idx = Math.max(0, Math.min(availableFontSizes.length - 1, idx + delta));
        // 如果当前大小和档位相同但方向相反，则移动到下一个
        if (availableFontSizes[idx] === curSize && delta !== 0) {
            idx = Math.max(0, Math.min(availableFontSizes.length - 1, idx + delta));
        }
        applyQuoteStyle('fontSize', availableFontSizes[idx]);
    }
    const fontUpBtn = document.getElementById('quoteFontSizeUp');
    if (fontUpBtn) fontUpBtn.addEventListener('click', () => adjustFontSize(1));
    const fontDownBtn = document.getElementById('quoteFontSizeDown');
    if (fontDownBtn) fontDownBtn.addEventListener('click', () => adjustFontSize(-1));
    // 快捷键：Ctrl+= 或 Ctrl++ 增大，Ctrl+- 减小
    document.addEventListener('keydown', (e) => {
        if (!quoteGrid) return;
        if (e.target.closest('#quoteGridContainer') === null
            && e.target.closest('#quoteToolbar') === null) return;
        if (e.ctrlKey || e.metaKey) {
            if (e.key === '=' || e.key === '+') {
                e.preventDefault();
                adjustFontSize(1);
            } else if (e.key === '-') {
                e.preventDefault();
                adjustFontSize(-1);
            }
        }
    });

    const quoteFontFamilySel = document.getElementById('quoteFontFamily');
    if (quoteFontFamilySel) quoteFontFamilySel.addEventListener('change', () => {
        if (quoteFontFamilySel.value) applyQuoteStyle('fontFamily', quoteFontFamilySel.value);
        quoteFontFamilySel.value = '';
    });

    const quoteBoldBtn = document.getElementById('quoteBoldBtn');
    if (quoteBoldBtn) quoteBoldBtn.addEventListener('click', () => {
        // 切换：检查第一个单元格是否已加粗
        if (!quoteSelection || quoteSelection.startRow === null) return;
        const key = `${quoteSelection.startRow}_${quoteSelection.startCol}`;
        const curBold = quoteGrid.styles[key] && quoteGrid.styles[key].bold;
        applyQuoteStyle('bold', !curBold);
    });

    const quoteFgColor = document.getElementById('quoteFgColor');
    if (quoteFgColor) quoteFgColor.addEventListener('input', () => { applyQuoteStyle('fg', quoteFgColor.value); });

    const quoteBgColor = document.getElementById('quoteBgColor');
    if (quoteBgColor) quoteBgColor.addEventListener('input', () => { applyQuoteStyle('bg', quoteBgColor.value); updateQuoteToolbarState(); });

    // 无填充按钮：清除 bg 样式（区分于白色填充）
    const quoteNoBgBtn = document.getElementById('quoteNoBgBtn');
    if (quoteNoBgBtn) quoteNoBgBtn.addEventListener('click', () => { applyQuoteStyle('bg', ''); updateQuoteToolbarState(); });

    // 更新工具栏状态（显示当前选中单元格的字号等）
    function updateQuoteToolbarState() {
        if (!quoteSelection || quoteSelection.startRow === null) return;
        const key = `${quoteSelection.startRow}_${quoteSelection.startCol}`;
        const style = quoteGrid.styles[key] || {};
        const fontSizeLabel = document.getElementById('quoteFontSizeLabel');
        if (fontSizeLabel) fontSizeLabel.textContent = style.fontSize || 13;
    }

    // 合并/拆分
    const quoteMergeBtn = document.getElementById('quoteMergeBtn');
    if (quoteMergeBtn) quoteMergeBtn.addEventListener('click', () => {
        if (!quoteGrid) { setStatus('表格未初始化'); return; }
        const rect = getSelectionRect();
        if (!rect) { setStatus('请先选中要合并的单元格（鼠标拖拽选择）'); return; }
        const { r1i, r2i, c1i, c2i } = rect;
        if (r1i === r2i && c1i === c2i) { setStatus('请选中至少2个单元格'); return; }
        const mainRowId = quoteGrid.rows[r1i].id;
        const mainColId = quoteGrid.columns[c1i].id;
        const rowspan = r2i - r1i + 1;
        const colspan = c2i - c1i + 1;
        // 移除所有与目标矩形相交的旧合并（避免合并嵌套混乱）
        quoteGrid.merges = (quoteGrid.merges || []).filter(m => {
            const mRi = rowIdToIdx(m.row);
            const mCi = colIdToIdx(m.col);
            if (mRi < 0 || mCi < 0) return false; // 失效合并直接移除
            const mR2i = mRi + m.rowspan - 1;
            const mC2i = mCi + m.colspan - 1;
            const intersect = !(mR2i < r1i || mRi > r2i || mC2i < c1i || mCi > c2i);
            return !intersect;
        });
        // 合并前先做一次防重：没有相同主单元格的合并（上面已过滤，但防御一下）
        const exists = quoteGrid.merges.some(m => m.row === mainRowId && m.col === mainColId);
        if (!exists) {
            quoteGrid.merges.push({ row: mainRowId, col: mainColId, rowspan, colspan });
        }
        // 合并后自动设置水平垂直居中到主单元格
        const mainKey = `${mainRowId}_${mainColId}`;
        if (!quoteGrid.styles[mainKey]) quoteGrid.styles[mainKey] = {};
        quoteGrid.styles[mainKey].align = 'center';
        quoteGrid.styles[mainKey].valign = 'middle';
        saveQuoteGridDebounced();
        renderQuoteGrid();
        setStatus('✅ 已合并单元格');
        setTimeout(() => setStatus(''), 1500);
    });

    const quoteSplitBtn = document.getElementById('quoteSplitBtn');
    if (quoteSplitBtn) quoteSplitBtn.addEventListener('click', () => {
        if (!quoteGrid) { setStatus('表格未初始化'); return; }
        const rect = getSelectionRect();
        if (!rect) { setStatus('请先选中要拆分的单元格'); return; }
        const { r1i, r2i, c1i, c2i } = rect;
        // 找出所有与选中矩形「相交」的合并，全部拆分
        // （这样即使点到合并块内部任何单元格，也能正确拆分整组合并）
        const toRemove = [];
        for (const m of (quoteGrid.merges || [])) {
            const mRi = rowIdToIdx(m.row);
            const mCi = colIdToIdx(m.col);
            if (mRi < 0 || mCi < 0) { toRemove.push(m); continue; }
            const mR2i = mRi + m.rowspan - 1;
            const mC2i = mCi + m.colspan - 1;
            const intersect = !(mR2i < r1i || mRi > r2i || mC2i < c1i || mCi > c2i);
            if (intersect) toRemove.push(m);
        }
        if (toRemove.length === 0) { setStatus('选中的单元格没有合并'); return; }
        quoteGrid.merges = (quoteGrid.merges || []).filter(m => toRemove.indexOf(m) < 0);
        saveQuoteGridDebounced();
        renderQuoteGrid();
        setStatus('✅ 已拆分单元格');
        setTimeout(() => setStatus(''), 1500);
    });

    // 导出 Excel
    const quoteExportBtn = document.getElementById('quoteExportBtn');
    if (quoteExportBtn) quoteExportBtn.addEventListener('click', async () => {
        if (!quoteGrid || quoteGrid.columns.length === 0) { setStatus('表格为空'); return; }
        try {
            await loadXLSX();
            const XLSX = window.XLSX;
            const headers = quoteGrid.columns.map(c => c.name);
            const data = quoteGrid.rows.map(row => {
                const obj = {};
                quoteGrid.columns.forEach(col => { obj[col.name] = row.cells[col.id] || ''; });
                return obj;
            });
            const ws = XLSX.utils.json_to_sheet(data, { header: headers });
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, '网络报价');
            XLSX.writeFile(wb, '网络报价.xlsx');
            setStatus('✅ 导出成功');
            setTimeout(() => setStatus(''), 1500);
        } catch (e) { setStatus('导出失败: ' + e.message); }
    });

    // 导出图片：克隆 DOM → 删除不需要部分 → 浏览器渲染
    // → inline 所有 computed style → XMLSerializer → SVG foreignObject
    // → Image → Canvas → Clipboard。利用浏览器原生引擎保证所见即所得。
    const quoteCopyImgBtn = document.getElementById('quoteCopyImgBtn');
    if (quoteCopyImgBtn) quoteCopyImgBtn.addEventListener('click', async () => {
        if (!quoteGrid || quoteGrid.columns.length === 0) { setStatus('表格为空'); return; }
        try {
            const g = quoteGrid;
            const container = document.getElementById('quoteGridContainer');
            if (!container) { setStatus('表格容器不存在'); return; }
            const table = container.querySelector('#quoteGridTable');
            if (!table) { setStatus('表格未渲染'); return; }

            const hiddenRows = new Set(Array.isArray(g.hiddenRows) ? g.hiddenRows : []);
            const hiddenCols = new Set(Array.isArray(g.hiddenCols) ? g.hiddenCols : []);

            // ------- 第 1 步：克隆表格，仅保留数据区域 -------
            // 用户明确要求：不需要列头(列1-7)、不需要行号(1-6)、不需要corner cell
            const clone = table.cloneNode(true);

            // 1a. 删除整个 thead（列1-7），但要保留列宽信息 → 用 colgroup 替代
            const thead = clone.querySelector('thead');
            if (thead) thead.remove();

            // 1a-2. 插入 colgroup，强制每列使用用户设置的宽度（仅包含可见列）
            // 否则 td 会按内容自动撑开，导致导出图片列宽与设置不一致
            const visibleCols = g.columns.filter(c => !hiddenCols.has(c.id));
            if (visibleCols.length > 0) {
                const colgroupHtml = '<colgroup>' + visibleCols.map(c => {
                    const w = g.colWidths[c.id] || 120;
                    return `<col style="width:${w}px;min-width:${w}px;">`;
                }).join('') + '</colgroup>';
                // 插入到 table 开头
                clone.insertAdjacentHTML('afterbegin', colgroupHtml);
                // 强制固定表格布局，确保列宽严格遵循 colgroup 设置，不被内容撑开
                clone.style.tableLayout = 'fixed';
            }
            // ★ 关键修复：给 <table> 本身显式加一圈完整边框。
            // 原 CSS 里只有 td/th 有 border，border-collapse: collapse 下外边框是边缘 td 的"半边框共享"，
            // 测量时这半像素常落在 getBoundingClientRect 之外，导致 SVG foreignObject 裁剪掉右/下边框。
            // 显式给 table 加 border-collapse + 外边框声明，使外边框 1px 完整归属于 table 元素，尺寸测量必包含它。
            clone.style.setProperty('border-collapse', 'collapse', 'important');
            clone.style.setProperty('border', '1px solid #dcdfe6', 'important');
            clone.style.setProperty('border-spacing', '0', 'important');

            // 1b. 删除 corner cell
            const corner = clone.querySelector('.corner-cell');
            if (corner) corner.remove();

            // 1c. 处理 tbody 中的每一行
            const tbodyRows = clone.querySelectorAll('tbody tr');
            tbodyRows.forEach(tr => {
                const rowId = parseInt(tr.dataset.rowId);
                if (hiddenRows.has(rowId)) {
                    tr.remove();
                    return;
                }
                tr.querySelectorAll('td.row-header').forEach(el => el.remove());
                tr.querySelectorAll('td[data-col-id]').forEach(td => {
                    const cid = parseInt(td.dataset.colId);
                    if (hiddenCols.has(cid)) td.remove();
                });
                tr.querySelectorAll('td.merge-covered-cell').forEach(td => td.remove());
            });

            // 1d. 删除装饰性子元素
            clone.querySelectorAll('.col-resize-handle, .row-resize-handle, .col-rename-input').forEach(el => el.remove());

            // 1e. 把 cell-display 内部替换为实际值 + 重新断言所有单元格样式（颜色/字体/对齐等）
            // 确保导出图片严格遵循用户在 quoteGrid.styles 中设置的样式
            // 调试日志：确认 quoteGrid.styles 中确实有 fg 值
            console.log('[EXPORT] 用户样式统计:', 
                'fg=' + Object.keys(g.styles).filter(k => g.styles[k].fg).length + 
                ', bg=' + Object.keys(g.styles).filter(k => g.styles[k].bg).length);

            clone.querySelectorAll('.cell-display').forEach(el => {
                const td = el.closest('td[data-row-id][data-col-id]');
                if (!td) return;
                const rowId = parseInt(td.dataset.rowId);
                const colId = parseInt(td.dataset.colId);
                const val = (g.rows.find(r => r.id === rowId)?.cells?.[colId]) || '';
                const key = `${rowId}_${colId}`;
                const cellStyle = g.styles[key] || {};

                // 从 cell-display 的 style 中提取 text-align
                let textAlign = cellStyle.align || 'left';
                const styleMatch = el.getAttribute('style');
                if (styleMatch) {
                    const taMatch = styleMatch.match(/text-align\s*:\s*([^;]+)/);
                    if (taMatch && !cellStyle.align) textAlign = taMatch[1].trim();
                }

                // 根据 quoteGrid.styles 重新构建完整的 cell-display style
                let displayStyle = `width:100%;height:100%;`;
                // 行高 / 合并高度
                const rowIdx = g.rows.findIndex(r => r.id === rowId);
                const h = g.rowHeights[rowId] || 32;
                const merge = g.merges ? g.merges.find(m => m.row === rowId && m.col === colId) : null;
                let totalHeight = h;
                if (merge && merge.rowspan > 1) {
                    totalHeight = 0;
                    for (let ri = 0; ri < merge.rowspan; ri++) {
                        const targetRow = g.rows[rowIdx + ri];
                        if (targetRow) totalHeight += g.rowHeights[targetRow.id] || 32;
                    }
                }
                displayStyle += `min-height:${(merge ? totalHeight : h)}px;`;
                displayStyle += `display:flex;flex-direction:row;flex-wrap:wrap;`;

                // 垂直对齐
                const valign = cellStyle.valign || (merge ? 'middle' : 'top');
                const vAlignFlex = valign === 'middle' ? 'align-items:center;' : (valign === 'bottom' ? 'align-items:flex-end;' : 'align-items:flex-start;');
                displayStyle += vAlignFlex;

                // 水平对齐
                const align = cellStyle.align || 'left';
                const hAlignFlex = align === 'center' ? 'justify-content:center;' : (align === 'right' ? 'justify-content:flex-end;' : 'justify-content:flex-start;');
                displayStyle += hAlignFlex;

                // 用户自定义样式
                if (cellStyle.fontFamily) displayStyle += `font-family:${cellStyle.fontFamily};`;
                if (cellStyle.bold) displayStyle += 'font-weight:bold;';
                if (cellStyle.fontSize) displayStyle += `font-size:${cellStyle.fontSize}px;`;
                if (cellStyle.fg) displayStyle += `color:${cellStyle.fg};-webkit-text-fill-color:${cellStyle.fg};`;
                displayStyle += 'padding:6px 10px;box-sizing:border-box;cursor:cell;line-height:1.5;white-space:pre-wrap;word-break:break-word;';
                displayStyle += `text-align:${align};`;

                // 设置 cell-display 的完整 style
                el.setAttribute('style', displayStyle);

                // 替换内容 —— 将 fg 颜色直接设置在 <span> 上，确保文本颜色不会因继承丢失
                if (val) {
                    const spanColor = cellStyle.fg ? `color:${cellStyle.fg};-webkit-text-fill-color:${cellStyle.fg};` : '';
                    el.innerHTML = `<span style="width:100%;text-align:${align};${spanColor}">${escapeHtml(String(val)).replace(/\n/g, '<br>')}</span>`;
                } else {
                    el.innerHTML = '&nbsp;';
                }
            });

            // 1e-2. 重新断言 td 的样式（背景色、边框、尺寸等）
            // 确保 bg (背景色) 也来自 quoteGrid.styles
            clone.querySelectorAll('td[data-row-id][data-col-id]').forEach(td => {
                const rowId = parseInt(td.dataset.rowId);
                const colId = parseInt(td.dataset.colId);
                const key = `${rowId}_${colId}`;
                const cellStyle = g.styles[key] || {};
                const rowIdx = g.rows.findIndex(r => r.id === rowId);
                const h = g.rowHeights[rowId] || 32;
                const merge = g.merges ? g.merges.find(m => m.row === rowId && m.col === colId) : null;
                let totalHeight = h;
                if (merge && merge.rowspan > 1) {
                    totalHeight = 0;
                    for (let ri = 0; ri < merge.rowspan; ri++) {
                        const targetRow = g.rows[rowIdx + ri];
                        if (targetRow) totalHeight += g.rowHeights[targetRow.id] || 32;
                    }
                }
                // 获取当前 td 的 style（可能已有 bg）
                let tdStyle = td.getAttribute('style') || '';
                // 移除旧的 background-color
                tdStyle = tdStyle.replace(/background-color\s*:[^;]*;?/g, '');
                if (cellStyle.bg) {
                    tdStyle += `background-color:${cellStyle.bg};`;
                }
                // 移除旧的 height/min-height 并重新设置
                tdStyle = tdStyle.replace(/height\s*:[^;]*;?/g, '').replace(/min-height\s*:[^;]*;?/g, '');
                const tdHeight = merge ? `height:${totalHeight}px;min-height:${totalHeight}px;` : `height:${h}px;min-height:${h}px;`;
                tdStyle += tdHeight;
                td.setAttribute('style', tdStyle);
            });

            // ------- 第 2 步：放到临时容器中测量，再统一添加四周等距 padding -------
            const padding = 24; // 四周统一空隙
            const tmpContainer = document.createElement('div');
            tmpContainer.style.cssText = `position:absolute;left:-99999px;top:-99999px;background:#fff;display:inline-block;box-sizing:content-box;overflow:visible;`;
            // ★ 关键：把 clone 放进一个"内容层 div"，用 content-box 测量纯内容尺寸，
            // 然后外层 SVG 背景是白色，内容层通过 width=cloneW + margin=padding 实现真正的四周等距
            const innerWrap = document.createElement('div');
            innerWrap.style.cssText = `display:inline-block;box-sizing:content-box;width:auto;height:auto;background:#fff;`;
            innerWrap.appendChild(clone);
            tmpContainer.appendChild(innerWrap);
            document.body.appendChild(tmpContainer);

            await new Promise(r => requestAnimationFrame(() => r()));
            await new Promise(r => requestAnimationFrame(() => r()));

            // ★ 修复尺寸裁剪：
            // 1) 用数据模型计算"理论尺寸"（可见列宽之和、可见行高之和），避免亚像素渲染误差
            // 2) 再加上 table 自身声明的外边框（左右/上下各 1px = +2px）
            // 3) 最后与 DOM 实际测量值取 max，再额外 +2px 做像素舍入缓冲
            //    ↑ 因为 table 已显式声明 border:1px，外边框完整归属于 table，DOM 测量必包含，
            //    只需很小的缓冲即可避免亚像素裁剪，不会出现多余的边距或双重边框。
            const _visibleCols = g.columns.filter(c => !hiddenCols.has(c.id));
            const _hiddenRows = new Set(Array.isArray(g.hiddenRows) ? g.hiddenRows : []);
            const _visibleRows = g.rows.filter(r => !_hiddenRows.has(r.id));
            // 列宽和（不含 merge-covered 行的特殊列）
            let theoryW = _visibleCols.reduce((s, c) => s + (g.colWidths[c.id] || 120), 0);
            // 行高和（合并行不会改变 tbody 的总高，因为 covered 行的 td 已被删，tr 仍在）
            let theoryH = _visibleRows.reduce((s, r) => s + (g.rowHeights[r.id] || 32), 0);
            // table 自身 1px 外边框：左右各 1、上下各 1 → 各加 +2
            theoryW += 2;
            theoryH += 2;

            // DOM 实际测量（包含渲染后的文本溢出导致的尺寸扩展）
            const domRect = innerWrap.getBoundingClientRect();
            const domW = Math.ceil(domRect.width);
            const domH = Math.ceil(domRect.height);

            // 取 max(理论, DOM测量) 再加 +2px 缓冲（避免亚像素舍入误差）
            const cloneW = Math.max(theoryW, domW) + 2;
            const cloneH = Math.max(theoryH, domH) + 2;
            const totalW = cloneW + padding * 2;
            const totalH = cloneH + padding * 2;

            // ------- 第 3 步：显式断言用户设置的关键样式（在 getComputedStyle 之前！） -------
            // 关键：必须在 getComputedStyle 之前执行，因为 Step 3 会删除 data-row-id / data-col-id 属性
            // 这一步确保 fg (字体颜色)、bg (背景色)、bold、fontSize、fontFamily 等
            // 用户自定义样式绝对不会在导出图片中丢失
            // 调试：统计有多少 td 被匹配到
            const tdsWithData = clone.querySelectorAll('td[data-row-id][data-col-id]');
            console.log('[EXPORT DEBUG] Step3 - td elements with data attributes:', tdsWithData.length);
            console.log('[EXPORT DEBUG] Step3 - cell-display elements:', clone.querySelectorAll('.cell-display').length);
            let matchedCount = 0;
            let fgSetCount = 0;
            tdsWithData.forEach(td => {
                const rowId = parseInt(td.dataset.rowId);
                const colId = parseInt(td.dataset.colId);
                const key = `${rowId}_${colId}`;
                const cellStyle = g.styles[key];
                if (!cellStyle) return;

                // 对 .cell-display div 显式设置关键样式
                const displayDiv = td.querySelector('.cell-display');
                if (!displayDiv) return;

                // 从当前 style 中移除旧的 color / font-weight / font-size / font-family
                let divStyle = displayDiv.getAttribute('style') || '';
                divStyle = divStyle.replace(/(^|;)color\s*:[^;]*(;|$)/g, '$1');
                divStyle = divStyle.replace(/(^|;)-webkit-text-fill-color\s*:[^;]*(;|$)/g, '$1');
                divStyle = divStyle.replace(/(^|;)font-weight\s*:[^;]*(;|$)/g, '$1');
                divStyle = divStyle.replace(/(^|;)font-size\s*:[^;]*(;|$)/g, '$1');
                divStyle = divStyle.replace(/(^|;)font-family\s*:[^;]*(;|$)/g, '$1');
                // 清理多余的分号
                divStyle = divStyle.replace(/;+/g, ';').replace(/^;|;$/g, '');

                // 用用户设置的样式重新构建（确保分号分隔正确）
                const newParts = [];
                if (cellStyle.fg) newParts.push(`color:${cellStyle.fg}`, `-webkit-text-fill-color:${cellStyle.fg}`);
                if (cellStyle.bold) newParts.push('font-weight:bold');
                if (cellStyle.fontSize) newParts.push(`font-size:${cellStyle.fontSize}px`);
                if (cellStyle.fontFamily) newParts.push(`font-family:${cellStyle.fontFamily}`);
                if (newParts.length > 0) {
                    divStyle = (divStyle ? divStyle + ';' : '') + newParts.join(';');
                }
                displayDiv.setAttribute('style', divStyle);

                // 对内部 <span> 也显式设置 color，确保文本颜色不会丢失
                const span = displayDiv.querySelector('span');
                if (span && cellStyle.fg) {
                    let spanStyle = span.getAttribute('style') || '';
                    spanStyle = spanStyle.replace(/(^|;)color\s*:[^;]*(;|$)/g, '$1');
                    spanStyle = spanStyle.replace(/(^|;)-webkit-text-fill-color\s*:[^;]*(;|$)/g, '$1');
                    spanStyle = spanStyle.replace(/;+/g, ';').replace(/^;|;$/g, '');
                    spanStyle = (spanStyle ? spanStyle + ';' : '') + `color:${cellStyle.fg};-webkit-text-fill-color:${cellStyle.fg}`;
                    span.setAttribute('style', spanStyle);
                }

                // 对 td 显式设置背景色
                if (cellStyle.bg) {
                    let tdStyle = td.getAttribute('style') || '';
                    tdStyle = tdStyle.replace(/(^|;)background-color\s*:[^;]*(;|$)/g, '$1');
                    tdStyle = tdStyle.replace(/;+/g, ';').replace(/^;|;$/g, '');
                    tdStyle = (tdStyle ? tdStyle + ';' : '') + `background-color:${cellStyle.bg}`;
                    td.setAttribute('style', tdStyle);
                }
                matchedCount++;
                if (cellStyle.fg) fgSetCount++;
            });
            console.log('[EXPORT] Step3 - 样式重断言:', `匹配${matchedCount}个单元格, 设置颜色${fgSetCount}个`);

            // ------- 第 4 步：保存元素引用 + getComputedStyle 内联样式 -------
            // foreignObject 不继承宿主页面样式表，必须 inline 所有 computed style
            // ★ 关键：先保存 {td, displayDiv, span, style} 的引用，再删除属性
            //     因为删除 class 后 .cell-display 选择器失效；删除 data-* 后 query 失效
            const reassertList = [];
            clone.querySelectorAll('td[data-row-id][data-col-id]').forEach(tdEl => {
                const k = `${tdEl.dataset.rowId}_${tdEl.dataset.colId}`;
                const st = g.styles[k];
                if (!st || (!st.fg && !st.bg && !st.bold && !st.fontSize && !st.fontFamily)) return;
                // 获取子元素的直接引用（不是用 class selector，而是用 DOM 结构）
                // .cell-display 是 td 的第一个/唯一一个子 div
                const displayDiv = tdEl.children && tdEl.children[0];
                if (!displayDiv) return;
                // span 是 displayDiv 的第一个 span 子元素（如果是内容单元格）
                const spanEl = displayDiv.querySelector('span');
                reassertList.push({ tdEl, displayDiv, spanEl, style: st });
            });
            console.log(`[EXPORT] Step4 - 保存样式应用目标: ${reassertList.length} 个单元格`);

            const styleWalker = document.createTreeWalker(clone, NodeFilter.SHOW_ELEMENT);
            let styleNode = styleWalker.nextNode();
            // 这些属性 computed 默认值会覆盖用户显式设置的颜色/样式，必须排除
            const SKIP_PROPS = new Set([
                '-webkit-text-fill-color',
                '-webkit-text-stroke-color',
                '-webkit-text-stroke-width'
            ]);
            while (styleNode) {
                const el = styleNode;
                const cs = window.getComputedStyle(el);
                let parts = [];
                for (let i = 0; i < cs.length; i++) {
                    const name = cs[i];
                    if (SKIP_PROPS.has(name)) continue;
                    const val = cs.getPropertyValue(name);
                    if (val) parts.push(`${name}:${val}`);
                }
                const cssText = parts.join(';');
                if (cssText) el.setAttribute('style', cssText);
                // 清理不必要的属性（但不在 reassertList 中移除 class——保留也不影响 foreignObject）
                el.removeAttribute('id');
                el.removeAttribute('data-row-id');
                el.removeAttribute('data-col-id');
                el.removeAttribute('data-th');
                // 注意：保留 class，不会影响 foreignObject 渲染（样式已 inline）
                styleNode = styleWalker.nextNode();
            }

            // ------- 第 4b 步：getComputedStyle 之后重断言用户样式 -------
            // ★ 这一步是颜色保真的最后防线：直接用保存的 DOM 元素引用设置 style
            //   完全不依赖选择器，绝对不会失效
            let reassertedCount = 0;
            for (const item of reassertList) {
                const { tdEl, displayDiv, spanEl, style: cs } = item;

                // 重断言 .cell-display (displayDiv) 的关键样式
                let ds = displayDiv.getAttribute('style') || '';
                ds = ds.replace(/(^|;)color\s*:[^;]*(;|$)/g, '$1');
                ds = ds.replace(/(^|;)-webkit-text-fill-color\s*:[^;]*(;|$)/g, '$1');
                ds = ds.replace(/(^|;)font-weight\s*:[^;]*(;|$)/g, '$1');
                ds = ds.replace(/(^|;)font-size\s*:[^;]*(;|$)/g, '$1');
                ds = ds.replace(/(^|;)font-family\s*:[^;]*(;|$)/g, '$1');
                ds = ds.replace(/;+/g, ';').replace(/^;|;$/g, '');
                const dParts = [];
                if (cs.fg) dParts.push(`color:${cs.fg}`, `-webkit-text-fill-color:${cs.fg}`);
                if (cs.bold) dParts.push('font-weight:bold');
                if (cs.fontSize) dParts.push(`font-size:${cs.fontSize}px`);
                if (cs.fontFamily) dParts.push(`font-family:${cs.fontFamily}`);
                if (dParts.length) ds = (ds ? ds + ';' : '') + dParts.join(';');
                displayDiv.setAttribute('style', ds);

                // 重断言 <span> 的 color（文本颜色）
                if (spanEl && cs.fg) {
                    let ss = spanEl.getAttribute('style') || '';
                    ss = ss.replace(/(^|;)color\s*:[^;]*(;|$)/g, '$1');
                    ss = ss.replace(/(^|;)-webkit-text-fill-color\s*:[^;]*(;|$)/g, '$1');
                    ss = ss.replace(/;+/g, ';').replace(/^;|;$/g, '');
                    ss = (ss ? ss + ';' : '') + `color:${cs.fg};-webkit-text-fill-color:${cs.fg}`;
                    spanEl.setAttribute('style', ss);
                }

                // 重断言 td 的 background-color
                if (cs.bg) {
                    let ts = tdEl.getAttribute('style') || '';
                    ts = ts.replace(/(^|;)background-color\s*:[^;]*(;|$)/g, '$1');
                    ts = ts.replace(/;+/g, ';').replace(/^;|;$/g, '');
                    ts = (ts ? ts + ';' : '') + `background-color:${cs.bg}`;
                    tdEl.setAttribute('style', ts);
                }
                reassertedCount++;
            }
            console.log(`[EXPORT] Step4b - getComputedStyle 后重断言: ${reassertedCount} 个单元格`);
            // 验证结果：直接检查保存的 displayDiv 的颜色
            if (reassertList.length > 0) {
                const first = reassertList[0];
                const hasColor = (first.displayDiv.getAttribute('style') || '').includes('color:');
                console.log(`[EXPORT] 验证: 第一个有样式的单元格 fg=${first.style.fg}, 写入成功=${hasColor}`);
            }

            // ------- 第 5 步：XMLSerializer → SVG foreignObject -------
            const xml = new XMLSerializer().serializeToString(clone);

            // ★ 彻底修复四周空隙不对称：外层 SVG 是 totalW*totalH 的白色画布，
            // 内层 foreignObject 恰好是表格尺寸，使用 x/y 偏移把内容定位到正中央。
            // 背景由 SVG 的白色矩形保证，表格内容从 (padding, padding) 开始绘制。
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${totalW}" height="${totalH}" viewBox="0 0 ${totalW} ${totalH}"><rect width="100%" height="100%" fill="#ffffff"/><foreignObject x="${padding}" y="${padding}" width="${cloneW}" height="${cloneH}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${cloneW}px;height:${cloneH}px;display:inline-block;background:#fff;box-sizing:content-box;overflow:visible;">${xml}</div></foreignObject></svg>`;

            const svgDataUrl = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);

            document.body.removeChild(tmpContainer);

            // ------- 第 6 步：把 SVG 渲染到 Canvas -------
            const img = new Image();
            img.crossOrigin = 'anonymous';
            let imgErr = null;
            await new Promise((resolve) => {
                img.onload = resolve;
                img.onerror = (e) => { imgErr = e; resolve(); };
                img.src = svgDataUrl;
            });
            if (imgErr || !img.complete || img.naturalWidth === 0) {
                // 兜底：Blob URL
                try {
                    const fbBlob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
                    const fbUrl = URL.createObjectURL(fbBlob);
                    await new Promise((resolve) => {
                        img.onload = resolve;
                        img.onerror = (e) => { imgErr = e; resolve(); };
                        img.src = fbUrl;
                    });
                    URL.revokeObjectURL(fbUrl);
                } catch (_) { /* ignore */ }
                if (imgErr || !img.complete || img.naturalWidth === 0) {
                    throw new Error('图片生成失败，请刷新重试');
                }
            }

            const scale = 2;
            const canvas = document.createElement('canvas');
            canvas.width = totalW * scale;
            canvas.height = totalH * scale;
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.scale(scale, scale);
            ctx.drawImage(img, 0, 0);

            // ------- 第 7 步：输出 -------
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
            try {
                if (navigator.clipboard && navigator.clipboard.write && window.ClipboardItem) {
                    await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
                    setStatus('✅ 已复制到剪贴板，可直接粘贴');
                } else {
                    throw new Error('clipboard_not_available');
                }
            } catch (e) {
                const a = document.createElement('a');
                a.href = canvas.toDataURL('image/png');
                a.download = '网络报价.png';
                a.click();
                const msg = e.message === 'clipboard_not_available'
                    ? '当前为HTTP环境，剪贴板不可用（需HTTPS），已下载图片'
                    : '剪贴板写入失败，已下载图片';
                setStatus('💾 ' + msg);
            }
            setTimeout(() => setStatus(''), 2000);
        } catch (e) { setStatus('导出图片失败: ' + e.message); console.error(e); }
    });

    // 导入
    const quoteImportBtn = document.getElementById('quoteImportBtn');
    if (quoteImportBtn) quoteImportBtn.addEventListener('click', () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.xlsx,.xls,.csv';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            try {
                await loadXLSX();
                const XLSX = window.XLSX;
                const data = await file.arrayBuffer();
                const wb = XLSX.read(data);
                const ws = wb.Sheets[wb.SheetNames[0]];
                const json = XLSX.utils.sheet_to_json(ws, { header: 1 });
                if (json.length === 0) { setStatus('文件为空'); return; }

                if (!quoteGrid) quoteGrid = createEmptyQuoteGrid();
                quoteGrid.columns = [];
                quoteGrid.rows = [];
                quoteGrid.nextColId = 1;
                quoteGrid.nextRowId = 1;
                quoteGrid.styles = {};
                quoteGrid.merges = [];
                quoteGrid.colWidths = {};
                quoteGrid.rowHeights = {};

                const headers = json[0].map(h => String(h || ''));
                headers.forEach(h => {
                    if (h.trim()) {
                        const col = { id: quoteGrid.nextColId++, name: h };
                        quoteGrid.columns.push(col);
                        quoteGrid.colWidths[col.id] = 120;
                    }
                });
                for (let i = 1; i < json.length; i++) {
                    const row = { id: quoteGrid.nextRowId++, cells: {} };
                    quoteGrid.columns.forEach((col, idx) => {
                        row.cells[col.id] = json[i][idx] !== undefined ? String(json[i][idx]) : '';
                    });
                    quoteGrid.rows.push(row);
                }
                saveQuoteGridDebounced();
                renderQuoteGrid();
                setStatus('✅ 导入成功');
                setTimeout(() => setStatus(''), 1500);
            } catch (err) { setStatus('导入失败: ' + err.message); }
        };
        input.click();
    });

    // 加载标签
    loadQuoteTags();

    init();
});
